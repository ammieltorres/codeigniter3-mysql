<?php

class ReportsModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }
    

    public function SwappingReports($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_Swap');

        if($search)
            {
            $Branch             = $search['Branch'];
            $UserID             = $search['UserID'];
            $DriverID           = $search['DriverID'];
            $UnitID             = $search['UnitID'];

            $BatteryID          = $search['BatteryID'];
            $SwapType           = $search['SwapType'];
            $DateStart          = $search['DateStart'];
            $DateEnd            = $search['DateEnd'];




    
            if($Branch){              
                $this->db->where("Branch LIKE '%$Branch%'");   
                     
            }
    
            if($UserID){              
                $this->db->where("UserID LIKE '%$UserID%'");   
                     
            }
    
            if($DriverID){              
                $this->db->where("DriverID LIKE '%$DriverID%'");   
                     
            }
            if($UnitID){              
                $this->db->where("UnitID LIKE '%$UnitID%'");   
                     
            }


            if($BatteryID){              
                $this->db->where("BatteryID LIKE '%$BatteryID%'");   
                     
            }
    
            if($SwapType){              
                $this->db->where("SwapType LIKE '%$SwapType%'");   
                     
            }
    
            if($DateStart){              
                $this->db->where('DATE(DateTime) >=', date('Y-m-d',strtotime($DateStart)));  
                     
            }
            if($DateEnd){              
                $this->db->where('DATE(DateTime) <=', date('Y-m-d',strtotime($DateEnd))); 
            }
    
           
            $this->db->Order_by("ReferenceCode", "Desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }







    public function BatteryReports($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_Charge');

        if($search)
            {
            $Branch             = $search['Branch'];
            $UserID             = $search['UserID'];
            $BatteryID          = $search['BatteryID'];
            $ChargeType         = $search['ChargeType'];

    
            if($Branch){              
                $this->db->where("Branch LIKE '%$Branch%'");   
                     
            }
    
            if($UserID){              
                $this->db->where("UserID LIKE '%$UserID%'");   
                     
            }
    
            if($BatteryID){              
                $this->db->where("BatteryID LIKE '%$BatteryID%'");   
                     
            }
            if($ChargeType){              
                $this->db->where("ChargeType LIKE '%$ChargeType%'");   
                     
            }
            
            $this->db->Order_by("ReferenceCode", "Desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }


    





    public function rp_log($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_Log');

        if($search)
            {
            $Branch             = $search['Branch'];
            $UserID             = $search['UserID'];
            $SwapType           = $search['SwapType'];
            $DateStart          = $search['DateStart'];
            $DateEnd            = $search['DateEnd'];
            $ItemCode           = $search['ItemCode'];
            $Category           = $search['Category'];
            
            if($Branch){              
                $this->db->where("Branch LIKE '%$Branch%'");   
                     
            }
    
            if($UserID){              
                $this->db->where("UserID LIKE '%$UserID%'");   
                     
            }
    
            if($SwapType){              
                $this->db->where("SwapType LIKE '%$SwapType%'");   
                     
            }
            if($DateStart){              
                $this->db->where('DATE(DateTimeStamp) >=', date('Y-m-d',strtotime($DateStart)));
            }
            if($DateEnd){              
                $this->db->where('DATE(DateTimeStamp) <=', date('Y-m-d',strtotime($DateEnd)));
                     
            }
            if($ItemCode){              
                $this->db->where("ItemCode LIKE '%$ItemCode%'");   
                     
            }
            if($Category){              
                $this->db->where("Category LIKE '%$Category%'");   
                     
            }
    
            
            $this->db->Order_by("ReferenceCode", "Desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }

public function lowvolcount()
{
  
}


// mileage report ajax


public function MileageReports($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            $Branch             = $search['Branch'];
            // $UserID             = $search['UserID'];
            // $SwapType           = $search['SwapType'];
            // $DateStart          = $search['DateStart'];
            // $DateEnd            = $search['DateEnd'];
            // $ItemCode           = $search['ItemCode'];
            // $Category           = $search['Category'];
            
            if($Branch){              
                // $this->db->where("Branch LIKE '%$Branch%'");   
                     
            }
            $this->db->where("CategoryCode", '0003');   
            // if($UserID){              
            //     $this->db->where("UserID LIKE '%$UserID%'");   
                     
            // }
    
           
    
            
            // $this->db->Order_by("currentmileage", "Desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
    
}

?>
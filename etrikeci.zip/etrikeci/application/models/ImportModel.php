<?php

class ImportModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }
    
    
    public function dlttemp($delete)
    {
        
        
        $data = explode("|", $delete);

        
        $this -> db -> where('UnitBattery', $data[0]);
        $this -> db -> where('Status', $data[1]);
        $this -> db -> where('DateTime', $data[2]);
        $this -> db -> delete('GS_Logs_Temp');

            
            
    }
    public function importtemp($data)
    {
            $insert = $this->db->insert('GS_Logs_Temp',$data);
             return ($this->db->affected_rows() != 1) ? false : true;
            
            
    }
    public function SP_GS_FindEquipments_V2()
    {
         $sql = "call `SP_GS_FindEquipments_V2` ()";
       
            $result = $this->db->query($sql);
            return true;
    }
   public function importreportrawdata($data)
    {
            $insert = $this->db->insert('GS_Report_RawData',$data);
             return ($this->db->affected_rows() != 1) ? false : true;
            
            
    }

    public function sp_GS_Report_RawData_Process_V2($data)
    {
            $sql = "call `sp_GS_Report_RawData_Process_V2` (?,?)";
            $result = $this->db->query($sql,$data);
            return true;
    }
    
}
    
    
<?php

class CashierModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }
    
        public function CH_CHECKINOUT_ADD($data)
    {
            $sql = "call `CH_CHECKINOUT_ADD` (?,?,?,?,?,?,?,?,?)";
       
            $result = $this->db->query($sql,$data);
            return $data;
    }
    
      public function DriverPayment($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('CH_CHECKINOUT');

        if($search)
            {
            // $Branch             = $search['Branch'];
            $USERID                 = $search['USERID'];

    
            if($USERID){              
                $this->db->where("USERID LIKE '%$USERID%'");   
                     
            }
            //Battery Code
            // $this->db->where("CategoryCode","0003"); 
    
     
            
            $this->db->Order_by("CHECKTIME", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
}

<?php

class DropDownModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function fs_branch()
    {
        $query = $this->db->get('fs_branch');
        $query = $this->db->query('SELECT BranchCode, Branch FROM fs_branch');
 
        return $query->result();

    }
}


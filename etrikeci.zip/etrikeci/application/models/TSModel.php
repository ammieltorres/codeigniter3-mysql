<?php

class TSModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function ViewDeviceList($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_DeviceLocationList');

        if($search)
        {
            $Imei                       = $search['Imei'];
            $deviceName                 = $search['deviceName'];
            $DateStart                  = $search['DateStart'];
            $DateEnd                    = $search['DateEnd'];
            if($Imei)
            {              
                $this->db->where("Imei LIKE '%$Imei%'");      
            }
            if($deviceName)
            {              
                $this->db->where("deviceName LIKE '%$deviceName%'");   
            }

            if($DateStart){              
                $this->db->where('DateTimeStamp >=', date('Y-m-d H:i',strtotime($DateStart)));   
            }
            if($DateEnd){              
                $this->db->where('DateTimeStamp <=', date('Y-m-d H:i',strtotime($DateEnd))); 
            }

            $this->db->Order_by("DeviceLocationListID", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }


    public function sys_Token_AED($token)
    {
            $sql = "call `sys_Token_AED` (?,?,?,?,?,?,?)";
       
            $result = $this->db->query($sql,$token);
            return $token;
    }
    
    // Mileage
     public function TrackMileage($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_TrackMileage');

        if($search)
        {
            $Imei                       = $search['Imei'];
            $StartTime                       = $search['StartTime'];
            $EndTime                       = $search['EndTime'];

            if($Imei)
            {              
                $this->db->where("IMEI",$Imei);      
            }
            if($StartTime)
            {              
                // $this->db->where("StartTime",$StartTime);      
                   $this->db->where('StartTime >=', date('Y-m-d H:i',strtotime($StartTime))); 
            }
           if($EndTime)
            {              
                // $this->db->where("StartTime",$StartTime);      
                   $this->db->where('EndTime <=', date('Y-m-d H:i',strtotime($EndTime))); 
            }
    

            //  $this->db->group_by("IMEI");   
            $this->db->Order_by("IMEI", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
    public function rp_TrackMileage_Add($data)
    {
            $sql = "call `rp_TrackMileage_Add` (?,?,?,?,?,?,?,?,?,?)";
       
            $result = $this->db->query($sql,$data);
            return $data;
    }

    public function sp_rp_devicelocationlist_weekly_milage()
    {
            $sql = "call `sp_rp_devicelocationlist_weekly_milage` ";
       
            $result = $this->db->query($sql);
            return $result->result();
    }
    public function sp_rp_equipments_gtmileage()
    {
        $sql = "call `sp_rp_equipments_gtmileage` ";
       
        $result = $this->db->query($sql);
        return $result->result();
    }
}
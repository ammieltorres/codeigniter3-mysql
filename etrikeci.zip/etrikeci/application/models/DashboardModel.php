<?php

class DashboardModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }
    
    public function GetBattery($limit, $offset, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_DeviceLocationList');
       $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d"))));
        $this->db->group_by('deviceName'); 
        $this->db->distinct('deviceName');
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    
    }
    
    public function GetL5KM($limit, $offset, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_TrackMileage');
                $this->db->group_by('IMEI'); 
                $this->db->where('Distance <',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
        public function GetG5KM($limit, $offset, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_TrackMileage');
                $this->db->group_by('IMEI'); 
                $this->db->where('Distance >',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
    
    // BATTERIES TO CHARGE  - 0001 =============
    public function Battocharge($limit, $offset, $count)
        {
            $this->db->select('*');
            $this->db->from('equipments');
                    $this->db->where('GS_StatusCode','0001');
            if($count)
            {
                return $this->db->count_all_results();     
            }
            else 
                {     
                $this->db->limit($limit, $offset);
                $query = $this->db->get();
        
                if($query->num_rows() > 0) {
                    return $query->result();            
                }  
            }
            return array();
        }
    
    // BATTERIES CHARGING   - 0002 =============
        public function Batcharging($limit, $offset, $count)
        {
            $this->db->select('*');
            $this->db->from('equipments');
                    $this->db->where('GS_StatusCode','0002');
            if($count)
            {
                return $this->db->count_all_results();     
            }
            else 
                {     
                $this->db->limit($limit, $offset);
                $query = $this->db->get();
        
                if($query->num_rows() > 0) {
                    return $query->result();            
                }  
            }
            return array();
        }
    
    // BATTERIES AVAILABLE  - 0003 =============
        public function BatAvailable($limit, $offset, $count)
        {
            $this->db->select('*');
            $this->db->from('equipments');
                    $this->db->where('GS_StatusCode','0003');
            if($count)
            {
                return $this->db->count_all_results();     
            }
            else 
                {     
                $this->db->limit($limit, $offset);
                $query = $this->db->get();
        
                if($query->num_rows() > 0) {
                    return $query->result();            
                }  
            }
            return array();
        }
    
    // BATTERIES IN USE     - 0004 =============
        public function Batinuse($limit, $offset, $count)
        {
            $this->db->select('*');
            $this->db->from('equipments');
                    $this->db->where('GS_StatusCode','0004');
            if($count)
            {
                return $this->db->count_all_results();     
            }
            else 
                {     
                $this->db->limit($limit, $offset);
                $query = $this->db->get();
        
                if($query->num_rows() > 0) {
                    return $query->result();            
                }  
            }
            return array();
        }

}


<?php
class SettingsModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }



    public function UserSettings($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('fs_users');

        if($search)
            {

            $UserID                = $search['UserID'];
            $LName                 = $search['LName'];
            $FName                 = $search['FName'];
            $MName                 = $search['MName'];
            $BranchCode            = $search['BranchCode'];
    
            if($UserID){              
                $this->db->where("UserID LIKE '%$UserID%'");    
            }
            if($LName){              
                $this->db->where("LName LIKE '%$LName%'");    
            }
            if($FName){              
                $this->db->where("FName LIKE '%$FName%'");        
            }
            if($MName){              
                $this->db->where("MName LIKE '%$MName%'");   
                     
            }
            if($BranchCode){              
                $this->db->where("BranchCode LIKE '%$BranchCode%'");   
            }

            $this->db->Order_by("LName", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }




}
?>
    
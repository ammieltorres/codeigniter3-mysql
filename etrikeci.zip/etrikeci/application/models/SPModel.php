<?php

class SPModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }


    //Scan =====================================================
    public function rp_swap_add($data)
    {
            $sql = "call `rp_swap_add` (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    public function rp_charge_add($data)
    {
            $sql = "call `rp_charge_add` (?,?,?,?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }

    public function rp_repair_add($data)
    {
            $sql = "call `rp_repair_add` (?,?,?,?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    //extract ================================================
    public function sp_rp_log_find($data)
    {
            $sql = "call `sp_rp_log_find` (?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    public function rp_swap_find($data)
    {
            $sql = "call `rp_swap_find` (?,?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    //Admin ================================================
    public function rp_equipments_update($data)
    {
            $sql = "call `rp_equipments_update` (?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    
    public function rp_fs_users_aed($data)
    {
            $sql = "call `rp_fs_users_aed` (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $result = $this->db->query($sql,$data);
            return $result->result();
    }

    //dashboard ================================================
    public function rp_equipments_status()
    {
            $sql = "call `rp_equipments_status` (?)";
            $data = array(
                'p_userid' => '',
            );
            $result = $this->db->query($sql,$data);
            return $result->result();
    }
    // Equipmend AED
    public function sp_rp_equipments_aed($data)
    {
            $sql = "call `sp_rp_equipments_aed` (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
       
            $result = $this->db->query($sql,$data);
            return $data;
    }


    public function sp_rp_DeviceLocationList_AED($val)
    {
            $sql = "call `sp_rp_DeviceLocationList_AED` (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      
            $result = $this->db->query($sql,$val);
            
            
            return $val;
    }
    
    public function sp_rp_equipments_find($val)
    {
            $sql = "call `sp_rp_equipments_find` (?,?,?)";
       
            $result = $this->db->query($sql,$val);
            return $result->result();
            // return $val;
    }

    public function sp_rp_equipments_updatemilage($val)
    {
            $sql = "call `sp_rp_equipments_updatemilage` (?,?)";
       
            $result = $this->db->query($sql,$val);
            // return $result->result();
            return $val;
    }












    function curlExecute($url,$type = 'GET', $params = NULL, $repeated = 0) {

        error_reporting(0); ini_set("display_errors",0);
        //error_reporting(E_ALL); ini_set("display_errors",1);
        date_default_timezone_set('UTC');
    
        define('DB_HOST','localhost');
        define('DB_USER','u523929723_db1');
        define('DB_PASS','UrZ!dN>+99~c');
        define('DB_NAME','u523929723_db1');
    
    
        define('ROOT','/home/u523929723/domains/gwgps.net/public_html');
        define('URL','https://gwgps.net');
    
        define('APP_URL','https://open.10000track.com/route/rest');
        //define('APP_URL','https://hk-open.tracksolidpro.com/route/rest');
    
    
        define('APP_KEY','8FB345B8693CCD002B61020E9A0B42BC');
        define('APP_SECRET','bcea22916410433db0233991acd5e623');
        define('USER_ID','GerWeiss');
        define('USER_PWD_MD5','a5aac79a15425e28acafe27c3075fabc');

        $curl = curl_init();

        if ($type == 'POST') {
            curl_setopt($curl, CURLOPT_POST, 1);
            if (!empty($params)) {
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
            }
        }

        if ($type == 'GET') {
            if (!empty($params)) {
                $fields =  http_build_query($params);
                $url .= '?' . $fields;
            }
        }

        if ($type == 'PUT') {
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
            if (!empty($params)) {
                $fields =  http_build_query($params);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $fields);
            }
        }

        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_HEADER => 0,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_REFERER => '',
            CURLOPT_URL => $url,
            CURLOPT_USERAGENT => '',
//            CURLOPT_SSL_VERIFYHOST => false,
//            CURLOPT_SSL_VERIFYPEER => false,


      ));


        //echo $access_token; die();
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/json' ,
            )
        );
        $output = curl_exec($curl);

        if (!$output) {
            die('Error: "' . curl_error($curl) . '" - Code: ' . curl_errno($curl));
        } else {

            $decoded =  json_decode($output);
            if (intval($decoded->code) == 1004) {
                // get new token
                //die();
            }
            return $decoded;
        }

        curl_close($curl);
    }
    
    
}
?>
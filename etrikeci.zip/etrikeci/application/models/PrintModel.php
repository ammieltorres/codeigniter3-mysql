
<?php

class PrintModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function equipmentsprintQR($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            $CategoryCode       = $search['CategoryCode'];
            $ID                 = $search['ID'];

            if($CategoryCode)
            {              
                $this->db->where("CategoryCode LIKE '%$CategoryCode%'");      
            }
    
            if($ID)
            {              
                $this->db->where("ID LIKE '%$ID%'");   
            }

            $this->db->Order_by("ID", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }



}


    
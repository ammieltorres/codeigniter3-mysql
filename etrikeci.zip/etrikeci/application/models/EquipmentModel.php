<?php

class EquipmentModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }
    
    
    
     public function rp_DistanceLfivekm_find($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_TrackMileage');

        if($search)
            {
               $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 00:00:00';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) >=",$dateend);  
                $this->db->where("Distance <=",5000); 
                $this->db->group_by('IMEI'); 

            // $this->db->Order_by("Distance", "desc");   
            $this->db->order_by('DateTimeStamp','DESC'); 
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    
    
    
     public function rp_DistanceGfivekm_find($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_TrackMileage');

        if($search)
            {

            // $Distance                             = $search['Distance'];
                $Distance                             = '5000';
            // $Distance                             = '5000';
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 00:00:00';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);
                $this->db->where("Distance >=",5000); 
                $this->db->group_by('IMEI'); 
                $this->db->order_by('DateTimeStamp','DESC'); 
            // $this->db->Order_by("Distance", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }

  public function rp_lowvoldate_find($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('rp_DeviceLocationList');

        if($search)
            {

            $Date                             = $search['CurDate'];
  

   
            if($Date){              
                $this->db->where("DATE(DateTimeStamp) LIKE '%$Date%'");    
            }
            $this->db->group_by('deviceName'); 
            $this->db->distinct('deviceName');

            $this->db->Order_by("DeviceLocationListID", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
    public function Equipments($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {

            $ID                             = $search['ID'];
            $CategoryCode                   = $search['CategoryCode'];

            if($ID){              
                $this->db->where("ID LIKE '%$ID%'");    
            }
            if($CategoryCode){              
                $this->db->where("CategoryCode LIKE '%$CategoryCode%'");    
            }

            $this->db->Order_by("ID", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }
  public function sp_rp_equipments_find($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {

            $Category                             = $search['p_Category'];
            $Status                               = $search['p_Status'];

            // Category
            // EStatus
            // CStatus
            // RStatus
            if($Category){              
                $this->db->where("Category LIKE '%$Category%'");    
            }

            if($Status)
            {              
                if(stripos($Status,'SWAP IN') !== FALSE)
                {
                    $this->db->where("EStatus LIKE '%$Status%'");  
                }
                elseif(stripos($Status,'SWAP OUT') !== FALSE)
                {
                    $this->db->where("EStatus LIKE '%$Status%'");  
                }


                elseif(stripos($Status,'REPAIR IN') !== FALSE)
                {
                    $this->db->where("RStatus LIKE '%$Status%'");  
                }
                elseif(stripos($Status,'REPAIR OUT') !== FALSE)
                {
                    $this->db->where("RStatus LIKE '%$Status%'");  
                }


                elseif(stripos($Status,'CHARGE IN') !== FALSE)
                {
                    $this->db->where("CStatus LIKE '%$Status%'");  
                }
                elseif(stripos($Status,'CHARGE OUT') !== FALSE)
                {
                    $this->db->where("CStatus LIKE '%$Status%'");  
                }
            }

            $this->db->Order_by("ID", "desc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array(); 
    }



}


<?php

class ApiTestingModel extends CI_Model
{
    
    public function __construct()
    {
        $this->load->database();
    }
    
    
    public function Addapitabletest($value)
    {
        // apitabletest
         return ($this->db->insert('apitabletest',$value)) ?   $this->db->insert_id()  :   false;
    }


}
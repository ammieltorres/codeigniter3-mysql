<?php

class Loginmodel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }



    function can_login($UserID, $Password)
    {
        $this->db->where('UserID',$UserID);
        $this->db->where('UserPassword',$Password);
        // $this->db->where('statusID', '0');

       

        $query = $this->db->get('fs_users');
        
        if($query->num_rows() > 0)
        {
            return $query->result();   
        }
        else
        {
            return false;
        }

    }


    function can_loginrfid($RFID)
    {
        $this->db->where('RFID',$RFID);
        // $this->db->where('UserPassword',$Password);
        // $this->db->where('statusID', '0');

       

        $query = $this->db->get('fs_users');
        
        if($query->num_rows() > 0)
        {
            return $query->result();   
        }
        else
        {
            return false;
        }

    }

    
}

?>
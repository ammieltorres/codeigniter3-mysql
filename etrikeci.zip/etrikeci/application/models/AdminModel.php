<?php

class AdminModel extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }



    public function StatusBattery($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            // $Branch             = $search['Branch'];
            $ID                 = $search['ID'];


    
            // if($Branch){              
            //     $this->db->where("Branch LIKE '%$Branch%'");   
                     
            // }
    
            if($ID){              
                $this->db->where("ID LIKE '%$ID%'");   
                     
            }
            //Battery Code
            $this->db->where("CategoryCode","0003"); 
    
     
            
            $this->db->Order_by("ID", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }









    public function StatusUnit($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            // $Branch             = $search['Branch'];
            $ID                 = $search['ID'];


    
            // if($Branch){              
            //     $this->db->where("Branch LIKE '%$Branch%'");   
                     
            // }
    
            if($ID){              
                $this->db->where("ID LIKE '%$ID%'");   
                     
            }
            //Battery Code
            $this->db->where("CategoryCode","0002"); 
    
     
            
            $this->db->Order_by("ID", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }




    public function StatusCharger($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            // $Branch             = $search['Branch'];
            $ID                 = $search['ID'];


    
            // if($Branch){              
            //     $this->db->where("Branch LIKE '%$Branch%'");   
                     
            // }
    
            if($ID){              
                $this->db->where("ID LIKE '%$ID%'");   
                     
            }
            //Battery Code
            $this->db->where("CategoryCode","0004"); 
    
     
            
            $this->db->Order_by("ID", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }





    

    public function StatusDriver($limit, $offset, $search, $count)
    {
        $this->db->select('*');
        $this->db->from('equipments');

        if($search)
            {
            // $Branch             = $search['Branch'];
            $ID                 = $search['ID'];
            $LName                 = $search['LName'];
            $FName                 = $search['FName'];
            $MName                 = $search['MName'];
            


    
            // if($Branch){              
            //     $this->db->where("Branch LIKE '%$Branch%'");   
                     
            // }
    
            if($ID){              
                $this->db->where("ID LIKE '%$ID%'");   
                     
            }
            if($LName){              
                $this->db->where("LName LIKE '%$LName%'");   
                     
            }
            if($FName){              
                $this->db->where("FName LIKE '%$FName%'");   
                     
            }
            if($MName){              
                $this->db->where("MName LIKE '%$MName%'");   
                     
            }
            
            //driver Code
            $this->db->where("CategoryCode","0001"); 
    
     
            
            $this->db->Order_by("ID", "asc");   
        }   
     
        if($count)
        {
            return $this->db->count_all_results();     
        }
        else 
            {     
            $this->db->limit($limit, $offset);
            $query = $this->db->get();
    
            if($query->num_rows() > 0) {
                return $query->result();            
            }  
        }
        return array();
    }








    



    
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// $config['firebase_app_key'] = APPPATH . 'config/gerweiss-93261-firebase-adminsdk-bknn4-7a304027e0.json';
$config['firebase_app_key'] = __DIR__ . '/../config/gerweiss-93261-firebase-adminsdk-bknn4-7a304027e0.json';

// $factory = (new Factory())->withServiceAccount(__DIR__.'/../config/gerweiss-93261-firebase-adminsdk-bknn4-7a304027e0.json');

// $database = $factory->createDatabase();
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Kreait\Firebase\Factory;

class Firebase {
    protected $firebase;
    protected $CI;

    public function __construct()
    {
        $this->CI =& get_instance();
        
        // Load the Firebase configuration
        $this->CI->config->load('firebase', TRUE);
        
        // Get the path to the service account key file
        $serviceAccountKeyPath = $this->CI->config->item('firebase_app_key', 'firebase');

        // Initialize Firebase
        try {
            $this->firebase = (new Factory)
                ->withServiceAccount($serviceAccountKeyPath)
                ->create();
        } catch (Exception $e) {
            log_message('error', 'Firebase initialization error: ' . $e->getMessage());
        }
    }

    public function getDatabase()
    {
        return $this->firebase->getDatabase();
    }

}
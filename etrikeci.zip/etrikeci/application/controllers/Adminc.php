

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adminc extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('AdminModel');

    }

    //battery admin status edit
    public function AdminUpdateStatusBattery()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30100') === 'Y')
            { 
                $nav['title'] = "Battery Status";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('A_BStatusedt/StatusBattery');
                $this->load->view('A_BStatusedt/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
            
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function AdminUpdateStatusindexBattery()
    {
        if($this->session->userdata('UserID') != '')
        {  
            if($this->session->userdata('M30100') === 'Y')
            { 
      
                $search = array(
                                // 'Branch'        => trim($this->input->post('Branch')),
                                'ID'            => trim($this->input->post('ID')),
                    

                                );
                
                $this->load->library('pagination');
                
                $limit = 5;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Adminc/AdminUpdateStatusindexBattery/');
                $config['total_rows'] = $this->AdminModel->StatusBattery($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['BatteryReports'] = $this->AdminModel->StatusBattery($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('A_BStatusedt/eqpbatajax',$data);
            }
            else
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function BatteryModalStatusdata()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30100') === 'Y')
            { 
                $this->load->view('A_BStatusedt/modaldata');
            }
            else
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


        // admin Unit status edit


        public function AdminUpdateStatusUnity()
        {
            if($this->session->userdata('UserID') != '')
            { 
                if($this->session->userdata('M30200') === 'Y')
                { 
                    $nav['title'] = "Unit Status";
                    $this->load->view('globaltemplate/header');
                    $this->load->view('globaltemplate/nav', $nav);
                    $this->load->view('A_UStatusedt/StatusBattery');
                    $this->load->view('A_UStatusedt/footer');
                    $this->load->view('globaltemplate/footer');
                }
                else
                {
                    redirect($_SERVER['HTTP_REFERER']);
                }
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
    
        public function AdminUpdateStatusindexUnit()
        {
            if($this->session->userdata('UserID') != '')
            { 
                if($this->session->userdata('M30200') === 'Y')
                { 
                    $search = array(
                                    // 'Branch'        => trim($this->input->post('Branch')),
                                    'ID'            => trim($this->input->post('ID')),
                        
    
                                    );
                    
                    $this->load->library('pagination');
                    
                    $limit = 5;
                    $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
    
                    $config['base_url'] = site_url('Adminc/AdminUpdateStatusindexUnit/');
                    $config['total_rows'] = $this->AdminModel->StatusUnit($limit, $offset, $search, $count=true);
                    $config['per_page'] = $limit;
                    $config['uri_segment'] = 3;
                    $config['num_links'] = 3;
                    $config['num_tag_open']         = '<li>';
                    $config['num_tag_close']        = '</li>';
                    $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                    $config['cur_tag_close']        = '</a></li>';
                    $config['next_link']            = '>';
                    $config['next_tag_open']        = '<li>';
                    $config['next_tag_close']       = '</li>';
                    $config['prev_link']            = '<';
                    $config['prev_tag_open']        = '<li>';
                    $config['prev_tag_close']       = '</li>';
                    $config['first_link']           = '<<';
                    $config['first_tag_open']       = '<li>';
                    $config['first_tag_close']      = '</li>';
                    $config['last_link']            = '>>';
                    $config['last_tag_open']        = '<li>';
                    $config['last_tag_close']       = '</li>';
    
                    $this->pagination->initialize($config);
    
                    $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                    $data['BatteryReports'] = $this->AdminModel->StatusUnit($limit, $offset, $search, $count=false);
                    $data['pagelinks'] = $this->pagination->create_links();
    
                    // $this->load->view('templates/afteraddheader');
                    $this->load->view('A_UStatusedt/eqpbatajax',$data);
                }
                else
                {
                    redirect($_SERVER['HTTP_REFERER']);
                }
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }

        
    public function UnitModalStatusdata()
    {
        if($this->session->userdata('UserID') != '')
        {   
            if($this->session->userdata('M30200') === 'Y')
            { 
                $this->load->view('A_UStatusedt/modaldata');
            }
            else
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    // admin Driver status edit







    public function AdminUpdateStatusDriver()
        {
            if($this->session->userdata('UserID') != '')
            { 
                if($this->session->userdata('M30300') === 'Y')
                { 
                    $nav['title'] = "Driver Status";
                    $this->load->view('globaltemplate/header');
                    $this->load->view('globaltemplate/nav', $nav);
                    $this->load->view('A_DStatusedt/StatusBattery');
                    $this->load->view('A_DStatusedt/footer');
                    $this->load->view('globaltemplate/footer');
                }
                else
                {
                    redirect($_SERVER['HTTP_REFERER']);
                }
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
    
        public function AdminUpdateStatusindexDriver()
        {
            if($this->session->userdata('UserID') != '')
            { 
                if($this->session->userdata('M30300') === 'Y')
                { 
                    $search = array(
                                    // 'Branch'        => trim($this->input->post('Branch')),
                                    'ID'            => trim($this->input->post('ID')),
                                    'LName'            => trim($this->input->post('LName')),
                                    'FName'            => trim($this->input->post('FName')),
                                    'MName'            => trim($this->input->post('MName')),
                                    
                        
    
                                    );
                    
                    $this->load->library('pagination');
                    
                    $limit = 5;
                    $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
    
                    $config['base_url'] = site_url('Adminc/AdminUpdateStatusindexDriver/');
                    $config['total_rows'] = $this->AdminModel->StatusDriver($limit, $offset, $search, $count=true);
                    $config['per_page'] = $limit;
                    $config['uri_segment'] = 3;
                    $config['num_links'] = 3;
                    $config['num_tag_open']         = '<li>';
                    $config['num_tag_close']        = '</li>';
                    $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                    $config['cur_tag_close']        = '</a></li>';
                    $config['next_link']            = '>';
                    $config['next_tag_open']        = '<li>';
                    $config['next_tag_close']       = '</li>';
                    $config['prev_link']            = '<';
                    $config['prev_tag_open']        = '<li>';
                    $config['prev_tag_close']       = '</li>';
                    $config['first_link']           = '<<';
                    $config['first_tag_open']       = '<li>';
                    $config['first_tag_close']      = '</li>';
                    $config['last_link']            = '>>';
                    $config['last_tag_open']        = '<li>';
                    $config['last_tag_close']       = '</li>';
    
                    $this->pagination->initialize($config);
    
                    $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                    $data['BatteryReports'] = $this->AdminModel->StatusDriver($limit, $offset, $search, $count=false);
                    $data['pagelinks'] = $this->pagination->create_links();
    
                    // $this->load->view('templates/afteraddheader');
                    $this->load->view('A_DStatusedt/eqpbatajax',$data);
                }
                else
                {
                redirect($_SERVER['HTTP_REFERER']);
                }
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }

        
    public function DriverModalStatusdata()
    {
        if($this->session->userdata('UserID') != '')
        {       
            if($this->session->userdata('M30300') === 'Y')
            { 
            $this->load->view('A_DStatusedt/modaldata');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }





    //update status
    public function AdminUpdateStatusCharger()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30400') === 'Y')
            { 
                $nav['title'] = "Charger Status";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('A_CStatusedt/StatusCharger');
                $this->load->view('A_CStatusedt/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function ModalStatusUpdate()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30000') === 'Y')
            { 

                // $p_id       = 'B-N198';         
                // $p_category = 'Battery';
                // $p_status   = 'S';
                // $p_value    = 'SWAP OUT';

                $p_id       = trim($this->input->post('p_id'));           
                $p_category = trim($this->input->post('p_category'));
                $p_status   = mb_substr(trim($this->input->post('p_status')), 0, 1);
                $p_value    = trim($this->input->post('p_status')).' '. trim($this->input->post('p_value'));

                $data = array(
                    'p_id'                  =>    $p_id,
                    'p_category'            =>    $p_category,
                    'p_status'              =>    $p_status,
                    'p_value'               =>    $p_value,
                    'p_updatedbyuserid'     =>    $this->session->userdata('UserID'),
                );

                $data['ResultModal'] = $this->SPModel->rp_equipments_update($data);
                $this->load->view('A_BStatusedt/ResultModaledt', $data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


    // admin Charger 
    public function AdminUpdateStatusindexCharger()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30400') === 'Y')
            { 
                $search = array(
                                // 'Branch'        => trim($this->input->post('Branch')),
                                'ID'            => trim($this->input->post('ID')),
                    

                                );
                
                $this->load->library('pagination');
                
                $limit = 5;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Adminc/AdminUpdateStatusindexCharger/');
                $config['total_rows'] = $this->AdminModel->StatusCharger($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['BatteryReports'] = $this->AdminModel->StatusCharger($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('A_CStatusedt/eqpbatajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function savedatatest()
    {
        
       $records = explode("|", $this->input->post('getrec'));
        $s = explode(" ",$records[2]);
        if(trim($s[1]) == "IN")
        {
            $sVal="OUT";
        }
        else
        {
            $sVal="IN";
        }


        $p_id       = trim($records[0]);           
        $p_category = trim($records[1]);
        $p_status   = trim(mb_substr(trim($s[0]), 0, 1));
        $p_value    = trim($s[0]).' '. trim($sVal);

        $data = array(
            'p_id'                  =>    $p_id,
            'p_category'            =>    $p_category,
            'p_status'              =>    $p_status,
            'p_value'               =>    $p_value,
            'p_updatedbyuserid'     =>    $this->session->userdata('UserID'),
        );

       print_r($this->SPModel->rp_equipments_update($data));
    }
    
    
    // update equipments with rfid
    
    
    public function RFIDCards()
    {
        $nav['title'] = "RFID Equipments";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('RFIDUpdate/RFID');
        // $this->load->view('RFIDUpdate/footer');
        $this->load->view('globaltemplate/footer');
    }
    
    
     public function RFIDajax()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M30400') === 'Y')
            { 
                $search = array(
                                // 'Branch'        => trim($this->input->post('Branch')),
                                'ID'            => trim($this->input->post('ID')),
                    

                                );
                
                $this->load->library('pagination');
                
                $limit = 5;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Adminc/AdminUpdateStatusindexCharger/');
                $config['total_rows'] = $this->AdminModel->StatusCharger($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['BatteryReports'] = $this->AdminModel->StatusCharger($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('A_CStatusedt/eqpbatajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    
    

    
    public function testing()
    {
      
        $this->load->view('testing/testing');
  
    }
}

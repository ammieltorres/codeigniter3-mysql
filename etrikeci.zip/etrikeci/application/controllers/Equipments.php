<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Equipments extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('EquipmentModel');
    }


    public function equipment()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
                $nav['title'] = "Equipments";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('Eqp_equipments/equipments');
                $this->load->view('Eqp_equipments/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    public function equipmentsajax($offset=null)
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
                    $search = array(
                        'ID'        => trim($this->input->post('ID')),
                        'CategoryCode'        => trim($this->input->post('CategoryCode')),
           
                        );
        
                $this->load->library('pagination');
                
                $limit = 15;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Equipments/equipmentsajax/');
                $config['total_rows'] = $this->EquipmentModel->Equipments($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['Equipments'] = $this->EquipmentModel->Equipments($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('Eqp_equipments/equipmentajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function addingequipments()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
                $data['CategoryCode'] =  $this->input->post("CategoryCode");
                $data['Category'] =  $this->input->post("Category");

                // $data['CategoryCode'] = '0001';

                $this->load->view('globaltemplate/header');

                $this->load->view('Eqp_equipments/addnewequipment', $data);
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function addnewequipment()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
        // echo 'success';

                $data = array(
                    'p_AED'                 => "ADD",
                    'p_ID'                  => $this->input->post('p_ID'),
                    'p_CategoryCode'        => $this->input->post('p_CategoryCode'),
                    'p_Category'            => $this->input->post('p_Category'),
                    'p_LName'               => $this->input->post('p_LName'),

                    'p_FName'               => $this->input->post('p_FName'),
                    'p_MName'               => $this->input->post('p_MName'),
                    'p_EStatus'             => ' ',
                    'p_EDateTime'           => ' ',
                    'p_CStatus'             => ' ',

                    'p_CDateTime'           => ' ',
                    'p_RStatus'             => ' ',
                    'p_RDateTime'           => ' ',
                    'p_RFIDCode'            => ' ',
                    'p_SystemID'            => ' ',
                    
                    'p_UserID'              => $this->session->userdata('UserID'),
                    'p_ULName'              => $this->session->userdata('LName'),
                    'p_UFName'              => $this->session->userdata('FName'),
                    'p_UMName'              => $this->session->userdata('MName'),
                    'p_UpdatedByUserID'     => $this->session->userdata('UserID'),

                    'p_UpdatedByULName'     => $this->session->userdata('LName'),
                    'p_UpdatedByUFName'     => $this->session->userdata('FName'),
                    'p_UpdatedByUMName'     => $this->session->userdata('MName')
                    
                    

                    // 'p_AED'                 => "ADD",
                    // 'p_ID'                  => 'asd222dadsd',
                    // 'p_CategoryCode'        => '0001',
                    // 'p_Category'            => 'adfgdfgdfsd',
                    // 'p_LName'               => 'adsadgdfgdfgsads',

                    // 'p_FName'               => 'dddfdgdd',
                    // 'p_MName'               => 'aadfgdfgdfaa',
                    // 'p_EStatus'             => ' ',
                    // 'p_EDateTime'           => ' ',
                    // 'p_CStatus'             => ' ',

                    // 'p_CDateTime'           => ' ',
                    // 'p_RStatus'             => ' ',
                    // 'p_RDateTime'           => ' ',
                    // 'p_RFIDCode'            => ' ',
                    // 'p_SystemID'            => ' ',
                    
                    // 'p_UserID'              => 'asd',
                    // 'p_ULName'              => 'asd',
                    // 'p_UFName'              => 'asd',
                    // 'p_UMName'              => 'asd',
                    // 'p_UpdatedByUserID'     => 'asd',

                    // 'p_UpdatedByULName'     => 'asd',
                    // 'p_UpdatedByUFName'     => 'asd',
                    // 'p_UpdatedByUMName'     => 'asd'
            
                );
                print_r($this->SPModel->sp_rp_equipments_aed($data));
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function editequipments()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
                $data['data'] = $this->input->post('getrec');
                $this->load->view('Eqp_equipments/editequipments', $data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
  
   
    }



    public function updateequipment()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40200') === 'Y')
            { 
                echo 'success';

                $data = array(
                    'p_AED'                 => "EDT",
                    'p_ID'                  => $this->input->post('p_ID'),
                    'p_CategoryCode'        => $this->input->post('p_CategoryCode'),
                    'p_Category'            => $this->input->post('p_Category'),
                    'p_LName'               => $this->input->post('p_LName'),

                    'p_FName'               => $this->input->post('p_FName'),
                    'p_MName'               => $this->input->post('p_MName'),
                    'p_EStatus'             => $this->input->post('p_EStatus'),
                    'p_EDateTime'           => $this->input->post('p_EDateTime'),
                    'p_CStatus'             => $this->input->post('p_CStatus'),

                    'p_CDateTime'           => $this->input->post('p_CDateTime'),
                    'p_RStatus'             => $this->input->post('p_RStatus'),
                    'p_RDateTime'           => $this->input->post('p_RDateTime'),
                    'p_RFIDCode'            => $this->input->post('p_RFIDCode'),
                    'p_SystemID'            => $this->input->post('p_SystemID'),
                    
                    'p_UserID'              => $this->input->post('UserID'),
                    'p_ULName'              => $this->input->post('LName'),
                    'p_UFName'              => $this->input->post('FName'),
                    'p_UMName'              => $this->input->post('MName'),
                    'p_UpdatedByUserID'     => $this->session->userdata('UserID'),

                    'p_UpdatedByULName'     => $this->session->userdata('LName'),
                    'p_UpdatedByUFName'     => $this->session->userdata('FName'),
                    'p_UpdatedByUMName'     => $this->session->userdata('MName')
                    

                    
                );
                print_r($this->SPModel->sp_rp_equipments_aed($data));
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

}
?>
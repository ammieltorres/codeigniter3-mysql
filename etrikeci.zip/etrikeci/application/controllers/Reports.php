<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH.'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Reports extends CI_Controller {




    public function __construct()
    {

    parent::__construct();
    $this->load->helper(array('url'));
    $this->load->database();
    $this->load->helper('form');
    $this->load->model('ReportsModel');
    $this->load->model('SPModel');
    }

    public function Swap()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20100') === 'Y')
            { 
                $nav['title'] = "Swapping Reports";
                
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('RP_Swapping/Report');
                $this->load->view('globaltemplate/footer');
                $this->load->view('RP_Swapping/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function SwappingIndex($offset=null)
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20100') === 'Y')
            { 
                    $search = array(
                        'Branch'        => trim($this->input->post('Branch')),
                        'UserID'        => trim($this->input->post('UserID')),
                        'DriverID'      => trim($this->input->post('DriverID')),
                        'UnitID'        => trim($this->input->post('UnitID')),

                        'BatteryID'     => trim($this->input->post('BatteryID')),
                        'SwapType'      => trim($this->input->post('SwapType')),
                        'DateStart'     => trim($this->input->post('DateStart')),
                        'DateEnd'       => trim($this->input->post('DateEnd')),
                        );
        
                $this->load->library('pagination');
                
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Reports/SwappingIndex/');
                $config['total_rows'] = $this->ReportsModel->SwappingReports($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['SwappingReports'] = $this->ReportsModel->SwappingReports($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('RP_Swapping/Reportsajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }




    public function exportSwapping()
    {     
        if($this->session->userdata('M20100') === 'Y')
        { 
            $datestart = date("m/d/Y", strtotime($this->input->post('DateStart')));
            $dateend = date("m/d/Y", strtotime($this->input->post('DateEnd')));

            $data = array(
                'p_unitid'      => trim($this->input->post('UnitID')),
                'p_batteryid'   => trim($this->input->post('BatteryID')),
                'p_driverid'    => trim($this->input->post('DriverID')),
                'p_swaptype'    => trim($this->input->post('SwapType')),
                'p_userid'      => trim($this->input->post('UserID')),
                'p_datetimes'   => $datestart,
                'p_datetimee'   => $dateend,
                'p_branchcode'  => '',
            );

            $Total = $this->SPModel->rp_swap_find($data);

            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="SwappingReports.xlsx"');
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            $sheet->setCellValue('A1','ReferenceCode');
            $sheet->setCellValue('B1','SwapType');
            $sheet->setCellValue('C1','DateTime');
            $sheet->setCellValue('D1','UnitID');
            $sheet->setCellValue('E1','BatteryID');
            $sheet->setCellValue('F1','DriverID');
            $sheet->setCellValue('G1','LDriver');
            $sheet->setCellValue('H1','FDriver');
            $sheet->setCellValue('I1','MDriver');
            $sheet->setCellValue('J1','UserID');
            $sheet->setCellValue('K1','LUser');
            $sheet->setCellValue('L1','FUser');
            $sheet->setCellValue('M1','MUser');
            $sheet->setCellValue('N1','BranchCode');
            $sheet->setCellValue('O1','Branch');
        

            $sn=2;
            foreach ($Total as $result) {
                
            $sheet->setCellValue('A'.$sn,$result->ReferenceCode);
            $sheet->setCellValue('B'.$sn,$result->SwapType);
            $sheet->setCellValue('C'.$sn,$result->DateTime);
            $sheet->setCellValue('D'.$sn,$result->UnitID);
            $sheet->setCellValue('E'.$sn,$result->BatteryID);
            $sheet->setCellValue('F'.$sn,$result->DriverID);
            $sheet->setCellValue('G'.$sn,$result->LDriver);
            $sheet->setCellValue('H'.$sn,$result->FDriver);
            $sheet->setCellValue('I'.$sn,$result->MDriver);
            $sheet->setCellValue('J'.$sn,$result->UserID);
            $sheet->setCellValue('K'.$sn,$result->LUser);
            $sheet->setCellValue('L'.$sn,$result->FUser);
            $sheet->setCellValue('M'.$sn,$result->MUser);
            $sheet->setCellValue('N'.$sn,$result->BranchCode);
            $sheet->setCellValue('O'.$sn,$result->Branch);

            $sn++;
            }

            $writer = new Xlsx($spreadsheet);
            $writer->save("php://output");

        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    



    //================================

    public function Battery()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20200') === 'Y')
            { 
                $nav['title'] = "Battery Reports";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('RP_Battery/Report');
                $this->load->view('RP_Battery/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function BatteryIndex($offset=null)
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20200') === 'Y')
            { 
                $search = array(
                                'Branch'        => trim($this->input->post('Branch')),
                                'UserID'     => trim($this->input->post('UserID')),
                                'BatteryID'       => trim($this->input->post('BatteryID')),
                                'ChargeType'          => trim($this->input->post('ChargeType')),

                                );
                
                $this->load->library('pagination');
                
                $limit = 5;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Reports/BatteryIndex/');
                $config['total_rows'] = $this->ReportsModel->BatteryReports($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['BatteryReports'] = $this->ReportsModel->BatteryReports($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('RP_Battery/Reportsajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    //====================================================================================
    //logs

    public function Logs()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20300') === 'Y')
            { 
                $nav['title'] = "Log Reports";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('RP_Logs/Report');
                $this->load->view('RP_Logs/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


    public function LogIndex($offset=null)
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M20300') === 'Y')
            { 
                $search = array(
                                'Branch'        => trim($this->input->post('Branch')),
                                'UserID'     => trim($this->input->post('UserID')),
                                'SwapType'       => trim($this->input->post('SwapType')),
                                'DateStart'       => trim($this->input->post('DateStart')),
                                'DateEnd'       => trim($this->input->post('DateEnd')),
                                'ItemCode'       => trim($this->input->post('ItemCode')),
                                'Category'       => trim($this->input->post('Category')),
                                

                                );
                
                $this->load->library('pagination');
                
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Reports/LogIndex/');
                $config['total_rows'] = $this->ReportsModel->rp_log($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['LogReports'] = $this->ReportsModel->rp_log($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('RP_Logs/Reportsajax',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function exportLogs()
    {            
        if($this->session->userdata('M20300') === 'Y')
        { 
            $datestart = date("m/d/Y", strtotime($this->input->post('DateStart')));
            $dateend = date("m/d/Y", strtotime($this->input->post('DateEnd')));
            $data = array(
                'p_itemcode' => trim($this->input->post('ItemCode')),
                'p_swaptype' => trim($this->input->post('SwapType')),
                'p_userid' => trim($this->input->post('UserID')),
                'p_datetimes' => $datestart,
                'p_datetimee' => $dateend,
                'p_branchcode' => '',
                'p_category' => trim($this->input->post('Category')),
            );
            $Total = $this->SPModel->sp_rp_log_find($data);

            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="LogsReports.xlsx"');
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            $sheet->setCellValue('A1','ReferenceCode');
            $sheet->setCellValue('B1','ReferenceCodeSwap');
            $sheet->setCellValue('C1','ItemCode');
            $sheet->setCellValue('D1','item');
            $sheet->setCellValue('E1','LDriver');
            $sheet->setCellValue('F1','FDriver');
            $sheet->setCellValue('G1','MDriver');
            $sheet->setCellValue('H1','SwapType');
            $sheet->setCellValue('I1','UserID');
            $sheet->setCellValue('J1','LUser');
            $sheet->setCellValue('K1','FUser');
            $sheet->setCellValue('L1','MUser');
            $sheet->setCellValue('M1','DateTimeStamp');
            $sheet->setCellValue('N1','BranchCode');
            $sheet->setCellValue('O1','Branch');
            $sheet->setCellValue('P1','CategoryCode');
            $sheet->setCellValue('Q1','Category');

            $sn=2;
            foreach ($Total as $result) {
                
            $sheet->setCellValue('A'.$sn,$result->ReferenceCode);
            $sheet->setCellValue('B'.$sn,$result->ReferenceCodeSwap);
            $sheet->setCellValue('C'.$sn,$result->ItemCode);
            $sheet->setCellValue('D'.$sn,$result->item);
            $sheet->setCellValue('E'.$sn,$result->LDriver);
            $sheet->setCellValue('F'.$sn,$result->FDriver);
            $sheet->setCellValue('G'.$sn,$result->MDriver);
            $sheet->setCellValue('H'.$sn,$result->SwapType);
            $sheet->setCellValue('I'.$sn,$result->UserID);
            $sheet->setCellValue('J'.$sn,$result->LUser);
            $sheet->setCellValue('K'.$sn,$result->FUser);
            $sheet->setCellValue('L'.$sn,$result->MUser);
            $sheet->setCellValue('M'.$sn,$result->DateTimeStamp);
            $sheet->setCellValue('N'.$sn,$result->BranchCode);
            $sheet->setCellValue('O'.$sn,$result->Branch);
            $sheet->setCellValue('P'.$sn,$result->CategoryCode);
            $sheet->setCellValue('Q'.$sn,$result->Category);

            $sn++;
            }

            $writer = new Xlsx($spreadsheet);
            $writer->save("php://output");
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }




public function R_logs()
{
    if($this->session->userdata('UserID') != '')
    { 
 
        $nav['title'] = "Repair Reports";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav',$nav);
      
        $this->load->view('RP_Replogs/Report');
        $this->load->view('globaltemplate/footer');

    }
    else
    {
    redirect($_SERVER['HTTP_REFERER']);
    }
}

public function Getapitabletest() 
{
    $this->db->order_by('id','desc'); 
    $this->db->limit(10);   

    $Equipments = $this->db->get('apitabletest');   
    $data = $Equipments->result_array();
    
    header("refresh: 5;");

    ?>
        <table class="table table-striped table-light">
            <thead>
                <tr>
                            <th>ID</th>
                            <th>RFID Value</th>
                            <th>Timestamp</th>
                </tr>
            </thead>
            <!-- content -->
            <tbody>
            </tr>
                <?php if(!empty($data))
                        {
                        foreach ($data as $row) 
                            {
                            ?>
                                <tr>
                                    <td><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['code'] ?></td>
                                    <td><?php echo $row['timestamp'] ?></td>
                                </tr>
                            <?php
                            }
                        } 
                        else
                        {
                        ?>
                            <div class="alert alert-info">
                                No Record Found.
                            </div>
                        <?php
                            }
                        ?>
            </tbody>
        </table>
    <?php
}







// ===================== Milege Report Summary ========================

public function mileagereport()
{
    if($this->session->userdata('UserID') != '')
    { 
        $nav['title'] = "Mileage Summary";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('RP_MileageReport/mileage');   
        $this->load->view('RP_MileageReport/footer');
        $this->load->view('globaltemplate/footer');
    }
    else
    {
    redirect($_SERVER['HTTP_REFERER']);
    }
}


public function MileageIndex($offset=null)
{
    if($this->session->userdata('UserID') != '')
    { 
        // if($this->session->userdata('M20200') === 'Y')
        // { 
            $search = array(
                            'Branch'        => trim($this->input->post('Branch')),
                            // 'UserID'     => trim($this->input->post('UserID')),
                            // 'BatteryID'       => trim($this->input->post('BatteryID')),
                            // 'ChargeType'          => trim($this->input->post('ChargeType')),

                            );
            
            $this->load->library('pagination');
            
            $limit = 5;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $config['base_url'] = site_url('Reports/MileageIndex/');
            $config['total_rows'] = $this->ReportsModel->MileageReports($limit, $offset, $search, $count=true);
            $config['per_page'] = $limit;
            $config['uri_segment'] = 3;
            $config['num_links'] = 3;
            $config['num_tag_open']         = '<li>';
            $config['num_tag_close']        = '</li>';
            $config['cur_tag_open']         = '<li><a href="" class="current_page">';
            $config['cur_tag_close']        = '</a></li>';
            $config['next_link']            = '>';
            $config['next_tag_open']        = '<li>';
            $config['next_tag_close']       = '</li>';
            $config['prev_link']            = '<';
            $config['prev_tag_open']        = '<li>';
            $config['prev_tag_close']       = '</li>';
            $config['first_link']           = '<<';
            $config['first_tag_open']       = '<li>';
            $config['first_tag_close']      = '</li>';
            $config['last_link']            = '>>';
            $config['last_tag_open']        = '<li>';
            $config['last_tag_close']       = '</li>';

            $this->pagination->initialize($config);

            $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
            $data['MileageReports'] = $this->ReportsModel->MileageReports($limit, $offset, $search, $count=false);
            $data['pagelinks'] = $this->pagination->create_links();

            // $this->load->view('templates/afteraddheader');
            $this->load->view('RP_MileageReport/mileageajax',$data);
        // }
        // else
        // {
        // redirect($_SERVER['HTTP_REFERER']);
        // }
    }
    else
    {
    redirect($_SERVER['HTTP_REFERER']);
    }
}
















}

?>



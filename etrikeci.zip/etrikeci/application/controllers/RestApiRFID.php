<?php
ob_start();

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
require APPPATH . 'libraries/Format.php';
use chriskacerguis\RestServer\RestController;







class RestApiRFID extends RestController {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->Model('ApiTestingModel');
        
    }
    
      public function RFID_get()
    {
            $val = $this->uri->segment(3);            
            $val1 = $this->uri->segment(4);
            $val2 = $this->uri->segment(5);
            // $val = $this->input->post('Code');
            date_default_timezone_set("Asia/Manila");
            $time =  Date('Y-m-d H:i:s');


            if($val)
            {
                
            $value = array(
                'code' => $val,
                'timestamp' => $time,
                
                );
            $value1 = array(
                'code' => $val1,
                'timestamp' => $time,
                
                );
            $value2 = array(
                'code' => $val2,
                'timestamp' => $time,
                
                );
            $code = $this->ApiTestingModel->Addapitabletest($value);
            $code1 = $this->ApiTestingModel->Addapitabletest($value1);
            $code2 = $this->ApiTestingModel->Addapitabletest($value2);
                if($code)
                {
                $this->response([
                    'Status'    => true,
                    'message'   => 'Code Inserted',
                    'Code'      => $code,
                    'Value'      => $val,
                    'Code'      => $code1,
                    'Value1'      => $val1,
                    'Code'      => $code2,
                    'Value2'      => $val2,
                    'time'      => $time,
                    ], RestController::HTTP_OK); 
                }
                else
                {
                $this->response([
                    'Status'    => false,
                    'message'   => 'Failed To Create Code',
                    ], RestController::HTTP_BAD_REQUEST); 
                }
            }
            else
            {
             $this->response([
                    'Status'    => false,
                    'message'   => 'Value are Required',
                    ], RestController::HTTP_BAD_REQUEST); 
            }
    }
    
    
    
    public function smartchargingapi_get()
    {
            $Status = $this->uri->segment(3);            
            $Voltage = $this->uri->segment(4);
            $Amp = $this->uri->segment(5);
            $watts = $this->uri->segment(6);
            
            $IDone = $this->uri->segment(7);
            $IDtwo = $this->uri->segment(8);
            $IDthree = $this->uri->segment(9);
            
            
            date_default_timezone_set("Asia/Manila");
            $time =  Date('Y-m-d H:i:s');


            if($Status && $Voltage && $Amp && $watts && $IDone && $IDtwo && $IDthree)
            {
                
            $value = array(
                'Status' => $Status,
                'Voltage' => $Voltage,
                'Amp' => $Amp,
                'watts' => $watts,
                
                'IDone' => $IDone,
                'IDtwo' => $IDtwo,
                'IDthree' => $IDthree,
                
                );
            // $code = $this->ApiTestingModel->Addapitabletest($value);

                if($code)
                {
                $this->response([
                    'Status'    => true,
                    'message'   => 'Code Inserted',
                    // 'Code'      => $code,
                    // 'Value'      => $val,
                    // 'Code'      => $code1,
                    // 'Value1'      => $val1,
                    // 'Code'      => $code2,
                    // 'Value2'      => $val2,
                    // 'time'      => $time,
                    ], RestController::HTTP_OK); 
                }
                else
                {
                $this->response([
                    'Status'    => false,
                    'message'   => 'Failed To Insert Data',
                    ], RestController::HTTP_BAD_REQUEST); 
                }
            }
            else
            {
             $this->response([
                    'Status'    => false,
                    'message'   => 'Value are Required',
                    ], RestController::HTTP_BAD_REQUEST); 
            }
    }
    
    
    
    public function RFID_post()
{
    $val = $this->input->post('Code');
    
    if ($val) {
        $value = array(
            'code' => $val,
        );
        
        $code = $this->ApiTestingModel->Addapitabletest($value);
        
        if ($code) {
            $this->response([
                'Status'    => true,
                'message'   => 'Code Inserted',
                'Code'      => $code,
                'Value'     => $val,
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'Status'    => false,
                'message'   => 'Failed To Create Code',
            ], RestController::HTTP_BAD_REQUEST);
        }
    } else {
        $this->response([
            'Status'    => false,
            'message'   => 'Code is Required',
        ], RestController::HTTP_BAD_REQUEST);
    }
}
    
    
    
    
    
    
}

?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class PrintCon extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('PrintModel');
    }



    public function printid()
    {       
        if($this->session->userdata('UserID') != '')
        { 
            $nav['title'] = 'Print';
            $this->load->view('globaltemplate/header');
            $this->load->view('globaltemplate/nav',$nav);
            $this->load->view('P_PrintQR/PrintQR');
            $this->load->view('globaltemplate/footer');
            $this->load->view('P_PrintQR/footer');
        }
        else
        {
            redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function PrintQRAjax($offset=null)
    {
        if($this->session->userdata('UserID') != '')
        { 
        
                    $search = array(
                        'CategoryCode'        => trim($this->input->post('Category')),
                        'ID'                    => trim($this->input->post('ID')),
                        );
        
                $this->load->library('pagination');
                
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('PrintCon/PrintQRAjax/');
                $config['total_rows'] = $this->PrintModel->equipmentsprintQR($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['SwappingReports'] = $this->PrintModel->equipmentsprintQR($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('P_PrintQR/Printajax',$data);
      
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
        public function printqrcodeBatch()
    {
         $CategoryCode = $this->input->post('Category');
        // $CategoryCode = '0001';
         $this->db->select('*');
         $this->db->where('CategoryCode',$CategoryCode);
        //  $this->db->limit(2);
         $Eqp = $this->db->get('equipments'); 

         $data['eqp'] = $Eqp->result_array();
        //  $this->load->view('globaltemplate/header');
        $this->load->view('P_PrintQRBatch/qrtest.php',$data); 
       
    }

    public function printqrcode()
    {
        $data['eqID'] = $this->input->post('eqID');
        $this->load->view('P_PrintQR/qrcoderesprint',$data);
        
    }




}   





?>

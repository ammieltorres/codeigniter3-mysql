
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Repair extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        
    }



    public function Repairs()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10400') === 'Y')
            { 
                $nav['title'] = "Repair";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('Rep_Repair/Scan');

                
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function query()
    {
        if($this->session->userdata('M10400') === 'Y')
        { 
            $query = $this->input->post('ID');
            $this->db->where('ID',$query);
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();

     
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    // echo $row['CategoryCode'];?><br><?php
                }
            }
            else
            {
                $Category = '';
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
            }

            if($Category)
            {
               
                //if unit categorycode = 0002
                if($Category ='0002')
                {
                    $data['result'] = $Equipments->result_array();
                    $this->load->view('Rep_Repair/submit',$data);
                }
                //if battery categorycode = 0003
                elseif($Category ='0003')
                {
                    $data['result'] = $Equipments->result_array();
                    $this->load->view('Rep_Repair/submit',$data);
                }
                // if charger categorycode = 0004
                elseif($Category ='0004')
                {
                    $data['result'] = $Equipments->result_array();
                    $this->load->view('Rep_Repair/submit',$data);
                }
                else
                {
                    ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?> item must be - UNIT | BATTERY 
                    </div>
                <?php
                }
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function RepairRecord()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10400') === 'Y')
            { 
                $data = array(
                'p_referencecode'       => ' ',
                'p_category'            => trim($this->input->post('p_category')),
                'p_itemid'              => trim($this->input->post('p_itemid')),
                'p_repairtype'          => trim($this->input->post('p_repairtype')),

                'p_userid'              => trim($this->session->userdata('UserID')),
                'p_luser'               => trim($this->session->userdata('LName')),

                'p_fuser'               => trim($this->session->userdata('FName')),
                'p_muser'               => trim($this->session->userdata('MName')),

                'p_branchcode'          => trim($this->session->userdata('BranchCode')),
                'p_branch'              => trim($this->session->userdata('Branch')),

                );

                $data['result'] = $this->SPModel->rp_repair_add($data);
                $this->load->view('Rep_Repair/ResultModal',$data);
          
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

}

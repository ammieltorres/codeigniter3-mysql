<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH.'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ImportData extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('ImportModel');
        // $this->load->model('SPModel');
        // $this->load->model('EquipmentModel');
        // $this->load->model('DashboardModel');
        // $this->load->model('ReportsModel');
        date_default_timezone_set('Asia/Manila');
    }
    
    
    public function importexdata()
    {
        if($this->session->userdata('UserID') != '')
        { 
                $nav['title'] = "Data Import";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('Import_BStatus/index');
                
                $this->load->view('globaltemplate/footer');
            
            
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    public function import()
    {
        
                $upload_file=$_FILES['upload_file']['name'];
            $extension=pathinfo($upload_file,PATHINFO_EXTENSION);
            if($extension=='csv')
            {
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            }
            else if($extension=='xls'){
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            }
            else
            {
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
                echo "xlsx";
                
            }
             $spreadsheet=$reader->load($_FILES['upload_file']['tmp_name']);
            $sheetdata=$spreadsheet->getActiveSheet()->toArray();
    // print_r($sheetdata);
            $sheetcount=count($sheetdata);

            if($sheetcount>1)
                {
                    for ($i=1; $i < $sheetcount; $i++)
                    {
                        $Day                        = $sheetdata[$i][0]; 
                        $UnitBattery                = $sheetdata[$i][1];
                        $Timestamp                  = $sheetdata[$i][2]; 
                        $ChargerDriver              = $sheetdata[$i][3];
                        $Name                       = $sheetdata[$i][4]; 
                         
                         
                        $CB                         = $sheetdata[$i][5]; 
                        $ChargingBoy                = $sheetdata[$i][6];
                        $Status                     = $sheetdata[$i][7];    
                        $DateTime                   = $sheetdata[$i][8]; 


  

                        
                        
                        $data=array(

                            'GS_Day'            =>  $Day,
                            'GS_Unit_Battery'   =>  $UnitBattery,
                            'GS_TimeStamp'      =>  $Timestamp,
                            'GS_Charger_Driver' =>  $ChargerDriver,
                            'GS_Name'           =>  $Name,
                            
                            'GS_CB'             =>  $CB,
                            'GS_ChargingBoy'    =>  $ChargingBoy,
                            'GS_Status'         =>  $Status,
                            'GS_DateTime'       =>  $DateTime,

                        );
                        
         
                        $delete = $UnitBattery.'|'. $Status.'|'. $DateTime;
                        
                        
                        $this->ImportModel->dlttemp($delete);
                        $re = $this->ImportModel->importtemp($data);
                       print_r($re);
                    }
     
                       if($sheetcount === $i)
                        {
                            
                            if($re)
                            {
                            echo  "<script type='text/javascript'>";
                            echo "alert('DATA HAVE BEEN PROCESSED');";
                            echo "window.close();";
                            echo "</script>";
                            }
                            else
                            {
                            echo  "<script type='text/javascript'>";
                            echo "alert('Error');";
                            echo "window.close();";
                            echo "</script>";
                            }

                        }
            }
    }
    
    
    public function processimporteddata()
    {
        $re = $this->ImportModel->SP_GS_FindEquipments_V2();
          if($re)
            {
            echo  "<script type='text/javascript'>";
            echo "alert('File Uploaded');";
            echo "window.close();";
            echo "</script>";
            }
            else
            {
            echo  "<script type='text/javascript'>";
            echo "alert('Error');";
            echo "window.close();";
            echo "</script>";
            }
    }
    
    public function importdatagsheetadd()
    {
        // $re = $this->ImportModel->SP_GS_FindEquipments_V2();
        
                $nav['title'] = "Data Import";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                // $this->load->view('Import_BGStatus/index');
        
    }
    
    
    
    
    public function importgsheet()
    {
        
            $upload_file=$_FILES['upload_file']['name'];
            $extension=pathinfo($upload_file,PATHINFO_EXTENSION);
            if($extension=='csv')
            {
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Csv();
            }
            else if($extension=='xls'){
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            }
            else
            {
                $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
                echo "xlsx";
                
            }
             $spreadsheet=$reader->load($_FILES['upload_file']['tmp_name']);
            $sheetdata=$spreadsheet->getActiveSheet()->toArray();
    // print_r($sheetdata);
            $sheetcount=count($sheetdata);

            if($sheetcount>1)
                {
                    for ($i=1; $i < $sheetcount; $i++)
                    {
                        $Day                        = $sheetdata[$i][0]; 
                        $UnitBattery                = $sheetdata[$i][1];
                        $Timestamp                  = $sheetdata[$i][2]; 



  

                        
                        
                        $data=array(

                            'GS_Day'            =>  $Day,
                            'GS_Unit_Battery'   =>  $UnitBattery,
                            'GS_TimeStamp'      =>  $Timestamp,
  

                        );
                        
         
                        $delete = $UnitBattery.'|'. $Status.'|'. $DateTime;
                        
                        
                        // $this->ImportModel->dlttemp($delete);
                        // $re = $this->ImportModel->importtemp($data);
                       print_r($re);
                    }
     
                       if($sheetcount === $i)
                        {
                            
                            if($re)
                            {
                            echo  "<script type='text/javascript'>";
                            echo "alert('DATA HAVE BEEN PROCESSED');";
                            echo "window.close();";
                            echo "</script>";
                            }
                            else
                            {
                            echo  "<script type='text/javascript'>";
                            echo "alert('Error');";
                            echo "window.close();";
                            echo "</script>";
                            }

                        }
            }
    }

    // ========================== import data new ==========================

    public function importreportrawdata()
    {
        
                $nav['title'] = "Data Import";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('Import_rawdata/index');
                $this->load->view('globaltemplate/footer');
        
    }
    
    public function importreportrawdataprocess()
    {
     
        date_default_timezone_set("Asia/Manila");
        $time =  Date('Y-m-d H:i:s');


        $upload_file=$_FILES['upload_file']['name'];
        $extension=pathinfo($upload_file,PATHINFO_EXTENSION);
        if($extension=='csv')
        {
            $reader= new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        }
        else if($extension=='xls'){
            $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xls();
        }
        else
        {
            $reader= new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            echo "xlsx";
            
        }
         $spreadsheet=$reader->load($_FILES['upload_file']['tmp_name']);
        $sheetdata=$spreadsheet->getActiveSheet()->toArray();
// print_r($sheetdata);
        $sheetcount=count($sheetdata);

        if($sheetcount>1)
            {
                for ($i=1; $i < $sheetcount; $i++)
                {
                    $GS_DateTime            = $sheetdata[$i][0]; 
                    $GS_Data                = $sheetdata[$i][1];
              
                    // echo $GS_DateTimef = date_format($GS_DateTime, "Y-m-d H:i:s");
                    
                    $data=array(

                        'GS_DateTime'       =>  $GS_DateTime,
                        'GS_Data'           =>  $GS_Data,
                        'GS_DateTimeStamp'  =>  $time,
                    );
                    
                    $re = $this->ImportModel->importreportrawdata($data);
                   print_r($re);
                }
                if($sheetcount === $i)
                {
                    echo  "<script type='text/javascript'>";
                    echo "alert('DATA HAVE BEEN IMPORTED');";
                    // echo "window.close();";
                    echo "</script>";

                }
                else
                {
                    echo  "<script type='text/javascript'>";
                    echo "alert('Error');";
                    // echo "window.close();";
                    echo "</script>";
                }
            }
    }


    

    // get data from google sheet


public function gsheetget()
{
    $api_url = "https://script.google.com/macros/s/AKfycbyuzqwK2smNLpWi3pXFRVk77RGFJAKvMzv02D8im_z8Bb90Tt7lncUc2a8JHjIUH0d-/exec";

    $client = curl_init($api_url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($client, CURLOPT_ENCODING, '');
    curl_setopt($client, CURLOPT_HEADER, 0);
    curl_setopt($client, CURLOPT_TIMEOUT, 0);
    curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'GET');
    // curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
    curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
   
     $response = curl_exec($client);
     
    $data =  json_decode($response);

    foreach($data as $row)
    {

        $datatime = str_replace("Z","0",$row->Data);
        $datatimeF = str_replace("T"," ",$datatime);
        $data = array(
            'p_DateTimeStamp' => $row->DateTimeStamp,
            'p_Data' => $datatimeF,
            // 'p_Data' => date_format($row->Data, "Y-m-d H:i:s"),
        );

        print_r($data);?> <br> <?php

        $re = $this->ImportModel->sp_GS_Report_RawData_Process_V2($data);
        // print_r($re);
    }

}

}


    
    
    

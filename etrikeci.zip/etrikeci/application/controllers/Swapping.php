
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Swapping extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('TSModel');
    }

    public function Swap()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10100') === 'Y')
            { 
                $nav['title'] = "Swapping";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('S_scan/Scan');

                
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function query()
    {            
        if($this->session->userdata('M10100') === 'Y')
        { 
            //textbox search
            // $query = '0000000001';
            $query = $this->input->post('ID');
            $this->db->where('ID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    // echo $row['CategoryCode'];?><br><?php
                }
            }
            else
            {
                $Category = '';
            }


            if($Category)
            {
                //if driver categorycode = 0001
                if($Category ==='0001')
                {
                    $_SESSION['DriverID'] = $ID;
                }
                //if unit categorycode = 0002
                elseif($Category ==='0002')
                {
                    $_SESSION['unitID'] = $ID;
                }
                //if battery categorycode = 0003
                elseif($Category ==='0003')
                {
                    $_SESSION['batteryID'] = $ID;
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                }
            }
            else
            {
                       ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php 
            }
  
        if(!empty($_SESSION['DriverID']))
        {
            $this->db->where('ID',$_SESSION['DriverID']);
            $DriverID = $this->db->get('equipments');   
            $data['DriverIDres'] = $DriverID->result_array();

            $this->load->view('S_information/Driver',$data);

        }
        if(!empty($_SESSION['unitID']))
        {
            $this->db->where('ID',$_SESSION['unitID']);
            $unitID = $this->db->get('equipments');   
            $data['UnitIDres'] = $unitID->result_array();

            $this->load->view('S_information/Unit',$data);

        }
        if(!empty($_SESSION['batteryID']))
        {
            $this->db->where('ID',$_SESSION['batteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_information/Battery',$data);

        }
       
        
        
        if (isset($_SESSION['DriverID']) && isset($_SESSION['unitID']) && isset($_SESSION['batteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                       echo $_SESSION['DriverID'].'-DriverID ,'. $_SESSION['unitID'] .'-unit ,'. $_SESSION['batteryID'] .'-battery'; 
                                ?>
                                    
                            </div>
                    <?php
            $this->load->view('S_information/type');
        }
        else
        {
                    if(isset($_SESSION['DriverID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['DriverID']; ?> scanned (Driver)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['unitID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['unitID']; ?> scanned (unit)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function AddSwappingRecord()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10000') === 'Y')
            { 
            $data = array(
                'v_referencecode'       => ' ',
                'p_swaptype'            => trim($this->input->post('p_swaptype')),
                'p_unitid'              => trim($this->input->post('p_unitid')),
                'p_batteryid'           => trim($this->input->post('p_batteryid')),
                'p_driverid'            => trim($this->input->post('p_driverid')),

                'p_ldriver'             => trim($this->input->post('p_ldriver')),
                'p_fdriver'             => trim($this->input->post('p_fdriver')),
                'p_mdriver'             => trim($this->input->post('p_mdriver')),

                'p_userid'              => trim($this->session->userdata('UserID') ),
                'p_luser'               => trim($this->session->userdata('LName') ),

                'p_fuser'               => trim($this->session->userdata('FName') ),
                'p_muser'               => trim($this->session->userdata('MName') ),

                'p_branchcode'          => trim($this->session->userdata('BranchCode') ),
                'p_branch'              => trim($this->session->userdata('Branch') ),

                );

                unset($_SESSION["DriverID"]);
                unset($_SESSION["unitID"]);
                unset($_SESSION["batteryID"]);

                $data['result'] = $this->SPModel->rp_swap_add($data);
                $this->load->view('S_information/ResultModal',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    public function removesession()
    {
        unset($_SESSION["DriverID"]);
        unset($_SESSION["unitID"]);
        unset($_SESSION["batteryID"]);
    }

    //===============================================
    // public function BatteryCharge()
    // {
    //     if($this->session->userdata('UserID') != '')
    //     { 

    //             $nav['title'] = "BatteryCharge";
    //             $this->load->view('globaltemplate/header');
    //             $this->load->view('globaltemplate/nav', $nav);
    //             // $this->load->view('S_Bscan/Scan');

                
    //             $this->load->view('globaltemplate/footer');

    //     }
    //     else
    //     {
    //     redirect($_SERVER['HTTP_REFERER']);
    //     }
    // }
    //=======================================================================================

    
    public function SwapM()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10200') === 'Y')
            { 
                $nav['title'] = "Swapping";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('S_scanM/Scan');

                
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


    public function queryM()
    {
        if($this->session->userdata('M10200') === 'Y')
        { 
            $query = $this->input->post('ID');
            $this->db->where('ID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    // echo $row['CategoryCode'];?><br><?php
                }
            }
            else
            {
                $Category = '';
            }


            if($Category)
            {
                //if driver categorycode = 0001
                if($Category ==='0001')
                {
                    $data['record'] = '1';
                    $_SESSION['DriverID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Driver';
                    $this->load->view('S_informationM/infomodal',$data);
                }
            //if unit categorycode = 0002
                elseif($Category ==='0002')
                {
                    $data['record'] = '1';
                    $_SESSION['unitID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Unit';
                    $this->load->view('S_informationM/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003')
                {
                    $data['record'] = '1';
                    $_SESSION['batteryID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Battery';
                    $this->load->view('S_informationM/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $ID;
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $data['Category'] = ' ';
                    $this->load->view('S_informationM/infomodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $this->input->post('ID');;
                    $data['Category'] = ' ';
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $this->load->view('S_informationM/infomodal',$data);
            }


        if(!empty($_SESSION['DriverID']))
        {
            $this->db->where('ID',$_SESSION['DriverID']);
            $DriverID = $this->db->get('equipments');   
            $data['DriverIDres'] = $DriverID->result_array();

            $this->load->view('S_informationM/Driver',$data);

        }
        if(!empty($_SESSION['unitID']))
        {
            $this->db->where('ID',$_SESSION['unitID']);
            $unitID = $this->db->get('equipments');   
            $data['UnitIDres'] = $unitID->result_array();

            $this->load->view('S_informationM/Unit',$data);

        }
        if(!empty($_SESSION['batteryID']))
        {
            $this->db->where('ID',$_SESSION['batteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationM/Battery',$data);

        }
       
        
        
        if (isset($_SESSION['DriverID']) && isset($_SESSION['unitID']) && isset($_SESSION['batteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['DriverID'].'-DriverID ,'. $_SESSION['unitID'] .'-unit ,'. $_SESSION['batteryID'] .'-battery'; 
                                ?>
                                    
                            </div>
                    <?php
            $this->load->view('S_informationM/type');
        }
        else
        {
                    if(isset($_SESSION['DriverID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['DriverID']; ?> scanned (Driver)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['unitID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['unitID']; ?> scanned (unit)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function testing()
    {
        $data = '1';
        $data2 = '1';
        $data3 = '1';
        if($data)
        {
            echo 'True';
        }
        else
        {
            echo 'False';
        }
        if($data & $data2 & $data3)
        {
            echo 'a';
        }
    }

    public function apitesting_post()
    {
        // $user_id = 'gelo';
   
        // $this->load->library("JWT");
        // $key = 'tokkenid';

        
        // $username = 'u12345';
        // $password = 'p12345';
   
        // $CONSUMER_TTL = 86400;
        // $data =  $this->jwt->encode(array(
        //   'username'=>$username,
        //   'password'=>$password,
        // //   'userid'=>$user_id,
        // //   'issuedAt'=>date(DATE_ISO8601, strtotime("now")),
        // //   'ttl'=>$CONSUMER_TTL
        // ), $key);

        // // $data ="eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzM4NCJ9.eyJUb2tlbiI6IjEyMyJ9.ebp-LcCdLq0Q8qN04cAvM9nNFmvPPM7MICYstkztLkkem7oPJn-7YZEVW_j-Drx3";
        // print_r($this->jwt->decode($data, $key, $verify = true)); 
       
     
        // print_r(json_decode(file_get_contents("php://input")));
        // print_r(file_get_contents("php://input"));
 $query = json_decode(file_get_contents("php://input"), true);

        // // print_r($data);
        // $Patientinfo = $data['Patient-Info'];
        // $Auth = $data['Auth'];
        // // print_r($dataq['name']);
        // $Authvals =($data['Auth']);

        // echo $Patientinfo['LastName'];?><br><?php
        // echo $Patientinfo['FirstName'];?><br><?php
        // echo $Patientinfo['MiddleName'];?><br><?php

        

        // echo $Authvals['TokkenID'];?><br><?php
        // echo $Authvals['Username'];?><br><?php
        // echo $Authvals['password'];?><br><?php

        // echo json_encode($data);

        // echo $dataj = json_encode($data);

        // print_r($query);
        $this->db->select('ID');
        $this->db->select('Category');
        $this->db->where('ID',$query['name']);
        $Equipments = $this->db->get('equipments');   
        $data = $Equipments->result_array();
        echo $data = json_encode($data);

   
    }
    
    public function passparams()
    {
            $data = array(
                "Patient-Info" => array(
            
                    "LastName" => 'Torres',
                    "FirstName" => 'Ammiel Angelo',
                    "MiddleName" => 'Ronquillo',
                ),
                "Auth" => array(
            
                    "TokkenID" => '123123123',
                    "Username" => 'gelo',
                    "password" => 'gelo',
                ),
            );
            $dataj = json_encode($data);
            // $api_url = "http://localhost:8080/etrike/Swapping/apitesting_post";
            $api_url = "https://aenterprise.biz/etrike/Swapping/apitesting_post";
            $client = curl_init($api_url);
            
            curl_setopt($client, CURLOPT_POST, true);
            curl_setopt($client, CURLOPT_POSTFIELDS, $dataj);
      
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
           
            $response = curl_exec($client);
           
            echo $response;
           
            curl_close($client);
           
            $result = json_decode($response);
        
    }

    public function gettoken()
    {
 
        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $this->db->select('*');
        $this->db->limit('1');
        $token = $this->db->get('sys_token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TaccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                $secretkey = 'bcea22916410433db0233991acd5e623';
        }
        

        $params = array(
            'app_key' => $TappKey,
            'expires_in' => 7200,
            'format' => 'json',
            'method' => 'jimi.oauth.token.refresh',
            'sign_method' => 'md5',
            'timestamp' => $timestamp,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'v' => '0.9',
        );
        ksort($params);

        $signVar = "";
        foreach ($params as $key => $value) {$signVar .= $key . $value;}
        $signVarSecret = $secretkey . $signVar . $secretkey;
        $sign = strtoupper(md5($signVarSecret));
        $data = array(
                    "timestamp" => $timestamp,
                    "app_key" => $TappKey,
                    "sign_method" => 'md5',
                    "sign" => $sign,
                    "v" => '0.9',
                    "format" => 'json',
                    "user_id" => 'GerWeiss',
                    "user_pwd_md5" => 'a5aac79a15425e28acafe27c3075fabc',
                    "expires_in" => '7200',
                    'method' => 'jimi.oauth.token.get',
              
            );
            $api_url = "https://hk-open.tracksolidpro.com/route/rest";
            $client = curl_init($api_url);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($data));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
           
            curl_close($client);
            $decode = json_decode($response);

            if(empty($decode->code))
            {
                echo  $p_TappKey          =  $decode->result->appKey;
                $p_Taccount         =  $decode->result->account;
                $p_TAccessToken     =  $decode->result->accessToken;
                $p_TrefreshToken    =  $decode->result->refreshToken;
                $p_TexpiresIn       =  $decode->result->expiresIn;
                $p_Ttime            =  $decode->result->time;
            
            
                $token = array(
    
                    "p_AED"             => 'EDT',
                    "p_TappKey"         => $p_TappKey,
                    "p_Taccount"        => $p_Taccount,
                    "p_TAccessToken"    => $p_TAccessToken,
                    "p_TrefreshToken"   => $p_TrefreshToken,
                    "p_TexpiresIn"      => $p_TexpiresIn,
                    "p_Ttime"           => $p_Ttime,
                );
        
                $this->TSModel->sys_Token_AED($token);
                
            }
            else
            {
                echo $decode->code;
                ?><br><?php
                echo $decode->message;
            }
        
  
    }


    public function refreshtoken()
    {

        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $this->db->select('*');
        $this->db->limit('1');
        $token = $this->db->get('sys_token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TaccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                $secretkey = 'bcea22916410433db0233991acd5e623';
        }
        

        $params = array(
            'app_key' => $TappKey,
            'expires_in' => 7200,
            'format' => 'json',
            'method' => 'jimi.oauth.token.refresh',
            'sign_method' => 'md5',
            'timestamp' => $timestamp,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'v' => '0.9',
       
        );
        ksort($params);

        $signVar = "";
        foreach ($params as $key => $value) {$signVar .= $key . $value;}
        $signVarSecret = $secretkey . $signVar . $secretkey;
        $sign = strtoupper(md5($signVarSecret));


        $params1 = array(
            'timestamp' => $timestamp,
            'app_key' => $TappKey,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign' => $sign,
            'sign_method' => 'md5',
            'expires_in' => 7200,
            'method' => 'jimi.oauth.token.refresh',
            'access_token' => $TaccessToken ,
            'refresh_token' => $TrefreshToken,
       
        );
 
            // $dataj = json_encode($data);
            $api_url = "https://hk-open.tracksolidpro.com/route/rest";
            // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
            $client = curl_init($api_url);
            // curl_setopt($client, CURLOPT_URL, APP_URL);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            // curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            // curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params1));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
           
            // echo $response;
           
            curl_close($client);
           
            $decode = json_decode($response);

           echo  $p_TappKey          =  $decode->result->appKey;
            $p_Taccount         =  $decode->result->account;
            $p_TAccessToken     =  $decode->result->accessToken;
            $p_TrefreshToken    =  $decode->result->refreshToken;
            $p_TexpiresIn       =  $decode->result->expiresIn;
            $p_Ttime            =  $decode->result->time;
        
        
            $token = array(
        
                "p_AED"             => 'EDT',
                "p_TappKey"         => $p_TappKey,
                "p_Taccount"        => $p_Taccount,
                "p_TAccessToken"    => $p_TAccessToken,
                "p_TrefreshToken"   => $p_TrefreshToken,
                "p_TexpiresIn"      => $p_TexpiresIn,
                "p_Ttime"           => $p_Ttime,
            );


            // echo  date('Y-m-d H:i:s', time());
    }



    public function getdevice()
    {
        
        



        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();


        $params = array(
            'timestamp' => $timestamp,
            'app_key' => '8FB345B8693CCD002B61020E9A0B42BC',
            'user_id' => 'GerWeiss',
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 3600,
            'method' => 'jimi.user.device.location.list',
            'imei' => '351742101136267',
            'access_token' => 'c70fc89089529ea8eceb7b2701d36ccf',
            'target' => 'GerWeiss'
        );


            // $dataj = json_encode($data);
            $api_url = "https://hk-open.tracksolidpro.com/route/rest";
            // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
            $client = curl_init($api_url);
            // curl_setopt($client, CURLOPT_URL, APP_URL);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
           
            // echo $response;

            $data = json_decode($response);
            $query = json_decode(file_get_contents("php://input"), true);
            // echo $data[0];

            // print_r($data);
            $value = reset($data);
            next($data);
            $info = (next($data));

            // print_r(array($info)[0]) ;
            foreach($info as $row)
            {
                echo 'imei';
                ?><br><?php
                echo $row->imei;
                ?><br><?php

                echo 'status';
                ?><br><?php
                // echo $row->status;
                if($row->status)
                {
                    echo 'active';
                }
                else
                {
                    echo 'inactive';
                }
                ?><br><?php
                

                echo 'deviceName';
                ?><br><?php
                echo $row->deviceName;
                ?><br><?php


    
                echo 'powerValue';
                ?><br><?php
                if($row->powerValue)
                {
                    echo $row->powerValue;
                }
                else
                {
                    echo 'NULL';
                }
                ?><br><?php
                ?><br><?php
            }
            // echo array_values($data)[0];
    }


public function tsgetdevice()
{

    // appKey":"8FB345B8693CCD002B61020E9A0B42BC",
    // "account":"GerWeiss",
    // "accessToken":"c70fc89089529ea8eceb7b2701d36ccf",
    // "refreshToken":"3c0a4c3b44f9f0bdf2545312ce320a59",
    // "expiresIn":7200,
    // "time":"2023-10-15 07:42:12"

    $this->db->select('*');
    $this->db->limit('1');
    $token = $this->db->get('sys_token'); 
    $tokendata =  $token->result_array();

   foreach($tokendata as $row)
   {
        $TappKey        = $row['TappKey'];
        $Taccount       = $row['Taccount'];
        $TaccessToken   = $row['TaccessToken'];
        $TrefreshToken  = $row['TrefreshToken'];
        $TexpiresIn     = $row['TexpiresIn'];
        
   }



    date_default_timezone_set('UTC');
    $timestamp = date('Y-m-d H:i:s', time());
    $curl = curl_init();


    $params = array(
        'timestamp' => $timestamp,
        'app_key' => $TappKey,
        'user_id' => $Taccount,
        'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
        'format' => 'json',
        'v' => '0.9',
        'sign_method' => 'md5',
        'expires_in' => 3600,
        'method' => 'jimi.user.device.location.list',
        // 'imei' => '351742101136267',
        'access_token' => $TaccessToken,
        'target' => 'GerWeiss'
    );

    
        // $dataj = json_encode($data);
        // $api_url = "http://open.10000track.com/route/rest";
        $api_url = "https://hk-open.tracksolidpro.com/route/rest";
        // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
        $client = curl_init($api_url);
        // curl_setopt($client, CURLOPT_URL, APP_URL);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($client, CURLOPT_ENCODING, '');
        curl_setopt($client, CURLOPT_HEADER, 0);
        curl_setopt($client, CURLOPT_TIMEOUT, 0);
        curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
        curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
       
        $response = curl_exec($client);
       
        // echo $response;

        $data = json_decode($response);

        // print_r($data);
        $array = json_decode(json_encode($data), true);


 
        $result = [];
        foreach($array as $key => $arrVal) {
           if(!in_array($arrVal, $result)){
               array_push($result, $arrVal);
           }
        }
        if($result[0] == '1004')
        {
            echo 'renew';
        }
        else
        {
            $value = reset($data);
            next($data);
            $info = (next($data));
            // print_r($data);
            foreach($info as $row)
            {
                echo $row->imei; ?> <br><?php
                echo $row->powerValue; ?> <br><?php
                
            }
        }
    //    echo var_dump($data);
       

        // echo $data[0];
}


    public function apitest()
    {

        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $params = array(
            'timestamp' => $timestamp,
            'app_key' => '8FB345B8693CCD002B61020E9A0B42BC',
            'user_id' => 'GerWeiss',
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 7200,
            'method' => 'jimi.user.child.list',
            'access_token' => '9a01233fe56a77c397dc95dd266fca2d',
            'target' => 'GerWeiss'
        );
        
        ksort($params);$signVar = "";foreach ($params as $key => $value) {$signVar .= $key . $value;}
        $signVarSecret = 'bcea22916410433db0233991acd5e623' . $signVar . 'bcea22916410433db0233991acd5e623';$sign = strtoupper(md5($signVarSecret));
        $params['sign'] = $sign;
        
        
        $response = $this->SPModel->curlExecute(APP_URL, 'POST', $params);
        echo "<pre>" . print_r($response,1) . "</pre>";
    }





public function testarray()
{
    $data = '{"code":109,"message":"success","result":{"appKey":"8FB345B8693CCD002B61020E9A0B42BC","account":"GerWeiss","accessToken":"f3125fcb9e6afdbb7c466a18983b4db4","refreshToken":"64d7e32cdaef3fa127ea87551734c66b","expiresIn":7200,"time":"2023-10-15 11:02:55"},"data":null}';
    $data1 = array(
        'code'=> '0',
        'message' =>  'success',

        "result" => array(
            
            "appKey" => '8FB345B8693CCD002B61020E9A0B42BC',
            "account" => 'GerWeiss',
            "accessToken" => 'f3125fcb9e6afdbb7c466a18983b4db4',
            "refreshToken" => '64d7e32cdaef3fa127ea87551734c66b',
            "expiresIn" => '7200',
            "time" => '2023-10-15 11:02:55',
        ),
        'data' =>  'null',
    );
    
    $json =  json_encode($data1);
    $decode = json_decode($json);

  
    if(empty($decode->code))
    {
        $p_TappKey          =  $decode->result->appKey;
        $p_Taccount         =  $decode->result->account;
        $p_TAccessToken     =  $decode->result->accessToken;
        $p_TrefreshToken    =  $decode->result->refreshToken;
        $p_TexpiresIn       =  $decode->result->expiresIn;
        $p_Ttime            =  $decode->result->time;
    
    
        $token = array(
    
            "p_AED"             => 'EDT',
            "p_TappKey"         => $p_TappKey,
            "p_Taccount"        => $p_Taccount,
            "p_TAccessToken"    => $p_TAccessToken,
            "p_TrefreshToken"   => $p_TrefreshToken,
            "p_TexpiresIn"      => $p_TexpiresIn,
            "p_Ttime"           => $p_Ttime,
        );

        $this->TSModel->sys_Token_AED($token);
    }
    else
    {
        echo $decode->code;
        ?><br><?php
        echo $decode->message;
    }


}

















































    public function saveattendace()
    {
        $data = array(
            "LastName" => $this->post->input('LName'),
            "FirstName" => $this->post->input('FName'),
            "MiddleName" => $this->post->input('MName'),
        );
        $return =  $this->model->saveattendace($data);
        if($return)
        {
         echo json_encode($return);
        }
    }




    public function gettoken1()
    {
                $data = array(
                "Patient-Info" => array(
            
                    "LastName" => 'Torres',
                    "FirstName" => 'Ammiel Angelo',
                    "MiddleName" => 'Ronquillo',
                ),
                "Auth" => array(
            
                    "TokkenID" => '123123123',
                    "Username" => 'gelo',
                    "password" => 'gelo',
                ),
            );
            $dataj = json_encode($data);
            $api_url = "http://localhost:8080/etrike/Swapping/saveattendance";
            // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
            $client = curl_init($api_url);
            
            curl_setopt($client, CURLOPT_POST, true);
            curl_setopt($client, CURLOPT_POSTFIELDS, $dataj);
      
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
           
            $response = curl_exec($client);
           
            echo $response;
           
            curl_close($client);
           
            $result = json_decode($response);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}





<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Charging extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
    }


    
   public function BatteryCharge()
   {    
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10300') === 'Y')
            { 
               $nav['title'] = "Charge";
               $this->load->view('globaltemplate/header');
               $this->load->view('globaltemplate/nav', $nav);
               $this->load->view('C_Charge/Scan');               
               $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
       }
       else
       {
       redirect($_SERVER['HTTP_REFERER']);
       }
   }




   public function query()
    {
        if($this->session->userdata('M10300') === 'Y')
        { 
            $query = $this->input->post('ID');
            $this->db->where('ID',$query);
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
     
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                }
            }
            else
            {
                $Category = '';
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
            }

            if($Category)
            {
                //if battery categorycode = 0003
                if($Category ==='0003')
                {
                    $_SESSION['C_batteryID'] = $ID;
                }
                //if charger categorycode = 0004
                if($Category ==='0004')
                {
                    $_SESSION['C_chargerID'] = $ID;
                }
                if(!empty($_SESSION['C_batteryID']))
                {
                    $this->db->where('ID',$_SESSION['C_batteryID']);
                    $C_batteryID = $this->db->get('equipments');   
                    $data['C_batteryIDres'] = $C_batteryID->result_array();
        
                    $this->load->view('C_Charge/Battery',$data);

                }
                if(!empty($_SESSION['C_chargerID']))
                {
                    $this->db->where('ID',$_SESSION['C_chargerID']);
                    $DriverID = $this->db->get('equipments');   
                    $data['C_chargerIDres'] = $DriverID->result_array();
        
                    $this->load->view('C_Charge/Charger',$data);

                }
                if (isset($_SESSION['C_batteryID']) && isset($_SESSION['C_chargerID']))
                {
                    ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['C_batteryID'].'- Battery ,'. $_SESSION['C_chargerID'] .'- Charger'; 
                                ?>
                                    
                            </div>
                    <?php
                    $this->load->view('C_Charge/submit');
                }
                else
                {
                    if(isset($_SESSION['C_batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['C_batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
                    if(isset($_SESSION['C_chargerID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['C_chargerID']; ?> scanned (Charger)
                            </div>
                        <?php
                    
                    }
                }

            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }

    }

    public function ChargingRecord()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10300') === 'Y')
            { 
                $data = array(
                'v_referencecode'       => ' ',
                'p_chargetype'          => trim($this->input->post('p_chargetype')),
                'p_batteryid'           => trim($this->input->post('p_batteryid')),
                'p_chargerid'           => trim($this->input->post('p_chargerid')),
           



                'p_userid'              => trim($this->session->userdata('UserID') ),
                'p_luser'               => trim($this->session->userdata('LName') ),

                'p_fuser'               => trim($this->session->userdata('FName') ),
                'p_muser'               => trim($this->session->userdata('MName') ),

                'p_branchcode'          => trim($this->session->userdata('BranchCode') ),
                'p_branch'              => trim($this->session->userdata('Branch') ),
                // 'v_referencecode'       => ' ',
                // 'p_swaptype'            => 'SWAP IN',
                // 'p_unitid'              => 'TO2',
                // 'p_batteryid'           => 'B201',
                // 'p_driverid'            => '0000000001',

                // 'p_ldriver'             => 'TORRES',
                // 'p_fdriver'             => 'AMMIEL ANGELO',
                // 'p_mdriver'             => 'RONQUILLO',
                // 'p_userid'              => 'GELO',
                // 'p_luser'               => 'TORRES',

                // 'p_fuser'               => 'AMMIEL ANGELO',
                // 'p_muser'               => 'RONQUILLO',

                // 'p_branchcode'               => '0001',
                // 'p_branch'               => 'Boracay',
                     );

                    //  unset($_SESSION["batteryID"]);

                $data['result'] = $this->SPModel->rp_charge_add($data);
                $this->load->view('C_Charge/ResultModal',$data);

            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }

        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    public function removesession()
    {
        unset($_SESSION["C_batteryID"]);
        unset($_SESSION["C_chargerID"]);
   
    }

}

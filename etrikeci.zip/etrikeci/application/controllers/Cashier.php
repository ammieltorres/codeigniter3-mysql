
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cashier extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('CashierModel');

    }
    
    
    public function paiddriver()
    {
        $nav['title'] = "Checkinout";
        $this->load->view('globaltemplate/header');
        $this->load->view("globaltemplate/nav", $nav);
        $this->load->view("CH_Paiddriver/PDriver");
        $this->load->view("CH_Paiddriver/PDriverfooter");
         $this->load->view("globaltemplate/footer");
    }
    
    
    public function paiddriverindex()
    {
        if($this->session->userdata('UserID') != '')
        {  
            // if($this->session->userdata('M30100') === 'Y')
            // { 
      
                $search = array(
                                // 'Branch'        => trim($this->input->post('Branch')),
                                'USERID'            => trim($this->input->post('USERID')),
                    

                                );
                
                $this->load->library('pagination');
                
                $limit = 20;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                $config['base_url'] = site_url('Cashier/paiddriverindex/');
                $config['total_rows'] = $this->CashierModel->DriverPayment($limit, $offset, $search, $count=true);
                $config['per_page'] = $limit;
                $config['uri_segment'] = 3;
                $config['num_links'] = 3;
                $config['num_tag_open']         = '<li>';
                $config['num_tag_close']        = '</li>';
                $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                $config['cur_tag_close']        = '</a></li>';
                $config['next_link']            = '>';
                $config['next_tag_open']        = '<li>';
                $config['next_tag_close']       = '</li>';
                $config['prev_link']            = '<';
                $config['prev_tag_open']        = '<li>';
                $config['prev_tag_close']       = '</li>';
                $config['first_link']           = '<<';
                $config['first_tag_open']       = '<li>';
                $config['first_tag_close']      = '</li>';
                $config['last_link']            = '>>';
                $config['last_tag_open']        = '<li>';
                $config['last_tag_close']       = '</li>';

                $this->pagination->initialize($config);

                $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                $data['PaidDrivers'] = $this->CashierModel->DriverPayment($limit, $offset, $search, $count=false);
                $data['pagelinks'] = $this->pagination->create_links();

                // $this->load->view('templates/afteraddheader');
                $this->load->view('CH_Paiddriver/PDriverAjax',$data);
        //     }
        //     else
        //     {
        //         redirect($_SERVER['HTTP_REFERER']);
        //     }
         }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    public function CH_CHECKINOUT_ADD()
    {
        

         // if($this->input->post('jsondata'))
        // {
            // echo $this->input->post('jsondata');
        
            //   $decode =  json_decode(trim($this->input->post('jsondata')));
            //         foreach($decode as $row)
            //         {
                        $data= array(
                            'p_USERID'              => '1',
                            'p_CHECKTIME'           => '1',
                            'p_CHECKTYPE'           => '1',
                            'p_VERIFYCODE'          => '1',
                            'p_SENSORID'            => '1',
                            'p_Memoinfo'            => '1',
                            'p_WorkCode'            => '1',
                            'p_sn'                  => '1',
                            'p_UserExtFmt'          => '1',
                            );
                            
                              $this->CashierModel->CH_CHECKINOUT_ADD($data);
                              
                            //   print_r($data);
                    // }
        
        
        
        
        

        
        
        //   foreach ($rows as $row) 
        //   {
        //         $data= array(
        //             'p_USERID'              => $row['USERID'],
        //             'p_CHECKTIME'           => $row['CHECKTIME'],
        //             'p_CHECKTYPE'           => $row['CHECKTYPE'],
        //             'p_VERIFYCODE'          => $row['VERIFYCODE'],
        //             'p_SENSORID'            => $row['SENSORID'],
        //             'p_Memoinfo'            => $row['Memoinfo'],
        //             'p_WorkCode'            => $row['WorkCode'],
        //             'p_sn'                  => $row['sn'],
        //             'p_UserExtFmt'          => $row['UserExtFmt'],
        //             );
                    
              

        //              $this->CashierModel->CH_CHECKINOUT_ADD($data);
        //   }
                
                
        // $data = array(
        //     'p_USERID'              => trim($this->input->post('jsondata')),
        //     'p_CHECKTIME'           => trim($this->input->post('p_CHECKTIME')),
        //     'p_CHECKTYPE'           => trim($this->input->post('p_CHECKTYPE')),
        //     'p_VERIFYCODE'          => trim($this->input->post('p_VERIFYCODE')),
        //     'TransactionCode'       => trim($this->input->post('p_SENSORID')),
        //     'p_SENSORID'            => trim($this->input->post('p_Memoinfo')),
        //     'p_WorkCode'            => trim($this->input->post('p_WorkCode')),
        //     'p_sn'                  => trim($this->input->post('p_sn')),
        //     'p_UserExtFmt'          => trim($this->input->post('p_UserExtFmt')),
        //     );
        
            //     $data = array(
            // 'p_USERID'              => '1230',
            // 'p_CHECKTIME'           => '05-19-2024 17:55',
            // 'p_CHECKTYPE'           => '1',
            // 'p_VERIFYCODE'          => '1',
            // 'TransactionCode'       => '1',
            // 'p_SENSORID'            => '1',
            // 'p_WorkCode'            => '1',
            // 'p_sn'                  => '1',
            // 'p_UserExtFmt'          => '1',
            // );
            
            
            
            
        // $this->CashierModel->CH_CHECKINOUT_ADD($data);
        
        // }
    }
    
    
    public function testing()
    {
        

           // $api_url = "http://open.10000track.com/route/rest";
            $api_url = "http://103.5.63.90:6060/GerAPI/Chboraapi/QueryApi";
            // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
            $client = curl_init($api_url);
            // curl_setopt($client, CURLOPT_URL, APP_URL);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
    
            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
            
            
            $res = json_decode($response);
            
            if($res)
            {
                foreach($res as $row)
                {
                $datetimecheck =  date_create($row->CHECKTIME);
                $checktime =  date_format($datetimecheck,"m-d-Y H:i:s");
                $data = array(
                'p_USERID'        => $row->USERID,
                'p_CHECKTIME'     => $checktime,
                'p_CHECKTYPE'     => $row->CHECKTYPE,
                'p_VERIFYCODE'    => $row->VERIFYCODE,
                'TransactionCode' => $row->MEMOINFO,
                'p_SENSORID'      => $row->SENSORID,
                'p_WorkCode'      => $row->WORKCODE,
                'p_sn'            => $row->sn,
                'p_UserExtFmt'    => $row->UserExtFmt,
                        );
                
                
                
            //     $data = array(
            // 'p_USERID'              => '1230',
            // 'p_CHECKTIME'           => '05-19-2024 17:55',
            // 'p_CHECKTYPE'           => '1',
            // 'p_VERIFYCODE'          => '1',
            // 'TransactionCode'       => '1',
            // 'p_SENSORID'            => '1',
            // 'p_WorkCode'            => '1',
            // 'p_sn'                  => '1',
            // 'p_UserExtFmt'          => '1',
            // );
            
            
            
            
                        
                $datasp =  $this->CashierModel->CH_CHECKINOUT_ADD($data);
                
                print_r($datasp);
                }
            }
    }

}



<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('SettingsModel');
        $this->load->model('DropDownModel');
        $this->load->library('encryption');
    }


    public function UserSettings()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40100') === 'Y')
            { 
                $nav['title'] = "User Settings";
                $data['Branch'] = $this->DropDownModel->fs_branch();
                $data['Branchadd'] = $this->DropDownModel->fs_branch();
          

                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('FS_Usersettings/UserSettings',$data);
                $this->load->view('FS_Usersettings/footer');
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    

    public function UserSettingsIndex()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40100') === 'Y')
            { 
     
                    $search = array(
     
                        'UserID'           => trim($this->input->post('UserID')),
                        'LName'            => trim($this->input->post('LName')),
                        'FName'            => trim($this->input->post('FName')),
                        'MName'            => trim($this->input->post('MName')),
                        'BranchCode'       => trim($this->input->post('BranchCode'))
            

                        );
    
                    $this->load->library('pagination');
                    
                    $limit = 5;
                    $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

                    $config['base_url'] = site_url('Settings/UserSettingsIndex/');
                    $config['total_rows'] = $this->SettingsModel->UserSettings($limit, $offset, $search, $count=true);
                    $config['per_page'] = $limit;
                    $config['uri_segment'] = 3;
                    $config['num_links'] = 3;
                    $config['num_tag_open']         = '<li>';
                    $config['num_tag_close']        = '</li>';
                    $config['cur_tag_open']         = '<li><a href="" class="current_page">';
                    $config['cur_tag_close']        = '</a></li>';
                    $config['next_link']            = '>';
                    $config['next_tag_open']        = '<li>';
                    $config['next_tag_close']       = '</li>';
                    $config['prev_link']            = '<';
                    $config['prev_tag_open']        = '<li>';
                    $config['prev_tag_close']       = '</li>';
                    $config['first_link']           = '<<';
                    $config['first_tag_open']       = '<li>';
                    $config['first_tag_close']      = '</li>';
                    $config['last_link']            = '>>';
                    $config['last_tag_open']        = '<li>';
                    $config['last_tag_close']       = '</li>';

                    $this->pagination->initialize($config);

                    $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
                    $data['BatteryReports'] = $this->SettingsModel->UserSettings($limit, $offset, $search, $count=false);
                    $data['pagelinks'] = $this->pagination->create_links();

                    // $this->load->view('templates/afteraddheader');
                    $this->load->view('FS_Usersettings/UserSettingsAjax',$data);


            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function UserAcess()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40100') === 'Y')
            { 
                $UserID =  trim($this->input->post('UserID'));

                $this->db->where('UserID',$UserID);
                $fs_users = $this->db->get('fs_users');   
                $data['User'] = $fs_users->result_array();
                $data['Branchedt'] = $this->DropDownModel->fs_branch();
                $this->load->view('FS_Usersettings/Users',$data);

            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


    public function ADDUSER()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40100') === 'Y')
            { 
                $Branchandcode = $this->input->post('BranchADD');

                $Branchandcodedata = explode("|", $Branchandcode);
                $BranchCode = $Branchandcodedata[0]; 
                $Branch = $Branchandcodedata[1];
                $data = array(
                    
                    'p_aed'         => 'ADD',
                    'p_userid'      =>  $this->input->post('UserIDADD'),
                    'p_password'    =>  $this->input->post('UserPasswordADD'),
                    'p_lname'       =>  $this->input->post('LNameADD'),
                    'p_fname'       =>  $this->input->post('FNameADD'),
                    
                    'p_mname'       =>  $this->input->post('MNameADD'),
                    'p_branchcode'  =>  $BranchCode,
                    'p_branch'      =>  $Branch,
                    'p_category'    =>  $this->input->post('CategoryADD'),
                    'p_m10000'      =>  $this->input->post('M10000ADD'),
                    'p_m10100'      =>  $this->input->post('M10100ADD'),

                    'p_m10200'      =>  $this->input->post('M10200ADD'),
                    'p_m10300'      =>  $this->input->post('M10300ADD'),
                    'p_m10400'      =>  $this->input->post('M10400ADD'),
                    'p_m20000'      =>  $this->input->post('M20000ADD'),
                    'p_m20100'      =>  $this->input->post('M20100ADD'),

                    'p_m20200'      =>  $this->input->post('M20200ADD'),
                    'p_m20300'      =>  $this->input->post('M20300ADD'),
                    'p_m30000'      =>  $this->input->post('M30000ADD'),
                    'p_m30100'      =>  $this->input->post('M30100ADD'),
                    'p_m30200'      =>  $this->input->post('M30200ADD'),

                    'p_m30300'      =>  $this->input->post('M30300ADD'),
                    'p_m30400'      =>  $this->input->post('M30400ADD'),
                    'p_m40000'      =>  $this->input->post('M40000ADD'),
                    'p_m40100'      =>  $this->input->post('M40100ADD'),

                

                );

                $result = $this->SPModel->rp_fs_users_aed($data);

                if($result)
                {
                    foreach($result as $row)
                    {
                        ?>
                        
                        <div class="alert alert-info">
                        User <?php echo $row->p_userid; ?> Added.
                        </div>
                        <?php
                    }
                }

            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


    public function EDTUSER()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M40100') === 'Y')
            { 
                $Branchandcode = $this->input->post('BranchEDT');

                $Branchandcodedata = explode("|", $Branchandcode);
                $BranchCode = $Branchandcodedata[0]; 
                $Branch = $Branchandcodedata[1];
                $data = array(
                    
                    'p_aed'         => 'EDT',
                    'p_userid'      =>  $this->input->post('UserIDEDT'),
                    'p_password'    =>  $this->input->post('UserPasswordEDT'),
                    'p_lname'       =>  $this->input->post('LNameEDT'),
                    'p_fname'       =>  $this->input->post('FNameEDT'),

                    'p_mname'       =>  $this->input->post('MNameEDT'),
                    'p_branchcode'  =>  $BranchCode,
                    'p_branch'      =>  $Branch,

                    'p_category'    =>  $this->input->post('CategoryEDT'),

                    'p_m10000'      =>  $this->input->post('M10000EDT'),
                    'p_m10100'      =>  $this->input->post('M10100EDT'),

                    'p_m10200'      =>  $this->input->post('M10200EDT'),
                    'p_m10300'      =>  $this->input->post('M10300EDT'),
                    'p_m10400'      =>  $this->input->post('M10400EDT'),
                    'p_m20000'      =>  $this->input->post('M20000EDT'),
                    'p_m20100'      =>  $this->input->post('M20100EDT'),

                    'p_m20200'      =>  $this->input->post('M20200EDT'),
                    'p_m20300'      =>  $this->input->post('M20300EDT'),
                    'p_m30000'      =>  $this->input->post('M30000EDT'),
                    'p_m30100'      =>  $this->input->post('M30100EDT'),
                    'p_m30200'      =>  $this->input->post('M30200EDT'),

                    'p_m30300'      =>  $this->input->post('M30300EDT'),
                    'p_m30400'      =>  $this->input->post('M30400EDT'),
                    'p_m40000'      =>  $this->input->post('M40000EDT'),
                    'p_m40100'      =>  $this->input->post('M40100EDT'),
                );

                $result = $this->SPModel->rp_fs_users_aed($data);

                if($result)
                {
                    foreach($result as $row)
                    {
                        ?>
                        
                        <div class="alert alert-info">
                        User <?php echo $row->p_userid; ?> Updated.
                        </div>
                        <?php
                    }
                }
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
}
?>


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RFID extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('TSModel');
    }

    
    
    // ==================  RFID =====================
    
    public function ScanSwapping() 
    {
        $nav['title'] = "RFID Swapping";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('S_RFIDM/ScanSwapping');
        $this->load->view('globaltemplate/footer');
    }






    public function queryRFIDM()
    {
        if($this->session->userdata('M10100') === 'Y')
        { 
            $query = trim($this->input->post('ID'));
            if($query)
            {
            // $query = trim('0004773155');
            
            $this->db->where('RFID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            if($data)
            {
                foreach($data as $row)
                {
                     $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    // $row['CategoryCode'];
                    
                    ?><br><?php
                }
           
            }
            else
            {
                $Category = '';
            }


            if($Category)
            {
                //if driver categorycode = 0001
                if($Category ==='0001')
                {
                    $data['record'] = '1';
                    $_SESSION['DriverID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Driver';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
            //if unit categorycode = 0002
                elseif($Category ==='0002')
                {
                    $data['record'] = '1';
                    $_SESSION['unitID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Unit';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003')
                {
                    $data['record'] = '1';
                    $_SESSION['batteryID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Battery';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $ID;
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $data['Category'] = ' ';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $this->input->post('ID');;
                    $data['Category'] = ' ';
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $this->load->view('S_informationRFID/infomodal',$data);
            }


        if(!empty($_SESSION['DriverID']))
        {
            $this->db->where('ID',$_SESSION['DriverID']);
            $DriverID = $this->db->get('equipments');   
            $data['DriverIDres'] = $DriverID->result_array();

            $this->load->view('S_informationRFIDM/Driver',$data);

        }
        if(!empty($_SESSION['unitID']))
        {
            $this->db->where('ID',$_SESSION['unitID']);
            $unitID = $this->db->get('equipments');   
            $data['UnitIDres'] = $unitID->result_array();

            $this->load->view('S_informationRFIDM/Unit',$data);

        }
        if(!empty($_SESSION['batteryID']))
        {
            $this->db->where('ID',$_SESSION['batteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationRFIDM/Battery',$data);

        }
       
        
        
        if (isset($_SESSION['DriverID']) && isset($_SESSION['unitID']) && isset($_SESSION['batteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['DriverID'].'-DriverID ,'. $_SESSION['unitID'] .'-unit ,'. $_SESSION['batteryID'] .'-battery'; 
                                ?>
                                    
                            </div>
                    <?php
            $this->load->view('S_informationRFIDM/type');
        }
        else
        {
                    if(isset($_SESSION['DriverID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['DriverID']; ?> scanned (Driver)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['unitID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['unitID']; ?> scanned (unit)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
                }
            }
            else
            {
               ?>
                <div class="alert alert-danger">
                    <?php echo "Value required"  ?> 
                </div>
               <?php
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }













    
    
    
    
    
     public function queryRFID()
    {
        if($this->session->userdata('M10100') === 'Y')
        { 
            $query = trim($this->input->post('ID'));
            
            // $query = trim('0004773155');
            
            $this->db->where('RFID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            if($data)
            {
                foreach($data as $row)
                {
                     $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    // $row['CategoryCode'];
                    
                    ?><br><?php
                }
           
            }
            else
            {
                $Category = '';
            }


            if($Category)
            {
                //if driver categorycode = 0001
                if($Category ==='0001')
                {
                    $data['record'] = '1';
                    $_SESSION['DriverID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Driver';
                    $this->load->view('S_informationRFID/infomodal',$data);
                }
            //if unit categorycode = 0002
                elseif($Category ==='0002')
                {
                    $data['record'] = '1';
                    $_SESSION['unitID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Unit';
                    $this->load->view('S_informationRFID/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003')
                {
                    $data['record'] = '1';
                    $_SESSION['batteryID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Battery';
                    $this->load->view('S_informationRFID/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $ID;
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $data['Category'] = ' ';
                    $this->load->view('S_informationRFID/infomodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $this->input->post('ID');;
                    $data['Category'] = ' ';
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $this->load->view('S_informationRFID/infomodal',$data);
            }


        if(!empty($_SESSION['DriverID']))
        {
            $this->db->where('ID',$_SESSION['DriverID']);
            $DriverID = $this->db->get('equipments');   
            $data['DriverIDres'] = $DriverID->result_array();

            $this->load->view('S_informationRFIDR/Driver',$data);

        }
        if(!empty($_SESSION['unitID']))
        {
            $this->db->where('ID',$_SESSION['unitID']);
            $unitID = $this->db->get('equipments');   
            $data['UnitIDres'] = $unitID->result_array();

            $this->load->view('S_informationRFIDR/Unit',$data);

        }
        if(!empty($_SESSION['batteryID']))
        {
            $this->db->where('ID',$_SESSION['batteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationRFIDR/Battery',$data);

        }
       
        
        
        if (isset($_SESSION['DriverID']) && isset($_SESSION['unitID']) && isset($_SESSION['batteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['DriverID'].'-DriverID ,'. $_SESSION['unitID'] .'-unit ,'. $_SESSION['batteryID'] .'-battery'; 
                                ?>
                                    
                            </div>
                    <?php
            $this->load->view('S_informationRFID/type');
        }
        else
        {
                    if(isset($_SESSION['DriverID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['DriverID']; ?> scanned (Driver)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['unitID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['unitID']; ?> scanned (unit)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    
    
    public function VerifyUser()
    {
            $rgiduser =  $this->input->post('rfiduser'); 
            $this->db->where('RFID',$rgiduser);
            $userdata = $this->db->get('fs_users'); 
             $data = $userdata->result_array();
            // print_r($data);
            if($data)
            {
             echo '1';
            }
            else 
            {
            echo '0';
            }
            
        
    }
    //   ScanCharger


    public function ScanCharger()
    {
        $nav['title'] = "RFID Charging";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('S_RFIDM/ScanCharger');
        $this->load->view('globaltemplate/footer');
    }



    public function queryRFIDC()
    {
        if($this->session->userdata('M10100') === 'Y')
        { 
            $query = trim($this->input->post('ID'));
            if($query)
            {



            
            // $query = trim('352124');
            
            $this->db->where('RFID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            if($data)
            {
                foreach($data as $row)
                {
                     $Category = $row['CategoryCode'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    // $row['CategoryCode'];
                    
                    ?><br><?php
                }
           
            }
            else
            {
                $Category = '';
            }


            if($Category)
            {
 
            //if charger categorycode = 0004
                if($Category ==='0004')
                {
                    $data['record'] = '1';
                    $_SESSION['CchargerID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'CHARGER';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003')
                {
                    $data['record'] = '1';
                    $_SESSION['CbatteryID'] = $ID;
                    $data['ID'] = $ID;
                    $data['LName'] = $LName;
                    $data['FName'] = $FName;
                    $data['MName'] = $MName;
                    $data['Category'] = 'Battery';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $ID;
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $data['Category'] = ' ';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                    $data['record'] = '0';
                    $data['ID'] = $this->input->post('ID');;
                    $data['Category'] = ' ';
                    $data['LName'] = ' ';
                    $data['FName'] = ' ';
                    $data['MName'] = ' ';
                    $this->load->view('S_informationRFIDM/infomodal',$data);
            }


        if(!empty($_SESSION['CchargerID']))
        {
            $this->db->where('ID',$_SESSION['CchargerID']);
            $chargerID = $this->db->get('equipments');   
            $data['chargerIDres'] = $chargerID->result_array();

            $this->load->view('S_informationRFIDM/Charger',$data);

        }
        if(!empty($_SESSION['CbatteryID']))
        {
            $this->db->where('ID',$_SESSION['CbatteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationRFIDM/BatteryC',$data);

        }
       
        
        
        if (isset($_SESSION['CchargerID']) && isset($_SESSION['CbatteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['CchargerID'].'-charger ,'. $_SESSION['CbatteryID'] ; 
                                ?>
                                    
                            </div>
                    <?php
            $this->load->view('S_informationRFIDM/Ctype');
            
        }
        else
        {
                    if(isset($_SESSION['CchargerID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['CchargerID']; ?> scanned (charger)
                            </div>
                        <?php
                    
                    }
                    
                    
                     if(isset($_SESSION['CbatteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['CbatteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
            }
        }
        
        else
        {
           ?>
        <div class="alert alert-danger">
                                <?php echo "Value required"  ?> 
                            </div>
           <?php
        }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }


// ========================= NEW RFID SWAPPING =========================


    public function SwapChoice()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10100') === 'Y')
            { 
                $nav['title'] = "RFID Swapping";
                $this->load->view('globaltemplate/header');
                $this->load->view('globaltemplate/nav', $nav);


                $this->load->view('S_RFIDR/choice');
                // $this->load->view('S_RFID/Scan');

                
                $this->load->view('globaltemplate/footer');
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }



    public function Swapping()
    {
    $data =  $this->uri->segment(3);
    $datarep =  str_replace("_"," ",$data);
    
        if($datarep === 'SWAP IN')
        {
    
            
            $nav['title'] = "RFID SWAP IN";
            $dataS['SWAPTYPE'] = "SWAP IN";
            // $datas['Status'] = $datarep;
            $this->load->view('globaltemplate/header');
            $this->load->view('globaltemplate/nav', $nav);
            $this->load->view('S_RFIDR/ScanSwapping', $dataS);
            $this->load->view('globaltemplate/footer');
        }
        elseif($datarep === 'SWAP OUT')
        {
            
            $nav['title'] = "RFID SWAP OUT";
            $dataS['SWAPTYPE'] = "SWAP OUT";
            // $datas['Status'] = $datarep;
            $this->load->view('globaltemplate/header');
            $this->load->view('globaltemplate/nav', $nav);
            $this->load->view('S_RFIDR/ScanSwapping', $dataS);
            $this->load->view('globaltemplate/footer');
        }
        else
        {
            echo 'Invalid';
        }
    }

    public function Charging()
    {
        $data =  $this->uri->segment(3);
        $datarep =  str_replace("_"," ",$data);
        if($datarep === 'CHARGE IN')
        {
    
            
            $nav['title'] = "RFID CHARGE IN";
            $dataS['SWAPTYPE'] = "CHARGE IN";
            // $datas['Status'] = $datarep;
            $this->load->view('globaltemplate/header');
            $this->load->view('globaltemplate/nav', $nav);
            $this->load->view('S_RFIDR/ScanCharging', $dataS);
            $this->load->view('globaltemplate/footer');
        }
        elseif($datarep === 'CHARGE OUT')
        {
            
            $nav['title'] = "RFID CHARGE OUT";
            $dataS['SWAPTYPE'] = "CHARGE OUT";
            // $datas['Status'] = $datarep;
            $this->load->view('globaltemplate/header');
            $this->load->view('globaltemplate/nav', $nav);
            $this->load->view('S_RFIDR/ScanCharging', $dataS);
            $this->load->view('globaltemplate/footer');
        }
        else
        {
            echo 'Invalid';
        }
    }




    public function queryRFIDR()
    {
        if($this->session->userdata('M10100') === 'Y')
        { 
            $query = trim($this->input->post('ID'));
            // $query = "000477";
             $Swapstatus = trim($this->input->post('SWAPSTATUS'));
            // $Swapstatus = 'SWAP IN';
            if($query)
            {
            // $query = trim('000477');
            
            $this->db->where('RFID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $CategoryName = $row['Category'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    $RStatus = $row['RStatus'];
                    $EStatus = $row['EStatus'];
                    $CStatus = $row['CStatus'];
                    
                    // WHEN CHECKING FOR SWAPPING
                        // BATTERY = 0003
                            // - RSTATUS = REPAIR STATUS
                            // - ESTATUS = SWAP STATUS
                            // - CSTATUS = CHARGE STATUS
                        // UNIT = 0002
                            // - RSTATUS = REPAIR STATUS
                            // - ESTATUS = SWAP STATUS
                        // DRIVER = 0001
                            // - ESTATUS = SWAP STATUS


                    
                    ?><br><?php
                }
           
            }
            else
            {
                $Category = '';
            }

            // echo $Category;
            if($Category)
            {
                //if driver categorycode = 0001
                if($Category ==='0001')
                {
                    $data['record'] = '1';
                    $_SESSION['DriverID'] = $ID;
                    // $data['ID'] = $ID;
                    // $data['LName'] = $LName;
                    // $data['FName'] = $FName;
                    // $data['MName'] = $MName;
                    // $data['Category'] = 'Driver';
                    // $this->load->view('globaltemplate/header');
                    // $this->load->view('S_informationRFIDR/Driver',$data);
                }
            //if unit categorycode = 0002
                elseif($Category ==='0002'  && $Swapstatus != $EStatus && $RStatus === 'REPAIR OUT')
                {
                    $data['record'] = '1';
                    $_SESSION['unitID'] = $ID;
                    // $data['ID'] = $ID;
                    // $data['LName'] = $LName;
                    // $data['FName'] = $FName;
                    // $data['MName'] = $MName;
                    // $data['Category'] = 'Unit';
                    // $this->load->view('S_informationRFIDR/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003'  && $Swapstatus != $EStatus && $RStatus === 'REPAIR OUT' && $CStatus === 'CHARGE OUT')
                {
                    $data['record'] = '1';
                    $_SESSION['batteryID'] = $ID;
                    // $data['ID'] = $ID;
                    // $data['LName'] = $LName;
                    // $data['FName'] = $FName;
                    // $data['MName'] = $MName;
                    // $data['Category'] = 'Battery';
                    // $this->load->view('S_informationRFIDR/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        ERROR: <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                  $data['record'] = '1';
                        
                  $data['ID'] = $ID;
                  $data['label'] = 'Driver';
                  $data['LName'] = $LName;
                  $data['FName'] = $FName;
                  $data['MName'] = $MName;
                  $data['RStatus'] = $RStatus;
                  $data['EStatus'] = $EStatus;
                  $data['CStatus'] = $CStatus;
                  $data['Swapstatus'] = $Swapstatus;
                  $data['CategoryName'] = $CategoryName;
                  // echo "invalid";

                  $data['Category'] = 'Driver';
                  $this->load->view('S_informationRFIDR/errormodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                  
            }


        if(!empty($_SESSION['DriverID']))
        {
            $this->db->where('ID',$_SESSION['DriverID']);
            $DriverID = $this->db->get('equipments');   
            $data['DriverIDres'] = $DriverID->result_array();

            $this->load->view('S_informationRFIDR/Driver',$data);

        }
        if(!empty($_SESSION['unitID']))
        {
            $this->db->where('ID',$_SESSION['unitID']);
            $unitID = $this->db->get('equipments');   
            $data['UnitIDres'] = $unitID->result_array();

            $this->load->view('S_informationRFIDR/Unit',$data);

        }
        if(!empty($_SESSION['batteryID']))
        {
            $this->db->where('ID',$_SESSION['batteryID']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationRFIDR/Battery',$data);

        }
       
        
        
        if (isset($_SESSION['DriverID']) && isset($_SESSION['unitID']) && isset($_SESSION['batteryID']))
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['DriverID'].'-DriverID ,'. $_SESSION['unitID'] .'-unit ,'. $_SESSION['batteryID'] .'-battery'; 
                                ?>
                                    
                            </div>
                    <?php

                    $data['swapstatus'] = $Swapstatus;
            $this->load->view('S_informationRFIDR/type', $data);
        }
        else
        {
                    if(isset($_SESSION['DriverID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['DriverID']; ?> scanned (Driver)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['unitID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['unitID']; ?> scanned (unit)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
                }
            }
            else
            {
               ?>
                <div class="alert alert-danger">
                    <?php echo "Value required"  ?> 
                </div>
               <?php
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }





    
    public function queryRFIDRC()
    {
        if($this->session->userdata('M10100') === 'Y')
        { 
            $query = trim($this->input->post('ID'));
            // $query = "000477";
             $ChargeStatus = trim($this->input->post('SWAPSTATUS'));
            // $Swapstatus = 'SWAP IN';
            if($query)
            {
            // $query = trim('000477');
            
            $this->db->where('RFID',"$query");
            $Equipments = $this->db->get('equipments');   
            $data = $Equipments->result_array();
            if($data)
            {
                foreach($data as $row)
                {
                    $Category = $row['CategoryCode'];
                    $CategoryName = $row['Category'];
                    $ID = $row['ID'];
                    $LName = $row['LName'];
                    $FName = $row['FName'];
                    $MName = $row['MName'];
                    $RStatus = $row['RStatus'];
                    $EStatus = $row['EStatus'];
                    $CStatus = $row['CStatus'];
                    
                    // WHEN CHECKING FOR CHARGING
                        // BATTERY = 0003
                            // - RSTATUS = REPAIR STATUS
                            // - ESTATUS = SWAP STATUS
                            // - CSTATUS = CHARGE STATUS
                        // CHARGER = 0002
                            // - RSTATUS = REPAIR STATUS
                            // - CSTATUS = CHARGE STATUS
         

                    
                    ?><br><?php
                }
           
            }
            else
            {
                $Category = '';
            }

            // echo $Category;
            if($Category)
            {
          

            //if Charger categorycode = 0004
                if($Category ==='0004'  && $ChargeStatus != $CStatus && $RStatus === 'REPAIR OUT'   )
                {
                    $data['record'] = '1';
                    $_SESSION['ChargerIDC'] = $ID;
                    // $data['ID'] = $ID;
                    // $data['LName'] = $LName;
                    // $data['FName'] = $FName;
                    // $data['MName'] = $MName;
                    // $data['Category'] = 'Unit';
                    // $this->load->view('S_informationRFIDR/infomodal',$data);
                }
            //if battery categorycode = 0003
                elseif($Category ==='0003'  && $ChargeStatus != $CStatus && $RStatus === 'REPAIR OUT' && $EStatus === 'SWAP IN')
                {
                    $data['record'] = '1';
                    $_SESSION['batteryIDC'] = $ID;
                    // $data['ID'] = $ID;
                    // $data['LName'] = $LName;
                    // $data['FName'] = $FName;
                    // $data['MName'] = $MName;
                    // $data['Category'] = 'Battery';
                    // $this->load->view('S_informationRFIDR/infomodal',$data);
                }
                else
                {
                ?>
                    <div class="alert alert-danger">
                        ERROR: <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                  $data['record'] = '1';
                        
                  $data['ID'] = $ID;
                  $data['label'] = 'Driver';
                  $data['LName'] = $LName;
                  $data['FName'] = $FName;
                  $data['MName'] = $MName;
                  $data['RStatus'] = $RStatus;
                  $data['EStatus'] = $EStatus;
                  $data['CStatus'] = $CStatus;
                  $data['Swapstatus'] = $Swapstatus;
                  $data['CategoryName'] = $CategoryName;
                  // echo "invalid";

                  $data['Category'] = 'Driver';
                  $this->load->view('S_informationRFIDR/errormodal',$data);
                }
            }
            else
            {
                   ?>
                    <div class="alert alert-danger">
                        INVALID CODE <?php echo $this->input->post('ID'); ?>
                    </div>
                <?php
                  
            }


        if(!empty($_SESSION['ChargerIDC']))
        {
            $this->db->where('ID',$_SESSION['ChargerIDC']);
            $ChargerID = $this->db->get('equipments');   
            $data['chargerIDres'] = $ChargerID->result_array();

            $this->load->view('S_informationRFIDR/Charger',$data);

        }
        if(!empty($_SESSION['batteryIDC']))
        {
            $this->db->where('ID',$_SESSION['batteryIDC']);
            $batteryID = $this->db->get('equipments');   
            $data['BatteryIDres'] = $batteryID->result_array();

            $this->load->view('S_informationRFIDR/Battery',$data);

        }

       
        
        
        if (isset($_SESSION['ChargerID']) && isset($_SESSION['batteryID']) )
        {

             ?>
                            <div class="alert alert-success">
                                <?php
                                    echo $_SESSION['batteryID'].'-batteryID ,'. $_SESSION['ChargerID'] .'-ChargerID ,'; 
                                ?>
                                    
                            </div>
                    <?php

                    $data['Swapstatus'] = $ChargeStatus;
            $this->load->view('S_informationRFIDR/type', $data);
        }
        else
        {
                    if(isset($_SESSION['ChargerID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['ChargerID']; ?> scanned (Charger)
                            </div>
                        <?php
                    
                    }
                    
                     if(isset($_SESSION['batteryID']))
                    {
                        ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['batteryID']; ?> scanned (Battery)
                            </div>
                        <?php
                    
                    }
                }
            }
            else
            {
               ?>
                <div class="alert alert-danger">
                    <?php echo "Value required"  ?> 
                </div>
               <?php
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function AddSwappingRecord()
    {
        if($this->session->userdata('UserID') != '')
        { 
            if($this->session->userdata('M10000') === 'Y')
            { 
            $data = array(
                'v_referencecode'       => ' ',
                'p_swaptype'            => trim($this->input->post('p_swaptype')),
                'p_unitid'              => trim($this->input->post('p_unitid')),
                'p_batteryid'           => trim($this->input->post('p_batteryid')),
                'p_driverid'            => trim($this->input->post('p_driverid')),

                'p_ldriver'             => trim($this->input->post('p_ldriver')),
                'p_fdriver'             => trim($this->input->post('p_fdriver')),
                'p_mdriver'             => trim($this->input->post('p_mdriver')),

                'p_userid'              => trim($this->session->userdata('UserID') ),
                'p_luser'               => trim($this->session->userdata('LName') ),

                'p_fuser'               => trim($this->session->userdata('FName') ),
                'p_muser'               => trim($this->session->userdata('MName') ),

                'p_branchcode'          => trim($this->session->userdata('BranchCode') ),
                'p_branch'              => trim($this->session->userdata('Branch') ),

                );

                unset($_SESSION["DriverID"]);
                unset($_SESSION["unitID"]);
                unset($_SESSION["batteryID"]);

                $data['result'] = $this->SPModel->rp_swap_add($data);
                $this->load->view('S_informationRFIDR/ResultModal',$data);
            }
            else
            {
            redirect($_SERVER['HTTP_REFERER']);
            }
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function AddChargingRecord()
    {
        
    }
    public function redirectchoice()
    {
        unset($_SESSION["DriverID"]);
        unset($_SESSION["unitID"]);
        unset($_SESSION["batteryID"]);
        unset($_SESSION["ChargerID"]);
        redirect('RFID/SwapChoice');
    }






    
    }


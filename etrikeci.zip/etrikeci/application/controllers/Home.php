<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('EquipmentModel');
        $this->load->model('ReportsModel');
        $this->load->model('DashboardModel');
        
        date_default_timezone_set('Asia/Manila');
    }


    public function Homepage2()
    {
        if($this->session->userdata('UserID') != '')
        { 
            

                $nav['title'] = "Dashboard";
                $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d"))));
                $this->db->group_by('deviceName'); 
                $this->db->distinct('deviceName');
                $data['DevCount'] = $this->db->get('rp_DeviceLocationList')->num_rows();   
                
                //   $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d"))));
                // $this->db->group_by('deviceName'); 
                // $this->db->distinct('deviceName');
                  
                     $this->db->group_by('IMEI'); 
                $this->db->where('Distance >',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);
                $data['DMG5'] = $this->db->get('rp_TrackMileage')->num_rows();   
                     $this->db->group_by('IMEI'); 
                $this->db->where('Distance <',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);  
                $data['DML5'] = $this->db->get('rp_TrackMileage')->num_rows();  
                //  = $data->num_rows();

                if($this->session->userdata('Category') == 'A')
                {
                    $data['rp_equipments_status'] = $this->SPModel->rp_equipments_status();
                }
                elseif($this->session->userdata('Category') == 'C')
                {
                    redirect("Dashboard/lowvoltagebattery");
                }
                else
                {
                    $val = array(
                        'p_Category'    =>  'Battery',
                        'p_Status'      =>  'Charge IN',
                        'p_UserID'      =>  'gelo',
                    );
                    $data['sp_rp_equipments_find'] = $this->SPModel->sp_rp_equipments_find($val);
                    // print_r( $this->SPModel->sp_rp_equipments_find($val));
                }
    
              
            // print_r($this->ReportsModel->lowvolcount());
                  
            // print_r($Equipments);
            
                $this->load->view('globaltemplate/header');
                $this->load->view('home/header');
                $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('home/dashboardNN',$data);
                $this->load->view('globaltemplate/footer');

        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
// ================================================












  public function Homepage()
    {   
        if($this->session->userdata('UserID') != '')
        { 
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $limit = "10";
        $numberpagesbat = (int) ceil($this->DashboardModel->GetBattery($limit, $offset, $count=true) / $limit);
        $numberpagesl5km = (int) ceil($this->DashboardModel->GetL5KM($limit, $offset, $count=true) / $limit);
        $numberpagesg5km = (int) ceil($this->DashboardModel->GetG5KM($limit, $offset, $count=true) / $limit);
         
        $data['numberpagesbat'] = $numberpagesbat ;
        $data['numberpagesl5km'] = $numberpagesl5km ;
        $data['numberpagesg5km'] = $numberpagesg5km ;
        $nav['title'] = "Dashboard";
    //  $this->load->view('globaltemplate/headerlogin');
                $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        
        $this->load->view('home/dashboardHN',$data);
        // $this->load->view('home/tailwinddashboard',$data);
        $this->load->view('H_Dashboard/footer');
          $this->load->view('globaltemplate/footer');
        
          
        
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    public function lowvoltagebattery()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $limit = "10";
        $numberpagesbat = (int) ceil($this->DashboardModel->GetBattery($limit, $offset, $count=true) / $limit);
        $numberpagesl5km = (int) ceil($this->DashboardModel->GetL5KM($limit, $offset, $count=true) / $limit);
        $numberpagesg5km = (int) ceil($this->DashboardModel->GetG5KM($limit, $offset, $count=true) / $limit);
         
        $data['numberpagesbat'] = $numberpagesbat ;
        $data['numberpagesl5km'] = $numberpagesl5km ;
        $data['numberpagesg5km'] = $numberpagesg5km ;
        $this->load->view('globaltemplate/header');
        $this->load->view('H_Dashboard/Dashboard', $data);
        $this->load->view('H_Dashboard/footer');
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    public function GetLowVolBattery()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');

        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Home/GetLowVolBattery/');
        $config['total_rows'] = $this->DashboardModel->GetBattery($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="battery">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetBattery($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('H_Dashboard/Dashboardajax',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    
    
    public function L5KM()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Home/L5KM/');
        $config['total_rows'] = $this->DashboardModel->GetL5KM($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="L5KM">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetL5KM($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('H_Dashboard/DashboardajaxLS5KM',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
     public function G5KM()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Home/G5KM/');
        $config['total_rows'] = $this->DashboardModel->GetG5KM($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="G5KM">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetG5KM($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('H_Dashboard/DashboardajaxGS5KM',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    






































// ================================================

    public function testing()
    {
        $this->load->view('globaltemplate/header');
        $this->load->view('home/testing');
        $this->load->view('globaltemplate/footer');
      
    }

  public function getdevicedasboard()
   {


    if(trim($this->input->post('Category')))
    {
       $_SESSION['Categorysearch'] = trim($this->input->post('Category'));
    }
    if(trim($this->input->post('StateType')))
    {
        $_SESSION['StateType'] = trim($this->input->post('StateType'));
    }


    if(!isset($_SESSION['Categorysearch']) || $_SESSION['Categorysearch'] == '')
    {
     
       $Category = '';
    }
    else
    {

         $Category = trim($_SESSION['Categorysearch']);
    }

    
    if (!isset($_SESSION['StateType']) || $_SESSION['StateType'] == '')
    {
       
        $StateType = '';
    }
    else
    {
     $StateType = trim($_SESSION['StateType']);

    }

 
    $search = array(
        'p_Category'        => trim($Category),
        'p_Status'        => trim($StateType),
        'p_UserID'        => ' ',

        // 'p_Category'    =>  'Charger',
        // 'p_Status'      =>  'REPAIR OUT',
        // 'p_UserID'      =>  'gelo',

        );

        $this->load->library('pagination');

        $limit = 50;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Home/getdevicedasboard/');
        $config['total_rows'] = $this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li>';
        $config['next_tag_close']       = '</li>';
        $config['prev_link']            = '<';
        $config['prev_tag_open']        = '<li>';
        $config['prev_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);

        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Equipments'] = $this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=false);
        // print_r($this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=false));
        $data['pagelinks'] = $this->pagination->create_links();
        $data['Status'] =  trim($StateType);
        $data['title'] = trim($Category.'-'.$StateType);
        // $data['Status'] =  trim('REPAIR OUT');
       
        // $this->load->view('templates/afteraddheader');
        $this->load->view('home/getdataajax',$data);

   } 
   
   
     public function getlowvoltagedevicedasboard()
   {


 
    $search = array(
         'CurDate'        => $this->input->post('CurDate'),

        // 'CurDate'        => date('Y-m-d',strtotime('2023-10-13')),



        );

        $this->load->library('pagination');

        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Home/getlowvoltagedevicedasboard/');
        $config['total_rows'] = $this->EquipmentModel->rp_lowvoldate_find($limit, $offset, $search, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li>';
        $config['next_tag_close']       = '</li>';
        $config['prev_link']            = '<';
        $config['prev_tag_open']        = '<li>';
        $config['prev_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);

        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Equipments'] = $this->EquipmentModel->rp_lowvoldate_find($limit, $offset, $search, $count=false);
        // print_r( $this->EquipmentModel->rp_lowvoldate_find($limit, $offset, $search, $count=false));
        // print_r($this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=false));
        $data['pagelinks'] = $this->pagination->create_links();
        // $data['Status'] =  trim($StateType);
        // $data['title'] = trim($Category.'-'.$StateType);
        // $data['Status'] =  trim('REPAIR OUT');
       
        // $this->load->view('templates/afteraddheader');
        $this->load->view('home/getdataajaxlowvoltage',$data);

   } 
   
   
   
   
    public function getlesstfivekm()
   {
        $search = array(
         'Distance'        => $this->input->post('Distance'),

        // 'CurDate'        => date('Y-m-d',strtotime('2023-10-13')),



        );

        $this->load->library('pagination');

        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Home/getlesstfivekm/');
        $config['total_rows'] = $this->EquipmentModel->rp_DistanceLfivekm_find($limit, $offset, $search, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li>';
        $config['next_tag_close']       = '</li>';
        $config['prev_link']            = '<';
        $config['prev_tag_open']        = '<li>';
        $config['prev_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);

        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Equipments'] = $this->EquipmentModel->rp_DistanceLfivekm_find($limit, $offset, $search, $count=false);
        // print_r( $this->EquipmentModel->rp_lowvoldate_find($limit, $offset, $search, $count=false));
        // print_r($this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=false));
        $data['pagelinks'] = $this->pagination->create_links();
        // $data['Status'] =  trim($StateType);
        // $data['title'] = trim($Category.'-'.$StateType);
        // $data['Status'] =  trim('REPAIR OUT');
       
        // $this->load->view('templates/afteraddheader');
        $this->load->view('home/getdataajaxLfivekm',$data);
   }
   
   public function getgreatertfivekm()
   {
        $search = array(
         'Distance'        => $this->input->post('Distance'),

        // 'CurDate'        => date('Y-m-d',strtotime('2023-10-13')),



        );

        $this->load->library('pagination');

        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Home/getgreatertfivekm/');
        $config['total_rows'] = $this->EquipmentModel->rp_DistanceGfivekm_find($limit, $offset, $search, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li>';
        $config['next_tag_close']       = '</li>';
        $config['prev_link']            = '<';
        $config['prev_tag_open']        = '<li>';
        $config['prev_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);

        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Equipments'] = $this->EquipmentModel->rp_DistanceGfivekm_find($limit, $offset, $search, $count=false);
        // print_r( $this->EquipmentModel->rp_lowvoldate_find($limit, $offset, $search, $count=false));
        // print_r($this->EquipmentModel->sp_rp_equipments_find($limit, $offset, $search, $count=false));
        $data['pagelinks'] = $this->pagination->create_links();
        // $data['Status'] =  trim($StateType);
        // $data['title'] = trim($Category.'-'.$StateType);
        // $data['Status'] =  trim('REPAIR OUT');
       
        // $this->load->view('templates/afteraddheader');
        $this->load->view('home/getdataajaxGfivekm',$data);
   }
   
   
   
   
   
//   new dashboard


 public function dashboard()
    {
        if($this->session->userdata('UserID') != '')
        { 
            

                $nav['title'] = "Dashboard";
                $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d"))));
                $this->db->group_by('deviceName'); 
                $this->db->distinct('deviceName');
                $data['DevCount'] = $this->db->get('rp_DeviceLocationList')->num_rows();   
                
                //   $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d"))));
                // $this->db->group_by('deviceName'); 
                // $this->db->distinct('deviceName');
                  
                $this->db->order_by('IMEI', 'desc');
                // $this->db->group_by('IMEI'); 
                $this->db->where('Distance >',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);
                $data['DMG5R'] = $this->db->get('rp_TrackMileage')->result();  
                
                // print_r($datares);
                $this->db->order_by('IMEI', 'desc');
                // $this->db->group_by('IMEI'); 
                $this->db->where('Distance <',5000);
                $yesterday =  date("Y-m-d",strtotime("-1 day"));
                $datestart = $yesterday .' 00:00:00';
                $dateend = $yesterday .' 23:59:59';
                $this->db->where("DATE(StartTime) >=",$datestart);
                $this->db->where("DATE(EndTime) <=",$dateend);  
                $data['DML5R'] = $this->db->get('rp_TrackMileage')->result();   
                //  = $data->num_rows();
                
                
                           
                $this->db->Select('deviceName');
                $this->db->Select('imei');
                $this->db->Select('powerValue');
                $this->db->Select('batteryPowerVal');
                $this->db->select_max('DateTimeStamp');
                   $this->db->where('DATE(DateTimeStamp)',date('Y-m-d',strtotime(date("Y-m-d")))); 
                //   $this->db->where('DateTimeStamp = (select max(DateTimeStamp) from rp_DeviceLocationList)', NULL, FALSE);
                    // $this->db->Order_by("DateTimeStame", "desc"); 
                    $this->db->Order_by("powerValue", "desc"); 
                $this->db->group_by('deviceName'); 
                
               
            // $this->db->distinct('deviceName');
            
            $data['LOWVOL'] = $this->db->get('rp_DeviceLocationList')->result(); 

                if($this->session->userdata('Category') == 'A')
                {
                    $data['rp_equipments_status'] = $this->SPModel->rp_equipments_status();
                }
                else
                {
                    $val = array(
                        'p_Category'    =>  'Battery',
                        'p_Status'      =>  'Charge IN',
                        'p_UserID'      =>  'gelo',
                    );
                    $data['sp_rp_equipments_find'] = $this->SPModel->sp_rp_equipments_find($val);
                    // print_r( $this->SPModel->sp_rp_equipments_find($val));
                }
    
              
            // print_r($this->ReportsModel->lowvolcount());
                  
            // print_r($Equipments);
            
                $this->load->view('globaltemplate/header');
                $this->load->view('home/header');
                // $this->load->view('globaltemplate/nav', $nav);
                $this->load->view('home/dashboardNNN',$data);
                $this->load->view('globaltemplate/footer');

        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
   
   
   public function GetRFID() 
   {
    $this->db->select('*');
    $this->db->from('apitabletest');
    $this->db->order_by('id', 'desc');
    $this->db->limit(10);
    $query = $this->db->get();
    
        $this->db->select('*');
    $this->db->from('apitabletest');
    $querycount = $this->db->get();
    
    
    $data['result'] = $query->result();

    $data['total'] = $querycount->num_rows();

    $this->load->view('home/getrfiddata', $data);
   }



   

   public function firebase()
   {
    $this->load->library('firebase');
    
    try {
        $database = $this->firebase->getDatabase();
        // Use $database to interact with Firebase Realtime Database
        // For example:
        // $reference = $database->getReference('path/to/data');
        // $snapshot = $reference->getSnapshot();
        // $value = $snapshot->getValue();
        
        echo "Firebase connection successful!";
    } catch (Exception $e) {
        echo "Firebase error: " . $e->getMessage();
    }
   }
   
   
   
   
   
}



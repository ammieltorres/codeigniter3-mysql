<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->model('SPModel');
        $this->load->model('EquipmentModel');
        $this->load->model('DashboardModel');
        $this->load->model('ReportsModel');
        $this->load->model('TSModel');
        
        date_default_timezone_set('Asia/Manila');
    }
    
    public function sitereport()
    {   
        if($this->session->userdata('UserID') != '')
        { 
        // DashboardSiteReport
   
        $data['rp_equipments_status'] = $this->SPModel->rp_equipments_status();
        // $data['totalmileage'] = $this->TSModel->sp_rp_equipments_gtmileage();

        $this->load->view('globaltemplate/header');
        $this->load->view('H_Dashboard/DashboardSiteReport', $data);
        $this->load->view('H_Dashboard/footer');
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    public function lowvoltagebattery()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $limit = "30";
        $numberpagesbat = (int) ceil($this->DashboardModel->GetBattery($limit, $offset, $count=true) / $limit);
        $numberpagesl5km = (int) ceil($this->DashboardModel->GetL5KM($limit, $offset, $count=true) / $limit);
        $numberpagesg5km = (int) ceil($this->DashboardModel->GetG5KM($limit, $offset, $count=true) / $limit);
        $data['numberpagesbat'] = $numberpagesbat ;
        $data['numberpagesl5km'] = $numberpagesl5km ;
        $data['numberpagesg5km'] = $numberpagesg5km ;
        $this->load->view('globaltemplate/header');
        $this->load->view('H_Dashboard/Dashboard', $data);
        $this->load->view('H_Dashboard/footer');
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    public function GetLowVolBattery()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');

        $limit = 30;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $config['base_url'] = site_url('Dashboard/GetLowVolBattery/');
        $config['total_rows'] = $this->DashboardModel->GetBattery($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['display_pages'] = FALSE;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="battery">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetBattery($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

        $this->load->view('globaltemplate/header');
        $this->load->view('H_Dashboard/Dashboardajax',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    
    
    public function L5KM()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 30;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/L5KM/');
        $config['total_rows'] = $this->DashboardModel->GetL5KM($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="L5KM">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetL5KM($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('H_Dashboard/DashboardajaxLS5KM',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
     public function G5KM()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 30;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/G5KM/');
        $config['total_rows'] = $this->DashboardModel->GetG5KM($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="G5KM">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->GetG5KM($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('H_Dashboard/DashboardajaxGS5KM',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    public function testing()
    {
        $this->load->view('globaltemplate/header');
        $this->load->view('H_Dashboard/Dashboard');
    }
    
    
    //===================== DASHTBOARD FOR BATTERY MONITORING =========================
    
    public function batteryreport()
    {
        
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $limit = "1";
        $numberpagesBattocharge = (int) ceil($this->DashboardModel->Battocharge($limit, $offset, $count=true) / $limit);
        $numberpagesBatcharging = (int) ceil($this->DashboardModel->Batcharging($limit, $offset, $count=true) / $limit);
        $numberpagesBatAvailable = (int) ceil($this->DashboardModel->BatAvailable($limit, $offset, $count=true) / $limit);
        $numberpagesBatinuse = (int) ceil($this->DashboardModel->Batinuse($limit, $offset, $count=true) / $limit);
        
        
        $numberpagesbat = (int) ceil($this->DashboardModel->GetBattery($limit, $offset, $count=true) / $limit);
        $numberpagesl5km = (int) ceil($this->DashboardModel->GetL5KM($limit, $offset, $count=true) / $limit);
        $numberpagesg5km = (int) ceil($this->DashboardModel->GetG5KM($limit, $offset, $count=true) / $limit);
        
        $data['numberpagesBattocharge'] = $numberpagesBattocharge ;
        $data['numberpagesBatcharging'] = $numberpagesBatcharging ;
        $data['numberpagesBatAvailable'] = $numberpagesBatAvailable ;
        $data['numberpagesBatinuse'] = $numberpagesBatinuse ;
        
        
        $data['numberpagesbat'] = $numberpagesbat ;
        $data['numberpagesl5km'] = $numberpagesl5km ;
        $data['numberpagesg5km'] = $numberpagesg5km ;
        
        $nav['title'] = "Battery Dashboard";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('RP_Batterydashboard/index',$data);
         $this->load->view('globaltemplate/footer');
        
    }
    
    // ================ Battocharge =======================
    public function Battocharge()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/Battocharge/');
        $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="Battocharge">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->Battocharge($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('RP_Batterydashboard/Battocharge',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    // =================== Batcharging ====================
    public function Batcharging()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/Batcharging/');
        $config['total_rows'] = $this->DashboardModel->Batcharging($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="Batcharging">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->Batcharging($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('RP_Batterydashboard/Batcharging',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
    // ================= BatAvailable ======================
    public function BatAvailable()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/BatAvailable/');
        $config['total_rows'] = $this->DashboardModel->BatAvailable($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="BatAvailable">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->BatAvailable($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
        $this->load->view('RP_Batterydashboard/BatAvailable',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
    }
    
    
        // ================== Batinuse =====================
         public function Batinuse()
    {
        if($this->session->userdata('UserID') != '')
        { 
        $this->load->library('pagination');
        $limit = 10;
        $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $config['base_url'] = site_url('Dashboard/Batinuse/');
        $config['total_rows'] = $this->DashboardModel->Batinuse($limit, $offset, $count=true);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['num_links'] = 3;
        $config['num_tag_open']         = '<li>';
        $config['num_tag_close']        = '</li>';
        $config['cur_tag_open']         = '<li><a href="" class="current_page">';
        $config['cur_tag_close']        = '</a></li>';
        $config['next_link']            = '>';
        $config['next_tag_open']        = '<li id="Batinuse">';
        $config['next_tag_close']       = '</li>';
        $config['first_link']           = '<<';
        $config['first_tag_open']       = '<li>';
        $config['first_tag_close']      = '</li>';
        $config['last_link']            = '>>';
        $config['last_tag_open']        = '<li>';
        $config['last_tag_close']       = '</li>';

        $this->pagination->initialize($config);
         
        $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
        $data['Battery'] = $this->DashboardModel->Batinuse($limit, $offset, $count=false);
        $data['pagelinks'] = $this->pagination->create_links();

       
           $this->load->view('RP_Batterydashboard/Batinuse',$data);
        }
        else
        {
        redirect($_SERVER['HTTP_REFERER']);
        }
        
    }
    
    
    
    
            
        public function Battochargesimplified()
        {
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
                $data['result_count']= "" . number_format($config['total_rows'], 0);
                $this->load->view('RP_BatterydashboardS/Battocharge',$data);
        }
        
        public function Batchargingsimplified()
        {
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
                $config['total_rows'] = $this->DashboardModel->Batcharging($limit, $offset, $count=true);
                $data['result_count']= "" . number_format($config['total_rows'], 0);
                $this->load->view('RP_BatterydashboardS/Batcharging',$data);
        }
        
        public function BatAvailablesimplified()
        {
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
                $config['total_rows'] = $this->DashboardModel->BatAvailable($limit, $offset, $count=true);
                $data['result_count']= "" . number_format($config['total_rows'], 0);
                $this->load->view('RP_BatterydashboardS/BatAvailable',$data);
        }
        
        public function Batinusesimplified()
        {
                $limit = 10;
                $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
                $config['total_rows'] = $this->DashboardModel->Batinuse($limit, $offset, $count=true);
                $data['result_count']= "" . number_format($config['total_rows'], 0);
                $this->load->view('RP_BatterydashboardS/Batinuse',$data);
        }
        
              
        
        
        
        public function Batteryreportgsheet()
        {
            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $config['total_rows'] = $this->DashboardModel->Batinuse($limit, $offset, $count=true);
            $data['Batinuse']= "" . number_format($config['total_rows'], 0);
            
            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $config['total_rows'] = $this->DashboardModel->BatAvailable($limit, $offset, $count=true);
            $data['BatAvailable']= "" . number_format($config['total_rows'], 0);

            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $config['total_rows'] = $this->DashboardModel->Batcharging($limit, $offset, $count=true);
            $data['Batcharging']= "" . number_format($config['total_rows'], 0);

            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $config['total_rows'] = $this->DashboardModel->Battocharge($limit, $offset, $count=true);
            $data['Battocharge']= "" . number_format($config['total_rows'], 0);




                $this->db->select('*');
                $this->db->from('GS_Logs_Temp');
                $this->db->order_by('GS_DateTime', 'desc');
                $this->db->limit(5);
                $query = $this->db->get();
                $data['result'] = $query->result();

                $this->load->view('globaltemplate/header');
                $this->load->view('RP_BatterydashboardS/index', $data);
        }
        
        
        
        
        
        
        public function Battochargegsheet()
        {
            $this->db->select('*');
            $this->db->from('GS_Logs_Temp');
            $this->db->order_by('GS_DateTime', 'desc');
            $this->db->limit(5);
            $query = $this->db->get();
            $data['result'] = $query->result();

            $this->load->view('globaltemplate/header');
            $this->load->view('RP_BatterydashboardS/Gsheetlist',$data);

            // print_r($query);
        }

        
        public function totalmileagereport()
        {
            $data['sp_rp_devicelocationlist_weekly_milage'] =  $this->TSModel->sp_rp_devicelocationlist_weekly_milage();
            $this->load->view('globaltemplate/header');
            $this->load->view('home/totalmileagereport',$data);
            $this->load->view('globaltemplate/footer');
        }

        
        
        public function sp_rp_equipments_gtmileage()
        {
            
            $data =$this->TSModel->sp_rp_equipments_gtmileage();
            $sum = "sum(currentmileage)";

          
            if($data)
            {
                foreach($data as $row)
                {
                   
         

            ?>
        <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
  

            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">
                    <i class="fas fa-cog icon-pulse text-indigo-500 mr-2"></i>
                    Total Mileage (Track Solid)
                </h3>
                <p class="text-3xl font-bold"><?php echo number_format($row->$sum, 2, '.', ',');?></p>
            </div>

        </div>
            <?php
           }
        }    
    
    }
        
        
        
        
        
        
        
        
}
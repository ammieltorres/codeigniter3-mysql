
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TSCon extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->database();
        $this->load->helper('form');
        $this->load->library('pagination');
        $this->load->model('TSModel');
        $this->load->model('SPModel');
    }

    public function ViewDevice()
    {
        $nav['title'] = "Device List TS";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('RP_Devicelocationlist/DeviceList');
        $this->load->view('RP_Devicelocationlist/footer');
        $this->load->view('globaltemplate/footer');
    }
    public function testingss()
    {
          $this->db->select('*');
                $this->db->limit('1');
                $token = $this->db->get('sys_token'); 
                $tokendata =  $token->result_array();
    
                foreach($tokendata as $row)
                {
                    $TappKey        = $row['TappKey'];
                    $Taccount       = $row['Taccount'];
                    $TaccessToken   = $row['TAccessToken'];
                    $TrefreshToken  = $row['TrefreshToken'];
                    $TexpiresIn     = $row['TexpiresIn'];
                        
                }
    
    
    
                date_default_timezone_set('UTC');
                $timestamp = date('Y-m-d H:i:s', time());
                $curl = curl_init();
    
    
                $params = array(
                    'timestamp' => $timestamp,
                    'app_key' => $TappKey,
                    'user_id' => $Taccount,
                    'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                    'format' => 'json',
                    'v' => '0.9',
                    'sign_method' => 'md5',
                    'expires_in' => 3600,
                    'method' => 'jimi.user.device.location.list',
                    // 'imei' => '351742101136267',
                    'access_token' => $TaccessToken,
                    'target' => 'GerWeiss'
                );
    
            
                // $dataj = json_encode($data);
                // $api_url = "http://open.10000track.com/route/rest";
                $api_url = "https://hk-open.tracksolidpro.com/route/rest";
                // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
                $client = curl_init($api_url);
                // curl_setopt($client, CURLOPT_URL, APP_URL);
                curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($client, CURLOPT_ENCODING, '');
                curl_setopt($client, CURLOPT_HEADER, 0);
                curl_setopt($client, CURLOPT_TIMEOUT, 0);
                curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
        
                curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
                curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
                curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
               
                $response = curl_exec($client);
               
                echo $response;
    }



    public function ViewDeviceIndex()
    {

            $search = array(
            'Imei'                  => trim($this->input->post('Imei')),
            'deviceName'            => trim($this->input->post('deviceName')),
            'DateStart'             => trim($this->input->post('DateStart')),
            'DateEnd'               => trim($this->input->post('DateEnd'))
            );

            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $config['base_url'] = site_url('TSCon/ViewDeviceIndex/');
            $config['total_rows'] = $this->TSModel->ViewDeviceList($limit, $offset, $search, $count=true);
            $config['per_page'] = $limit;
            $config['uri_segment'] = 3;
            $config['num_links'] = 3;
            $config['num_tag_open']         = '<li>';
            $config['num_tag_close']        = '</li>';
            $config['cur_tag_open']         = '<li><a href="" class="current_page">';
            $config['cur_tag_close']        = '</a></li>';
            $config['next_link']            = '>';
            $config['next_tag_open']        = '<li>';
            $config['next_tag_close']       = '</li>';
            $config['prev_link']            = '<';
            $config['prev_tag_open']        = '<li>';
            $config['prev_tag_close']       = '</li>';
            $config['first_link']           = '<<';
            $config['first_tag_open']       = '<li>';
            $config['first_tag_close']      = '</li>';
            $config['last_link']            = '>>';
            $config['last_tag_open']        = '<li>';
            $config['last_tag_close']       = '</li>';

            $this->pagination->initialize($config);

            $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
            $data['DeviceList'] = $this->TSModel->ViewDeviceList($limit, $offset, $search, $count=false);
            $data['pagelinks'] = $this->pagination->create_links();

            // $this->load->view('templates/afteraddheader');
            $this->load->view('RP_Devicelocationlist/devicelistajax',$data);
    }

    public function tsgetdevice()
    {
            $this->db->select('*');
            $this->db->limit('1');
            $token = $this->db->get('sys_Token'); 
            $tokendata =  $token->result_array();

            foreach($tokendata as $row)
            {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TAccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                    
            }



            date_default_timezone_set('UTC');
            $timestamp = date('Y-m-d H:i:s', time());
            $curl = curl_init();


            $params = array(
                'timestamp' => $timestamp,
                'app_key' => $TappKey,
                'user_id' => $Taccount,
                'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                'format' => 'json',
                'v' => '0.9',
                'sign_method' => 'md5',
                'expires_in' => 3600,
                'method' => 'jimi.user.device.location.list',
                // 'imei' => '351742101136267',
                'access_token' => $TaccessToken,
                'target' => 'GerWeiss'
            );

        
            // $dataj = json_encode($data);
            // $api_url = "http://open.10000track.com/route/rest";
            $api_url = "https://hk-open.tracksolidpro.com/route/rest";
            // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
            $client = curl_init($api_url);
            // curl_setopt($client, CURLOPT_URL, APP_URL);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
    
            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
           
            // echo $response;
    
            $data = json_decode($response);
    
            // print_r($data);
            $array = json_decode(json_encode($data), true);
    
    
     
            $result = [];
            foreach($array as $key => $arrVal) {
               if(!in_array($arrVal, $result)){
                   array_push($result, $arrVal);
               }
            }
            if($result[0] == '1004')
            {
               
                
                $params = array(
                    'app_key' => $TappKey,
                    'expires_in' => 7200,
                    'format' => 'json',
                    'method' => 'jimi.oauth.token.refresh',
                    'sign_method' => 'md5',
                    'timestamp' => $timestamp,
                    'user_id' => $Taccount,
                    'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                    'v' => '0.9',
                );
                ksort($params);
        
                $signVar = "";
                foreach ($params as $key => $value) {$signVar .= $key . $value;}
                if(isset($secretkey))
                {
                     header("refresh: 3");
                }
                $signVarSecret = $secretkey . $signVar . $secretkey;
                $sign = strtoupper(md5($signVarSecret));
                $data = array(
                            "timestamp" => $timestamp,
                            "app_key" => $TappKey,
                            "sign_method" => 'md5',
                            "sign" => $sign,
                            "v" => '0.9',
                            "format" => 'json',
                            "user_id" => 'GerWeiss',
                            "user_pwd_md5" => 'a5aac79a15425e28acafe27c3075fabc',
                            "expires_in" => '7200',
                            'method' => 'jimi.oauth.token.get',
                      
                    );
                    $api_url = "https://hk-open.tracksolidpro.com/route/rest";
                    $client = curl_init($api_url);
                    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($client, CURLOPT_ENCODING, '');
                    curl_setopt($client, CURLOPT_HEADER, 0);
                    curl_setopt($client, CURLOPT_TIMEOUT, 0);
                    curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
                    curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($data));
                    curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
                   
                    $response = curl_exec($client);
                   
                    curl_close($client);
                    $decode = json_decode($response);
        
                    if(empty($decode->code))
                    {
                        echo  $p_TappKey          =  $decode->result->appKey;
                        $p_Taccount         =  $decode->result->account;
                        $p_TAccessToken     =  $decode->result->accessToken;
                        $p_TrefreshToken    =  $decode->result->refreshToken;
                        $p_TexpiresIn       =  $decode->result->expiresIn;
                        $p_Ttime            =  $decode->result->time;
                    
                    
                        $token = array(
            
                            "p_AED"             => 'EDT',
                            "p_TappKey"         => $p_TappKey,
                            "p_Taccount"        => $p_Taccount,
                            "p_TAccessToken"    => $p_TAccessToken,
                            "p_TrefreshToken"   => $p_TrefreshToken,
                            "p_TexpiresIn"      => $p_TexpiresIn,
                            "p_Ttime"           => $p_Ttime,
                        );
                
                        $this->TSModel->sys_Token_AED($token);
                        header("refresh: 3");
                        
                    }
                    else
                    {
                        echo $decode->code;
                        ?><br><?php
                        echo $decode->message;
                    }







            }
            else
            {
                $value = reset($data);
                next($data);
                $info = (next($data));
                // print_r($data);
                if($info)
                {
                         foreach($info as $row)
                        {
                         
                         $val = array(
                            'p_AED'                     => 'ADD',
                            'p_DeviceLocationListID '   => ' ',
                            'p_imei'                    => $row->imei,
                            'p_deviceName'              => $row->deviceName,
                            'p_icon'                    => $row->icon,
                            
                            'p_statusD'                 => $row->status,
                            'p_posType'                 => $row->posType,
                            'p_lat'                     => $row->lat,
                            'p_lng'                     => $row->lng,
                            'p_hbTime'                  => $row->hbTime,
                            
                            'p_accStatus'               => $row->accStatus,
                            'p_gpsSignal'               => $row->gpsSignal,
                            'p_powerValue'              => $row->powerValue,
                            'p_batteryPowerVal'         => $row->batteryPowerVal,
                            'p_speed'                   => $row->speed,
                            
                            
                            'p_gpsNum'                  => $row->gpsNum,
                            'p_gpsTime'                 => $row->gpsTime,
                            'p_direction'               => $row->direction,
                            'p_activationFlag'          => $row->activationFlag,
                            'p_expireFlag'              => $row->expireFlag,
                            
                            
                            'p_electQuantity'           => $row->electQuantity,
                            'p_locDesc'                 => $row->locDesc,
                            'p_distance'                => $row->distance,
                            'p_temperature'             => $row->temperature,
                            'p_trackerOil'              => $row->trackerOil,
                            
                            
                            'p_currentMileage'          => $row->currentMileage,
                            'p_hbTimeSys'               => ' ',
                
                            
        
                             ); 
                             
                             $this->SPModel->sp_rp_DeviceLocationList_AED($val);
                             header("refresh: 60");
                           
                        }
                         header("refresh: 30");
                         date_default_timezone_set('Asia/Manila');
                         
                         ?>
                           <div class="alert alert-success">
                                <?php echo "Success - ". date("Y-m-d h:i:sa"); ?>
                            </div>
                         
                         <?php
                         
                }
                else
                {
                     header("refresh: 2");
                     ?>
                           <div class="alert alert-Danger">
                                <?php echo "Empty - ". date("Y-m-d h:i:sa"); ?>
                            </div>
                         
                    <?php
                }
               
            }

}


public function testing()
{
    echo json_encode($this->input->post('DeviceName'));
}

public function tscron()
{
        $this->db->select('*');
        $this->db->limit('1');
        $token = $this->db->get('sys_Token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TAccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                
        }



        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();


        $params = array(
            'timestamp' => $timestamp,
            'app_key' => $TappKey,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 3600,
            'method' => 'jimi.user.device.location.list',
            // 'imei' => '351742101136267',
            'access_token' => $TaccessToken,
            'target' => 'GerWeiss'
        );

    
        // $dataj = json_encode($data);
        // $api_url = "http://open.10000track.com/route/rest";
        $api_url = "https://hk-open.tracksolidpro.com/route/rest";
        // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
        $client = curl_init($api_url);
        // curl_setopt($client, CURLOPT_URL, APP_URL);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($client, CURLOPT_ENCODING, '');
        curl_setopt($client, CURLOPT_HEADER, 0);
        curl_setopt($client, CURLOPT_TIMEOUT, 0);
        curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
        curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
       
        $response = curl_exec($client);
       
        // echo $response;

        $data = json_decode($response);

        // print_r($data);
        $array = json_decode(json_encode($data), true);


 
        $result = [];
        foreach($array as $key => $arrVal) {
           if(!in_array($arrVal, $result)){
               array_push($result, $arrVal);
           }
        }
        if($result[0] == '1004')
        {
           
            
            $params = array(
                'app_key' => $TappKey,
                'expires_in' => 7200,
                'format' => 'json',
                'method' => 'jimi.oauth.token.refresh',
                'sign_method' => 'md5',
                'timestamp' => $timestamp,
                'user_id' => $Taccount,
                'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                'v' => '0.9',
            );
            ksort($params);
    
            $signVar = "";
            foreach ($params as $key => $value) {$signVar .= $key . $value;}
            $signVarSecret = $secretkey . $signVar . $secretkey;
            $sign = strtoupper(md5($signVarSecret));
            $data = array(
                        "timestamp" => $timestamp,
                        "app_key" => $TappKey,
                        "sign_method" => 'md5',
                        "sign" => $sign,
                        "v" => '0.9',
                        "format" => 'json',
                        "user_id" => 'GerWeiss',
                        "user_pwd_md5" => 'a5aac79a15425e28acafe27c3075fabc',
                        "expires_in" => '7200',
                        'method' => 'jimi.oauth.token.get',
                  
                );
                $api_url = "https://hk-open.tracksolidpro.com/route/rest";
                $client = curl_init($api_url);
                curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($client, CURLOPT_ENCODING, '');
                curl_setopt($client, CURLOPT_HEADER, 0);
                curl_setopt($client, CURLOPT_TIMEOUT, 0);
                curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
                curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($data));
                curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
               
                $response = curl_exec($client);
               
                curl_close($client);
                $decode = json_decode($response);
    
                if(empty($decode->code))
                {
                    echo  $p_TappKey          =  $decode->result->appKey;
                    $p_Taccount         =  $decode->result->account;
                    $p_TAccessToken     =  $decode->result->accessToken;
                    $p_TrefreshToken    =  $decode->result->refreshToken;
                    $p_TexpiresIn       =  $decode->result->expiresIn;
                    $p_Ttime            =  $decode->result->time;
                
                
                    $token = array(
        
                        "p_AED"             => 'EDT',
                        "p_TappKey"         => $p_TappKey,
                        "p_Taccount"        => $p_Taccount,
                        "p_TAccessToken"    => $p_TAccessToken,
                        "p_TrefreshToken"   => $p_TrefreshToken,
                        "p_TexpiresIn"      => $p_TexpiresIn,
                        "p_Ttime"           => $p_Ttime,
                    );
            
                    $this->TSModel->sys_Token_AED($token);
                    // header("refresh: 3");
                    
                }
                else
                {
                    echo $decode->code;
                    ?><br><?php
                    echo $decode->message;
                }







        }
        else
        {
            $value = reset($data);
            next($data);
            $info = (next($data));
            // print_r($data);
            foreach($info as $row)
            {
                 
                 $val = array(
                    'p_AED'                     => 'ADD',
                    'p_DeviceLocationListID '   => ' ',
                    'p_imei'                    => $row->imei,
                    'p_deviceName'              => $row->deviceName,
                    'p_icon'                    => $row->icon,
                    
                    'p_statusD'                 => $row->status,
                    'p_posType'                 => $row->posType,
                    'p_lat'                     => $row->lat,
                    'p_lng'                     => $row->lng,
                    'p_hbTime'                  => $row->hbTime,
                    
                    'p_accStatus'               => $row->accStatus,
                    'p_gpsSignal'               => $row->gpsSignal,
                    'p_powerValue'              => $row->powerValue,
                    'p_batteryPowerVal'         => $row->batteryPowerVal,
                    'p_speed'                   => $row->speed,
                    
                    
                    'p_gpsNum'                  => $row->gpsNum,
                    'p_gpsTime'                 => $row->gpsTime,
                    'p_direction'               => $row->direction,
                    'p_activationFlag'          => $row->activationFlag,
                    'p_expireFlag'              => $row->expireFlag,
                    
                    
                    'p_electQuantity'           => $row->electQuantity,
                    'p_locDesc'                 => $row->locDesc,
                    'p_distance'                => $row->distance,
                    'p_temperature'             => $row->temperature,
                    'p_trackerOil'              => $row->trackerOil,
                    
                    
                    'p_currentMileage'          => $row->currentMileage,
                    'p_hbTimeSys'               => ' ',
        
                    

                     ); 
                     
                     $this->SPModel->sp_rp_DeviceLocationList_AED($val);
                    //  header("refresh: 60");
            }
        }

}




















// MILEAGE SECTION

public function Mileage()
{
        $nav['title'] = "Mileage Report TS";
        $this->load->view('globaltemplate/header');
        $this->load->view('globaltemplate/nav', $nav);
        $this->load->view('RP_Mileage/Mileage');
        $this->load->view('RP_Mileage/MileageFooter');
        $this->load->view('globaltemplate/footer');
}





    public function Mileageindex()
    {

            $search = array(
            'Imei'                      => trim($this->input->post('Imei')),
            'StartTime'                 => trim($this->input->post('StartTime')),
            'EndTime'                   => trim($this->input->post('EndTime')),
            );

            $limit = 10;
            $offset = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $config['base_url'] = site_url('TSCon/Mileageindex/');
            $config['total_rows'] = $this->TSModel->TrackMileage($limit, $offset, $search, $count=true);
            $config['per_page'] = $limit;
            $config['uri_segment'] = 3;
            $config['num_links'] = 3;
            $config['num_tag_open']         = '<li>';
            $config['num_tag_close']        = '</li>';
            $config['cur_tag_open']         = '<li><a href="" class="current_page">';
            $config['cur_tag_close']        = '</a></li>';
            $config['next_link']            = '>';
            $config['next_tag_open']        = '<li>';
            $config['next_tag_close']       = '</li>';
            $config['prev_link']            = '<';
            $config['prev_tag_open']        = '<li>';
            $config['prev_tag_close']       = '</li>';
            $config['first_link']           = '<<';
            $config['first_tag_open']       = '<li>';
            $config['first_tag_close']      = '</li>';
            $config['last_link']            = '>>';
            $config['last_tag_open']        = '<li>';
            $config['last_tag_close']       = '</li>';

            $this->pagination->initialize($config);

            $data['result_count']= "Total Record(s) Found: " . number_format($config['total_rows'], 0);
            $data['DeviceList'] = $this->TSModel->TrackMileage($limit, $offset, $search, $count=false);
            $data['pagelinks'] = $this->pagination->create_links();

            // $this->load->view('templates/afteraddheader');
            $this->load->view('RP_Mileage/MileageAjax',$data);
    }






public function getdeviceBat()
{
    // get token first
    
        $this->db->select('*');
        $this->db->limit('10');
        $token = $this->db->get('sys_Token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
               $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TAccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                
        }
        
        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();




// search all device
     $api_url = "https://hk-open.tracksolidpro.com/route/rest";

        $this->db->select('*');
        $this->db->limit('1');
        $this->db->select('EIME'); 
        $devices = $this->db->get('EIME'); 
        $devicesdata =  $devices->result_array();
          
                    foreach($devicesdata as $row)
                    {
                             echo $EIME = $row['EIME'].',';
                   
                    }

            $params = array(
                'timestamp' => $timestamp,
                'app_key' => $TappKey,
                'user_id' => $Taccount,
                'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                'format' => 'json',
                'v' => '0.9',
                'sign_method' => 'md5',
                'expires_in' => 3600,
                //  'method' => 'jimi.track.device.detail',
                'method' => 'jimi.device.location.URL.share',
                'imei' => '862476053021266',
                        // 862476053029
                'access_token' => $TaccessToken,
                'target' => 'GerWeiss'
            );
    
       
            $client = curl_init($api_url);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
    
            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
    
            $data = json_decode($response);
            $value = reset($data);
            next($data);
            $info = (next($data));
            $dataMileage = json_decode(json_encode($info), true);
            
            print_r($dataMileage);
            
            // if($dataMileage)
            // {
            //               echo $dataMileage['imei'];
            // ?> <br> <?php
            // echo $dataMileage['currentMileage'];
            //       ?> <br> <br> <?php 
            // }
            // echo $dataMileage['imei'];

                   
    
            $data = json_decode($response);
    
            print_r($data);
            $array = json_decode(json_encode($data), true);



 
      
           
        
        


}






public function devicechecker()
{
    $this->db->select('*');
    $this->db->limit('1');
    $token = $this->db->get('sys_Token'); 
    $tokendata =  $token->result_array();

    foreach($tokendata as $row)
    {
            $TappKey        = $row['TappKey'];
            $Taccount       = $row['Taccount'];
            $TaccessToken   = $row['TAccessToken'];
            $TrefreshToken  = $row['TrefreshToken'];
            $TexpiresIn     = $row['TexpiresIn'];
            
    }



    $this->db->select('EIME');
    $this->db->limit('90');
    // $this->db->where('LENGTH(EIME) = 15');
    $EIME =  $this->db->get('EIME'); 
      
    $EIMEdata = $EIME->result_array();
    foreach($EIMEdata as $row)
    {
        

        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();
        $datab= date("Y-m-d",strtotime("-3 day"));
        //   $datab= date("Y-m-d");
        $begdate = "$datab 00:00:00";
        $datae =  date("Y-m-d");
         $enddate= "$datae 23:59:59";    
        $params = array(
            'timestamp' => $timestamp,
            'app_key' => $TappKey,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 3600,
            // 'method' => 'jimi.user.device.location.list',
             'method' => 'jimi.device.track.mileage',
            //  'imeis' => "862476053034392",
             'imeis' => $row['EIME'],

            
            
            //  'imeis' => '862476054229769,862476053034624,862476053034608,862476053034517,862476053034467,862476053034459,862476053034400,862476053034392,862476053034376,862476053034327,862476053034236,862476053034210,862476053034145,862476053034103,862476053034020,862476053031570,862476053031414,862476053031273,862476053029681',
            'begin_time' => "$begdate",
   
             'end_time' => "$enddate",
                // 'begin_time' => "2024-03-10 00:00:00",
                // 'end_time' => '2024-03-11 24:59:59',
   
            //  : yyyy-MM-dd HH:mm:ss
         

            'access_token' => $TaccessToken,
            'target' => 'GerWeiss',
            'MILEAGE' => 'ON'
        );   
   
//   print_r($params);
// echo $begdate;

//   echo $enddate;
    
        // $dataj = json_encode($data);
        // $api_url = "http://open.10000track.com/route/rest";
        $api_url = "https://hk-open.tracksolidpro.com/route/rest";
        // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
        $client = curl_init($api_url);
        // curl_setopt($client, CURLOPT_URL, APP_URL);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($client, CURLOPT_ENCODING, '');
        curl_setopt($client, CURLOPT_HEADER, 0);
        curl_setopt($client, CURLOPT_TIMEOUT, 0);
        curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
        curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
       
         $response = curl_exec($client);
       
        // echo $response;

        $data = json_decode($response);

        ?><br><br><br><?php
        echo $row['EIME']; ?><br><?php
        print_r($data);
    

    }
}



public function tscronmilage()
{
        $this->db->select('*');
        $this->db->limit('1');
        $token = $this->db->get('sys_Token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TAccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                
        }
        
     $this->db->select('EIME');
    if(!isset($_SESSION['conter']))
    {
        $_SESSION['conter'] = '1';
    }

    if($_SESSION['conter'] === "1")
    {
        $_SESSION['conter'] = "2";
        $this->db->order_by('EIME','desc');
    }
    else
    {
        $_SESSION['conter'] = "1";
        $this->db->order_by('EIME','asc');
    }


        $this->db->select('EIME');
        $this->db->limit('90');
        // $this->db->where('LENGTH(EIME) = 15');
        $EIME =  $this->db->get('EIME'); 
        $EIMEdata = $EIME->result_array();
        $imeValues = array_column($EIMEdata, "EIME");
        $implodedString = implode(",", $imeValues);
        $implodedString;
        $string = $implodedString;
        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();
        $datab= date("Y-m-d",strtotime("-3 day"));
        $begdate = "$datab 00:00:00";
        $datae =  date("Y-m-d");
        $enddate= "$datae 23:59:59";    
        $params = array(
            'timestamp' => $timestamp,
            'app_key' => $TappKey,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 3600,
            'method' => 'jimi.device.track.mileage',
            'imeis' => $string,
            'begin_time' => "$begdate",
            'end_time' => "$enddate",
            'access_token' => $TaccessToken,
            'target' => 'GerWeiss',
            'MILEAGE' => 'ON'
        );   
   

        // $api_url = "http://open.10000track.com/route/rest";
        $api_url = "https://hk-open.tracksolidpro.com/route/rest";
        // $api_url = "https://aenterprise.biz/etrike/Swapping/saveattendance";
        $client = curl_init($api_url);
        // curl_setopt($client, CURLOPT_URL, APP_URL);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($client, CURLOPT_ENCODING, '');
        curl_setopt($client, CURLOPT_HEADER, 0);
        curl_setopt($client, CURLOPT_TIMEOUT, 0);
        curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
        curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
       
         $response = curl_exec($client);
       
        // echo $response;

        $data = json_decode($response);

        // print_r($data);
        $array = json_decode(json_encode($data), true);




        $paramsget = array(
            'timestamp' => $timestamp,
            'app_key' => $TappKey,
            'user_id' => $Taccount,
            'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
            'format' => 'json',
            'v' => '0.9',
            'sign_method' => 'md5',
            'expires_in' => 3600,
            'method' => 'jimi.device.location.get',
            // 'imeis' => $string,
            'imeis' => "862476053034392",
            'access_token' => $TaccessToken,
            'target' => 'GerWeiss'
        );

   
        $clientget = curl_init($api_url);
        curl_setopt($clientget, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($clientget, CURLOPT_ENCODING, '');
        curl_setopt($clientget, CURLOPT_HEADER, 0);
        curl_setopt($clientget, CURLOPT_TIMEOUT, 0);
        curl_setopt($clientget, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($clientget, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($clientget, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($clientget, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($clientget, CURLOPT_POSTFIELDS,  http_build_query($params));
        curl_setopt($clientget, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
       
         $responseget = curl_exec($clientget);
     

        $dataget = json_decode($responseget);

        // print_r($dataget);
        // $value = reset($dataget);
        next($dataget);
        next($dataget);
        $infoget = (next($dataget));
        //  $dataMileageget = json_decode(json_encode($infoget), true);
        
 

        foreach($infoget as $row)
        {

            $val = array(
                'p_eime' => $row->imei,
                'p_currentmileage' => $row->totalMileage,
            );

            
            $this->SPModel->sp_rp_equipments_updatemilage($val);
        }






        


 
        $result = [];
        foreach($array as $key => $arrVal) {
           if(!in_array($arrVal, $result)){
               array_push($result, $arrVal);
           }
        }
        if($result[0] == '1004')
        {
           
            
            $params = array(
                'app_key' => $TappKey,
                'expires_in' => 7200,
                'format' => 'json',
                'method' => 'jimi.oauth.token.refresh',
                'sign_method' => 'md5',
                'timestamp' => $timestamp,
                'user_id' => $Taccount,
                'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                'v' => '0.9',
            );
            ksort($params);
    
            $signVar = "";
            foreach ($params as $key => $value) {$signVar .= $key . $value;}
            if(isset($secretkey))
            {
                 header("refresh: 3");
            }
            $signVarSecret = $secretkey . $signVar . $secretkey;
            $sign = strtoupper(md5($signVarSecret));
            $data = array(
                        "timestamp" => $timestamp,
                        "app_key" => $TappKey,
                        "sign_method" => 'md5',
                        "sign" => $sign,
                        "v" => '0.9',
                        "format" => 'json',
                        "user_id" => 'GerWeiss',
                        "user_pwd_md5" => 'a5aac79a15425e28acafe27c3075fabc',
                        "expires_in" => '7200',
                        'method' => 'jimi.oauth.token.get',
                  
                );
                $api_url = "https://hk-open.tracksolidpro.com/route/rest";
                $client = curl_init($api_url);
                curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($client, CURLOPT_ENCODING, '');
                curl_setopt($client, CURLOPT_HEADER, 0);
                curl_setopt($client, CURLOPT_TIMEOUT, 0);
                curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
                curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($data));
                curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
               
                $response = curl_exec($client);
               
                curl_close($client);
                $decode = json_decode($response);
    
                if(empty($decode->code))
                {
                    $p_TappKey          =  $decode->result->appKey;
                    $p_Taccount         =  $decode->result->account;
                    $p_TAccessToken     =  $decode->result->accessToken;
                    $p_TrefreshToken    =  $decode->result->refreshToken;
                    $p_TexpiresIn       =  $decode->result->expiresIn;
                    $p_Ttime            =  $decode->result->time;
                
                
                    $token = array(
        
                        "p_AED"             => 'EDT',
                        "p_TappKey"         => $p_TappKey,
                        "p_Taccount"        => $p_Taccount,
                        "p_TAccessToken"    => $p_TAccessToken,
                        "p_TrefreshToken"   => $p_TrefreshToken,
                        "p_TexpiresIn"      => $p_TexpiresIn,
                        "p_Ttime"           => $p_Ttime,
                    );
            
                    $this->TSModel->sys_Token_AED($token);
                    // header("refresh: 3");
                    
                }
                else
                {
                     $decode->code;
                    ?><br><?php
                     $decode->message;
                }







        }
        else
        {
            
            // print_r($data);
        
            $value = reset($data);
            next($data);  
            // next($data);
            $info = (next($data));
            $dataMileage = json_decode(json_encode($info), true);
                    //  print_r($dataMileage);
            // print_r($dataMileage[0]);
            
            
            
            $i = 0;
            if($dataMileage)
            {
                foreach($dataMileage as $row)
                {
                  $data = $dataMileage[$i];  
             
                    $imei           = $data['imei'];        
                    $startTime      = $data['startTime']; 
                    $endTime        = $data['endTime'];
                    $startLat       = $data['startLat'];        
                    $startLng       = $data['startLng'];
                    $endLat         = $data['endLat'];   
                    $endLng         = $data['endLng'];   
                    $runTimeSecond  = $data['runTimeSecond'];   
                    $distance       = $data['distance'];   
                    $avgSpeed       = $data['avgSpeed']; 
                    
                    $data = array(
                        'p_IMEI'		=>	$imei,
                        'p_StartTime'	=>	$startTime,
                        'p_EndTime'	    =>	$endTime,
                        'p_StartLat'	=>	$startLat,
                        'p_StartLng'	=>	$startLng,
                        'p_EndLat'	    =>	$endLat,
                        'p_EndLng'	    =>	$endLng,
                        'p_Elapsed'	    =>	$runTimeSecond,
                        'p_Distance'	=>	$distance,
                        'p_AvgSpeed'	=>	$avgSpeed,
                        );
          
                    $this->TSModel->rp_TrackMileage_Add($data);
                    $i++;
                }
            }

            if($dataMileage)
            {
                            
            ?>
               <div class="alert alert-success">
                    <?php echo "Success - ". date("Y-m-d h:i:sa"); ?>
                </div>
                         
             <?php
            }
            else
            {
                    ?>
               <div class="alert alert-danger">
                    <?php echo "Empty - ". date("Y-m-d h:i:sa"); ?>
                </div>
                         
             <?php
            }

            
            //   header("refresh: 10");
      
          
        }

}



// GPS Device


public function GPSDevice($imeidata)
{
// get token first
    
        $this->db->select('*');
        $this->db->limit('10');
        $token = $this->db->get('sys_Token'); 
        $tokendata =  $token->result_array();

        foreach($tokendata as $row)
        {
                $TappKey        = $row['TappKey'];
                $Taccount       = $row['Taccount'];
                $TaccessToken   = $row['TAccessToken'];
                $TrefreshToken  = $row['TrefreshToken'];
                $TexpiresIn     = $row['TexpiresIn'];
                
        }
        
        date_default_timezone_set('UTC');
        $timestamp = date('Y-m-d H:i:s', time());
        $curl = curl_init();




// search all device
     $api_url = "https://hk-open.tracksolidpro.com/route/rest";

            $params = array(
                'timestamp' => $timestamp,
                'app_key' => $TappKey,
                'user_id' => $Taccount,
                'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
                'format' => 'json',
                'v' => '0.9',
                'sign_method' => 'md5',
                'expires_in' => 3600,
                //  'method' => 'jimi.track.device.detail',
                'method' => 'jimi.device.location.URL.share',
                'imei' => "$imeidata",
                        // 862476053029
                'access_token' => $TaccessToken,
                'target' => 'GerWeiss'
            );
    
       
            $client = curl_init($api_url);
            curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($client, CURLOPT_ENCODING, '');
            curl_setopt($client, CURLOPT_HEADER, 0);
            curl_setopt($client, CURLOPT_TIMEOUT, 0);
            curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);
    
            curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
            curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
           
            $response = curl_exec($client);
    
            $data = json_decode($response);
            $value = reset($data);
            next($data);
            $info = (next($data));
            $dataMileage = json_decode(json_encode($info), true);
            
            // print_r($dataMileage);
            
            if($dataMileage)
            {
                          $url =  $dataMileage['URL'];
            ?> <br> <?php
                 header("Location:$url");
            die();
                
            }


                   
    
            $data = json_decode($response);
    
            // print_r($data);
            // $array = json_decode(json_encode($data), true);
           
               
            

}



public function gsheetget()
{
    $api_url = "https://script.google.com/macros/s/AKfycbyrSVy4kjmVXCa2avXKrc79_834V1RpkHX0j2lPnVYkrplRpwvXsEbkKkCHw3zPCAuv/exec";

    // $params = array(
    //     'timestamp' => $timestamp,
    //     'app_key' => $TappKey,
    //     'user_id' => $Taccount,
    //     'user_pwd_md5' => 'a5aac79a15425e28acafe27c3075fabc',
    //     'format' => 'json',
    //     'v' => '0.9',
    //     'sign_method' => 'md5',
    //     'expires_in' => 3600,
    //     //  'method' => 'jimi.track.device.detail',
    //     'method' => 'jimi.device.location.URL.share',
    //     'imei' => "$imeidata",
    //             // 862476053029
    //     'access_token' => $TaccessToken,
    //     'target' => 'GerWeiss'
    // );


    $client = curl_init($api_url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($client, CURLOPT_ENCODING, '');
    curl_setopt($client, CURLOPT_HEADER, 0);
    curl_setopt($client, CURLOPT_TIMEOUT, 0);
    curl_setopt($client, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($client, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($client, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($client, CURLOPT_CUSTOMREQUEST, 'GET');
    // curl_setopt($client, CURLOPT_POSTFIELDS,  http_build_query($params));
    curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
   
     $response = curl_exec($client);
     
    $data =  json_decode($response);

    foreach($data as $row)
    {
        // echo $row->LastName;?> <br><?php
    }

}
















}
?>
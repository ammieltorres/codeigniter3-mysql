<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {

    parent::__construct();
    $this->load->helper(array('url'));
    $this->load->database();
    $this->load->helper('form');
    $this->load->model('Loginmodel');
    }


	public function Userlogin()
	{
        $data['title'] = 'Login';
        $this->load->view('FS_login/header');
		$this->load->view('FS_login/login',$data);
        $this->load->view('globaltemplate/footer');
	}



    function LoginValidation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('UserID' ,'UserID', 'required');
        $this->form_validation->set_rules('Password' ,'Password', 'required');
        if($this->form_validation->run())
        {
            $UserID = $this->input->post('UserID');
            $Password = $this->input->post('Password');
            $login = $this->Loginmodel->can_login($UserID, $Password);
       
            if($login)
            {
                foreach ($login as $data)
                {
                    $UserIDQ        =   $data->UserID;
                    $Branch         =   $data->Branch;
                    $BranchCode     =   $data->BranchCode;
                    $LName          =   $data->LName;
                    $FName          =   $data->FName;
                    $MName          =   $data->MName;

                    $Category       =   $data->Category;

                //Menu ==================================
                    //Scan
                    $M10000          =   $data->M10000;
                    $M10100          =   $data->M10100;
                    $M10200          =   $data->M10200;
                    $M10300          =   $data->M10300;
                    $M10400          =   $data->M10400;

                    //Reports
                    $M20000          =   $data->M20000;
                    $M20100          =   $data->M20100;
                    $M20200          =   $data->M20200;
                    $M20300          =   $data->M20300;

                    //Admin
                    $M30000          =   $data->M30000;
                    $M30100          =   $data->M30100;
                    $M30200          =   $data->M30200;
                    $M30300          =   $data->M30300;
                    $M30400          =   $data->M30400;

                    //Settings
                    $M40000          =   $data->M40000;
                    $M40100          =   $data->M40100;
                    $M40200          =   $data->M40200;
                }
                $session_data = array(
                    'UserID'        => $UserIDQ,
                    'Branch'        => $Branch,
                    'BranchCode'    => $BranchCode,
                    'LName'         => $LName,
                    'FName'         => $FName,
                    'MName'         => $MName,

                    'Category'      => $Category,

                    'M10000'         => $M10000,
                    'M10100'         => $M10100,
                    'M10200'         => $M10200,
                    'M10300'         => $M10300,
                    'M10400'         => $M10400,

                    'M20000'         => $M20000,
                    'M20100'         => $M20100,
                    'M20200'         => $M20200,
                    'M20300'         => $M20300,

                    'M30000'         => $M30000,
                    'M30100'         => $M30100,
                    'M30200'         => $M30200,
                    'M30300'         => $M30300,
                    'M30400'         => $M30400,

                    'M40000'         => $M40000,
                    'M40100'         => $M40100,
                    'M40200'         => $M40200,
                );
                $this->session->set_userdata($session_data);
                if($Category === 'C')
                {
                    redirect(base_url(). 'Dashboard/lowvoltagebattery');
                }
                else
                {
                 redirect(base_url(). 'Home/Homepage');   
                }
                
            }
            else
            {
                $this->session->set_flashdata('error', ' USERID and PASSWORD Does Not Match');
                redirect($_SERVER['HTTP_REFERER']);
            }


        }
        else
        {
            $data['title'] = 'Login';
            $this->load->view('FS_login/header');
            $this->load->view('FS_login/login',$data);
        }
    }

    function logout()  
    {  
        $this->session->unset_userdata('UserID');  
        $this->session->unset_userdata('Site');  
        session_unset();
        session_destroy();
        redirect(base_url() . 'Login/Userlogin');  
        
    }  
    
    
    // ================= login rfid =================================
    
    
    
    	public function Userloginrfid()
	{
        $data['title'] = 'Login';
        $this->load->view('FS_login/header');
		$this->load->view('FS_loginrfid/login',$data);
        $this->load->view('globaltemplate/footer');
	}



    function LoginValidationrfid()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('RFID' ,'RFID', 'required');
        // $this->form_validation->set_rules('Password' ,'Password', 'required');
        if($this->form_validation->run())
        {
            $RFID = trim($this->input->post('RFID'));
// $RFID = '004981300';            
            
            // $Password = $this->input->post('Password');
            $login = $this->Loginmodel->can_loginrfid($RFID);
       
            if($login)
            {
                foreach ($login as $data)
                {
                    $UserIDQ        =   $data->UserID;
                    $Branch         =   $data->Branch;
                    $BranchCode     =   $data->BranchCode;
                    $LName          =   $data->LName;
                    $FName          =   $data->FName;
                    $MName          =   $data->MName;

                    $Category       =   $data->Category;

                //Menu ==================================
                    //Scan
                    $M10000          =   $data->M10000;
                    $M10100          =   $data->M10100;
                    $M10200          =   $data->M10200;
                    $M10300          =   $data->M10300;
                    $M10400          =   $data->M10400;

                    //Reports
                    $M20000          =   $data->M20000;
                    $M20100          =   $data->M20100;
                    $M20200          =   $data->M20200;
                    $M20300          =   $data->M20300;

                    //Admin
                    $M30000          =   $data->M30000;
                    $M30100          =   $data->M30100;
                    $M30200          =   $data->M30200;
                    $M30300          =   $data->M30300;
                    $M30400          =   $data->M30400;

                    //Settings
                    $M40000          =   $data->M40000;
                    $M40100          =   $data->M40100;
                    $M40200          =   $data->M40200;
                }
                $session_data = array(
                    'UserID'        => $UserIDQ,
                    'Branch'        => $Branch,
                    'BranchCode'    => $BranchCode,
                    'LName'         => $LName,
                    'FName'         => $FName,
                    'MName'         => $MName,

                    'Category'      => $Category,

                    'M10000'         => $M10000,
                    'M10100'         => $M10100,
                    'M10200'         => $M10200,
                    'M10300'         => $M10300,
                    'M10400'         => $M10400,

                    'M20000'         => $M20000,
                    'M20100'         => $M20100,
                    'M20200'         => $M20200,
                    'M20300'         => $M20300,

                    'M30000'         => $M30000,
                    'M30100'         => $M30100,
                    'M30200'         => $M30200,
                    'M30300'         => $M30300,
                    'M30400'         => $M30400,

                    'M40000'         => $M40000,
                    'M40100'         => $M40100,
                    'M40200'         => $M40200,
                );
                $this->session->set_userdata($session_data);
                unset($_SESSION['error']);
                redirect(base_url(). 'RFID/ScanSwapping');
            }
            else
            {
                $this->session->set_flashdata('error', 'INVALID RFID');
                redirect($_SERVER['HTTP_REFERER']);
            }


        }
        else
        {
            $data['title'] = 'Login';
            $this->load->view('FS_loginrfid/header');
            $this->load->view('FS_loginrfid/login',$data);
        }
    }

    function logoutrfid()  
    {  
        $this->session->unset_userdata('UserID');  
        $this->session->unset_userdata('Site');  
        session_unset();
        session_destroy();
        redirect(base_url() . 'Login/Userloginrfid');  
        
    }  

}
?>
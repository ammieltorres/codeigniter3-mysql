

     




<style>

.img
{
    width: 50px;
    height: 50px;
}


@import url('https://fonts.googleapis.com/css?family=Poppins:400,500,700');


.navbar.navbar-expand-md.navbar-light.navbar-default.bg-light.sticky-top{
  position: fixed;
  width: 100%;
  background-color: rgb(255, 255, 255);
  transition: .3s;
  }



.container-fluid .padding{
justify-content: center;
padding: 5rem 5rem 5rem 5rem ;
}



.navbar-default{
background-color: transparent;
opacity: 80%;
margin: 0;

}








.iconDetails {
margin-left:2%;
float:left; 
height:40px;
width:40px; 
} 

.container2 {
   width:100%;
   height:auto;
   padding:1%;
}




</style>







<body>





<center>


<div id="printableArea">





<div class="col-md-12 ">
  <div class="panel panel-default ">


    <div class="form-result">
 
      <div class="row justify-content-md-center">                                        
    <div class="col-xs-6 co lg-sm-6 col-md-6 ">       
    <canvas  hidden="" style=' width: 150%; 'id="qr-canvas"></canvas>
    </div>

      <div>
    <div>
  <div>
<div>




      <canvas  hidden="" id="qr-canvas"></canvas>

      <div id="qr-result" hidden="">
      
      </div>
                


      <div class="container mx-auto px-4 flex justify-center items-center">
      <div class="flex flex-col space-y-4 ">
    <a href="<?php echo base_url('RFID/ScanSwapping') ?>" class="rounded-full bg-green-500 text-white px-4 py-2">SCAN SWAPPING</a>
   
  </div>
</div>
<br>
<form id="search">
  <div class="form-group">

    <input type="text" class="rounded-lg border-red-800 focus:border-red-500 focus:ring-red-500" name="ID" id="ID" autofocus></input>

  </div>



    <script src="<?php echo base_url('js/qr_packed.js') ?>"></script>

        <h1 class="uppercase text-2xl font-bold text-red-700 transition-all duration-300 animate-pulse ">please scan the RFID</h1>
  <!-- <a class="btn btn-info" id="btn-scan-qr">
       Scan     
  </a>
  <a class="btn btn-danger" id="btn-stopscan-qr">
       Scan stop
  </a> -->
  
  
  <button  class="btn btn-success" type="submit" id ="submit"name="submit" hidden>search</button>


</form>
<form id="submitrecord">
          <div id="result"></div>
</form>


</html>
</center>

<script>


// $(document).ready(function(){
//  $("#btn-scan-qr").trigger('click');
// });
</script>
<script>



const qrcodes = window.qrcode;

const video = document.createElement("video");
const canvasElement = document.getElementById("qr-canvas");
const canvas = canvasElement.getContext("2d");

const qrResult = document.getElementById("qr-result");
const ID = document.getElementById("ID");
const btnScanQR = document.getElementById("btn-scan-qr");
const btnStopScanQR = document.getElementById("btn-stopscan-qr");


let scanning = false;

qrcodes.callback = res => {
  if (res) {
    ID.value = res;
    scanning = false;
    // document.getElementById('submit').click();
    video.srcObject.getTracks().forEach(track => {
      track.stop();
    });
    // alert('a');
    
    document.getElementById('submit').click();
    // navigator.mediaDevices
    // .getUserMedia({ video: { facingMode: "environment" } })
    // .then(function(stream) {
    //   scanning = true;
    //   qrResult.hidden = true;
    //   btnScanQR.hidden = false;
    //   canvasElement.hidden = false;
    //   video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
    //   video.srcObject = stream;
    //   video.play();
    //   tick();
    //   scan();
    // });
   
  }
};



btnStopScanQR.onclick = () => {
    video.srcObject.getTracks().forEach(track => {
      track.stop();
    });
    qrResult.hidden = false;
    canvasElement.hidden = true;
    btnScanQR.hidden = false;
};


btnScanQR.onclick = () => {
  navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      btnScanQR.hidden = false;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
};

function tick() {
  canvasElement.height ='1400' ;
  canvasElement.width = '1400';
  canvas.drawImage(video, 0, 0,canvasElement.width, canvasElement.height);

  scanning && requestAnimationFrame(tick);
  
}


function scan() {
  try {
    qrcodes.decode();
  } catch (e) {
    setTimeout(scan, 500);
    
  }
}

    </script>



<script>
  $('#search').unbind("submit");
    $("#search").submit(function(e) 
    {
        console.log('a');
      e.preventDefault();
			var ID            = $("#ID").val();
      // var status            = $("#status").val();

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('RFID/queryRFIDC/') ?>",
				data:  "ID=" + ID,		
				
				success: function(response) {
					console.log(response);
                    $("#result").html(response);
                    $("#ID").val('');
                    var input = document.getElementById("ID").focus()
				}
			});
            return false;
		});
</script>

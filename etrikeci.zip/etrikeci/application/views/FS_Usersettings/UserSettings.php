
<hr>
<div class="box">
	<div class="row">

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">

                        <div class="row">
                        <div class="col-xs-2 col-sm-2 col-md-2">
                                <label for="UserID">UserID</label>
						        <input type="text" class="form-control" name="UserID" id="UserID" placeholder="UserID" />
                            </div> 
           
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <label for="LName">Last Name</label>
						        <input type="text" class="form-control" name="LName" id="LName" placeholder="Last Name" />
                            </div> 
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <label for="FName">First Name</label>
						        <input type="text" class="form-control" name="FName" id="FName" placeholder="First Name" />
                            </div> 
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <label for="MName">Middle Name</label>
						        <input type="text" class="form-control" name="MName" id="MName" placeholder="Middle Name" />
                            </div> 
              
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <label for="BranchCode">Branch</label>
                                <select  type="text" name="BranchCode" id="BranchCode" class="form-control input-sm" value="">
                                    <option value="" placeholder="">Branch</option>
                                                <?php 

                                                        foreach($Branch as $Branch)
                                                        { 
                                                        echo '<option value="'.$Branch->BranchCode.'">'.$Branch->Branch.'</option>';
                                                        }
                                                        

                                                ?>
                                </select>
                            </div> 

                        </div>
                        <br>
                     
                        <div class="row">
                        <div class="col-xs-4 col-sm-4 col-md-4">
                                <button type="button" id="searchBtn" class="w-100 focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">Search</button>
                            </div>
                            
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <button type="button" id="resetBtn" class="w-100 focus:outline-none text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:focus:ring-yellow-900">Clear Texbox</button>
                            </div>
             
                        
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <button type="button" id="Adduser" data-toggle="modal" data-target="#ADDUserAccessModal"class="w-100 text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">Add User</button>
                            </div>
                        </div>
                        </form>
					</div>
				</div>
				
			</div>
		</div>
	</div>

<hr>
<!-- --------------------- -->

	<div class="row">
		<div class="col-md-12">
			<div id="ajaxContent"></div>
		</div>
	</div>


</div>




<div class="modal" id="message"  tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">MESSAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div id="messagemodal"></div>
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="UserAccessModal" tabindex="-1" role="dialog" aria-labelledby="UserAccessModal" aria-hidden="true">
  <div class="modal-dialog  modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="UserAccessModal">USER ACCESS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="EDTUSER">


            
            <div class="modal-body">
   

                            <div id="UserAccess"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn btn-secondary text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" id="srch" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success  text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800" >Edit User</button>
            </div>
            </form>
            </form>

    </div>
  </div>
</div>



<div class="modal fade" id="ADDUserAccessModal" tabindex="-1" role="dialog" aria-labelledby="ADDUserAccessModal" aria-hidden="true">
  <div class="modal-dialog  modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ADDUserAccessModal">ADD USER</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

            <div class="modal-body">
<form  Method="POST" id="ADDUSER">

            <div class="row">
            <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="UserIDADD">UserID</label>
                        <input type="text" class="form-control" name="UserIDADD" id="UserIDADD" value ="" placeholder="UserID"  required/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="BranchADD">Branch</label>
                        <select  type="text" name="BranchADD" id="BranchADD" class="form-control input-sm" value="">
                                    <option value="" placeholder="">Branch</option>
                                                <?php 

                                                        foreach($Branchadd as $Branch)
                                                        { 
                                                        echo '<option value="'.$Branch->BranchCode.'|'.$Branch->Branch.'">'.$Branch->Branch.'</option>';
                                                        }
                                                        

                                                ?>
                                </select>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                                        <label for="CategoryADD">Category</label>
                                        <select  type="text" name="CategoryADD" id="CategoryADD" class="form-control input-sm" value="" required>
                                                            <option value="" placeholder="">Category</option>                                                   
                                                            <option value="A">Admin</option>
                                                            <option value="S">Scan only</option>      
                                                 
                                        </select>
                                    </div>
            </div>

            <div class="row">
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="LNameADD">Last Name</label>
                        <input type="text" class="form-control" name="LNameADD" id="LNameADD" value ="" placeholder="First Name"  required/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="BranchADD">First Name</label>
                        <input type="text" class="form-control" name="FNameADD" id="FNameADD" value ="" placeholder="Last Name" required/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="BranchADD">Middle Name</label>
                        <input type="text" class="form-control" name="MNameADD" id="MNameADD" value ="" placeholder="Middle Name" required/>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                        <label for="BranchADD">Password</label>
                        <input type="text" class="form-control" name="UserPasswordADD" id="UserPasswordADD" value ="" placeholder="Password" required/>
                </div>
            </div>

            <hr>
<!-- ============================ Scan ========================== -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="ScanADD"><b>Scan</b></label>
                        <select  type="text" name="M10000ADD" id="M10000ADD" class="form-control input-sm" required>
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 

                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10100ADD">Swapping</label>
                        <select  type="text" name="M10100ADD" id="M10100ADD" class="form-control input-sm" required>
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10200ADD">Swapping (NEW)</label>
                        <select  type="text" name="M10200ADD" id="M10200ADD" class="form-control input-sm" required>
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10300ADD">Battery Charge</label>
                        <select  type="textM10300" name="M10300ADD" id="M10300ADD" class="form-control input-sm" required>
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10400ADD">Repair</label>
                        <select  type="text" name="M10400ADD" id="M10400ADD" class="form-control input-sm" required>
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
            </div>
        <hr>
<!-- ============================ Reports ========================== -->
        <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M20000ADD"><b>Reports</b></label>
                        <select  type="text" name="M20000ADD" id="M20000ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>            
                                <option value="Y">Permit </option>      
                        </select>
                </div> 

                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20100ADD">Swapping Reports</label>
                        <select  type="text" name="M20100ADD" id="M20100ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option> 
                                <option value="Y">Permit </option>      
                                     
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20200ADD">Battery Reports</label>
                        <select  type="text" name="M20200ADD" id="M20200ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>      
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20300ADD">Log Reports</label>
                        <select  type="text" name="M20300ADD" id="M20300ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>       
                        </select>
                </div> 
            </div>
            <hr>
<!-- ============================ Admin ========================== -->
        <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M30000ADD"><b>Admin</b></label>
                        <select  type="text" name="M30000ADD" id="M30000ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>      
                        </select>
                </div> 

                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30100ADD">Battery Status</label>
                        <select  type="text" name="M30100ADD" id="M30100ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>       
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30200ADD">Unit Status</label>
                        <select  type="text" name="M30200ADD" id="M30200ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>        
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30300ADD">Driver Status</label>
                        <select  type="text" name="M30300ADD" id="M30300ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>       
                        </select>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M30400ADD">Charger Status</label>
                        <select  type="text" name="M30400ADD" id="M30400ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>       
                        </select>
                </div> 
            </div>
            <hr>
<!-- ============================ Admin ========================== -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M40000ADD"><b>Settings</b></label>
                        <select  type="text" name="M40000ADD" id="M40000ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>      
                        </select>
                </div> 

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M40100ADD">Battery Status</label>
                        <select  type="text" name="M40100ADD" id="M40100ADD" class="form-control input-sm" required>
                                <option value="N">Prohibit </option>          
                                <option value="Y">Permit </option>       
                        </select>
                </div> 
            </div>
                                                            
            </div>
            <div class="modal-footer">
                <button type="Submit" class="btn btn-success  text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"  >Submit</button>
                <button type="button" class="btn btn-secondary btn btn-secondary text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" id="srch" data-dismiss="modal">Close</button>
               
            </div>
            </form>
    </div>

  </div>
</div>




     
         





<script>
    $('#ADDUSER').unbind("submit");
    $("#ADDUSER").submit(function(e) 
    {
      e.preventDefault();

      var UserIDADD              = $("#UserIDADD").val();
      var UserPasswordADD        = $("#UserPasswordADD").val();
      var LNameADD               = $("#LNameADD").val();
      var FNameADD               = $("#FNameADD").val();
      var MNameADD               = $("#MNameADD").val();

      var BranchADD              = $("#BranchADD").val();
      var CategoryADD            = $("#CategoryADD").val();
      
      var aM10000ADD             = $("#M10000ADD").val();
      var aM10100ADD             = $("#M10100ADD").val();
      var aM10200ADD             = $("#M10200ADD").val();
      var aM10300ADD             = $("#M10300ADD").val();

      var aM10400ADD             = $("#M10400ADD").val();
      var aM20000ADD             = $("#M20000ADD").val();
      var aM20100ADD             = $("#M20100ADD").val();
      var aM20200ADD             = $("#M20200ADD").val();
      var aM20300ADD             = $("#M20300ADD").val();


      var aM30000ADD             = $("#M30000ADD").val();
      var aM30100ADD             = $("#M30100ADD").val();
      var aM30200ADD             = $("#M30200ADD").val();
      var aM30300ADD             = $("#M30300ADD").val();
      var aM40000ADD             = $("#M40000ADD").val();
      var aM30400ADD             = $("#aM30400ADD").val();

      var aM40100ADD             = $("#M40100ADD").val();

    

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Settings/ADDUSER/') ?>",
				data:   "UserIDADD=" + UserIDADD + 
                                        "&UserPasswordADD=" + UserPasswordADD + 
                                        "&LNameADD=" + LNameADD + 
                                        "&FNameADD=" + FNameADD +
                                        "&MNameADD=" + MNameADD +

                                        "&BranchADD=" + BranchADD +
                                        "&CategoryADD=" + CategoryADD +
                                        
                                        "&M10000ADD=" + aM10000ADD +
                                        "&M10100ADD=" + aM10100ADD +
                                        "&M10200ADD=" + aM10200ADD +
                                        "&M10300ADD=" + aM10300ADD +

                                        "&M10400ADD=" + aM10400ADD +
                                        "&M20000ADD=" + aM20000ADD +
                                        "&M20100ADD=" + aM20100ADD +
                                        "&M20200ADD=" + aM20200ADD +
                                        "&M20300ADD=" + aM20300ADD +

                                        "&M30000ADD=" + aM30000ADD +
                                        "&M30100ADD=" + aM30100ADD +
                                        "&M30200ADD=" + aM30200ADD +
                                        "&M30300ADD=" + aM30300ADD +
                                        "&M30400ADD=" + aM30400ADD +

                                        "&M40000ADD=" + aM40000ADD +

                                        "&M40100ADD=" + aM40100ADD,
				
				success: function(response) {
     
					console.log(response);
                                        $('#ADDUserAccessModal').modal('hide');
                                        $('#message').modal('toggle');
                                        $("#messagemodal").html(response);
		
    
				}
			});
            return false;
		});
</script>

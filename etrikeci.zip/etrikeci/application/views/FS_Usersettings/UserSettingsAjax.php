


<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <!-- <th>Branch</th> -->
                <th>Action</th>
                <th>Branch</th>
                <th>UserID</th>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>

    
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($BatteryReports))
                {
                
                ?>

                    <?php foreach ($BatteryReports as $row) 
                    {
                      ?>
                        <tr>
                        <td><button class="btn btn-primary" id="EdtuserAccess" value="<?php echo $row->UserID?>">Edit User Access</button></td>

                            <td><?php echo $row->Branch ?></td>
                            <td><?php echo $row->UserID ?></td>
                            <td><?php echo $row->LName ?></td>
                            <td><?php echo $row->FName ?></td>
                            <td><?php echo $row->MName ?></td>
                           
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>



<script>

$(document).on('click', "#EdtuserAccess", function(event) {

  var UserID = $(this).val();

  $.ajax({
    method: "POST",
    url: "<?php echo site_url('Settings/UserAcess/') ?>",
    data:  "UserID=" + UserID,
    
    success: function(response) {
      console.log(response);
      $("#UserAccess").html(response);
      $('#UserAccessModal').modal('toggle');

      
    }
  });

   
});

</script>
<?php
    if($User)
    {
        foreach($User as $row)
        {
        ?>

     
            <div class="row">
            <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="UserIDEDT">UserID</label>
                        <input type="text" class="form-control" name="UserIDEDT" id="UserIDEDT" value ="<?php echo $row['UserID']; ?>" onkeypress="return false;" readonly/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="BranchEDT">Branch</label>
                        <select  type="text" name="BranchEDT" id="BranchEDT" class="form-control input-sm" value="">
                                    <option value="<?php echo $row['BranchCode'].'|'.$row['Branch'];?>" placeholder=""><?php echo $row['Branch'];?></option>
                                                <?php 

                                                        foreach($Branchedt as $Branch)
                                                        { 
                                                        echo '<option value="'.$Branch->BranchCode.'|'.$Branch->Branch.'">'.$Branch->Branch.'</option>';
                                                        }
                                                        

                                                ?>
                                </select>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                                        <label for="CategoryEDT">Category</label>
                                        <select  type="text" name="CategoryEDT" id="CategoryEDT" class="form-control input-sm" value="" required>
                                                            <option value="<?php echo $row['Category'];?>" placeholder=""><?php echo $row['Category'];?></option>                                                   
                                                            <option value="A">Admin</option>
                                                            <option value="S">Scan only</option>      
                                                 
                                        </select>
                </div>



            </div>

            <div class="row">
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="LNameEDT">Last Name</label>
                        <input type="text" class="form-control" name="LNameEDT" id="LNameEDT" value ="<?php echo $row['LName']; ?>" onkeypress="return false;" readonly/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="FNameEDT">First Name</label>
                        <input type="text" class="form-control" name="FNameEDT" id="FNameEDT" value ="<?php echo $row['FName']; ?>" onkeypress="return false;" readonly/>
                </div>
                <div class="col-xs-4 col-sm-4 col-md-4">
                        <label for="MNameEDT">Middle Name</label>
                        <input type="text" class="form-control" name="MNameEDT" id="MNameEDT" value ="<?php echo $row['MName']; ?>" onkeypress="return false;" readonly/>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                        <label for="UserPasswordEDT">Password</label>
                        <input type="Password" class="form-control" name="UserPasswordEDT" id="UserPasswordEDT" value ="<?php echo $row['UserPassword']; ?>" placeholder="Password" required/>
                </div>
            </div>

            <hr>
<!-- ============================ Scan ========================== -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M10000EDT"><b>Scan</b></label>
                        <select  type="text" name="M10000EDT" id="M10000EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M10000'];?>" placeholder=""><?php if($row['M10000'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>                
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 

                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10100EDT">Swapping</label>
                        <select  type="text" name="M10100EDT" id="M10100EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M10100'];?>" placeholder=""><?php if($row['M10100'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>              
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10200EDT">Swapping (NEW)</label>
                        <select  type="text" name="M10200EDT" id="M10200EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M10200'];?>" placeholder=""><?php if($row['M10200'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>            
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10300EDT">Battery Charge</label>
                        <select  type="text" name="M10300EDT" id="M10300EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M10300'];?>" placeholder=""><?php if($row['M10300'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>             
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-3 col-sm-3 col-md-3">
                    <label for="M10400EDT">Repair</label>
                        <select  type="text" name="M10400EDT" id="M10400EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M10400'];?>" placeholder=""><?php if($row['M10400'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>                
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
            </div>
        <hr>
<!-- ============================ Reports ========================== -->
        <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M20000EDT"><b>Reports</b></label>
                        <select  type="text" name="M20000EDT" id="M20000EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M20000'];?>" placeholder=""><?php if($row['M20000'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>                
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 

                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20100EDT">Swapping Reports</label>
                        <select  type="text" name="M20100EDT" id="M20100EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M20100'];?>" placeholder=""><?php if($row['M20100'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>              
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20200EDT">Battery Reports</label>
                        <select  type="text" name="M20200EDT" id="M20200EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M20200'];?>" placeholder=""><?php if($row['M20200'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>            
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M20300EDT">Log Reports</label>
                        <select  type="text" name="M20300EDT" id="M20300EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M20300'];?>" placeholder=""><?php if($row['M20300'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>             
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
            </div>
            <hr>
<!-- ============================ Admin ========================== -->
        <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M30000EDT"><b>Admin</b></label>
                        <select  type="text" name="M30000EDT" id="M30000EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M30000'];?>" placeholder=""><?php if($row['M30000'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>                
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 

                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30100EDT">Battery Status</label>
                        <select  type="text" name="M30100EDT" id="M30100EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M30100'];?>" placeholder=""><?php if($row['M30100'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>              
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30200EDT">Unit Status</label>
                        <select  type="text" name="M30200EDT" id="M30200EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M30200'];?>" placeholder=""><?php if($row['M30200'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>            
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-4 col-sm-4 col-md-4">
                    <label for="M30300EDT">Driver Status</label>
                        <select  type="text" name="M30300EDT" id="M30300EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M30300'];?>" placeholder=""><?php if($row['M30300'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>             
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M30400EDT">Charger Status</label>
                        <select  type="text" name="M30400EDT" id="M30400EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M30400'];?>" placeholder=""><?php if($row['M30400'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>             
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
            </div>
            <hr>
<!-- ============================ Admin ========================== -->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M40000EDT"><b>Settings</b></label>
                        <select  type="text" name="M40000EDT" id="M40000EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M40000'];?>" placeholder=""><?php if($row['M40000'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>                
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <label for="M40100EDT">Battery Status</label>
                        <select  type="text" name="M40100EDT" id="M40100EDT" class="form-control input-sm">
                                <option value="<?php echo $row['M40100'];?>" placeholder=""><?php if($row['M40100'] === 'Y'){?> Permit <?php }else{ ?> Prohibit <?php }  ?></option>              
                                <option value="Y">Permit </option>      
                                <option value="N">Prohibit </option>      
                        </select>
                </div> 
            </div>

          
        <?php
        }
    }
    else
    {
        ?>
            <div class="alert alert-info">
                No Record Found.
            </div>
        <?php
    }
?>





 





<script>
    $('#EDTUSER').unbind("submit");
    $("#EDTUSER").submit(function(e) 
    {
      e.preventDefault();

      var UserIDEDT              = $("#UserIDEDT").val();
      var UserPasswordEDT        = $("#UserPasswordEDT").val();
      var LNameEDT               = $("#LNameEDT").val();
      var FNameEDT               = $("#FNameEDT").val();
      var MNameEDT               = $("#MNameEDT").val();

      var BranchEDT              = $("#BranchEDT").val();
      var CategoryEDT            = $("#CategoryEDT").val();

      
      var aM10000EDT             = $("#M10000EDT").val();
      var aM10100EDT             = $("#M10100EDT").val();
      var aM10200EDT             = $("#M10200EDT").val();
      var aM10300EDT             = $("#M10300EDT").val();

      var aM10400EDT             = $("#M10400EDT").val();
      var aM20000EDT             = $("#M20000EDT").val();
      var aM20100EDT             = $("#M20100EDT").val();
      var aM20200EDT             = $("#M20200EDT").val();
      var aM20300EDT             = $("#M20300EDT").val();

      var aM30000EDT             = $("#M30000EDT").val();
      var aM30100EDT             = $("#M30100EDT").val();
      var aM30200EDT             = $("#M30200EDT").val();
      var aM30300EDT             = $("#M30300EDT").val();
      var aM30400EDT             = $("#M30400EDT").val();

      
      var aM40000EDT             = $("#M40000EDT").val();
      
      var aM40100EDT             = $("#M40100EDT").val();

    

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Settings/EDTUSER/') ?>",
				data:   "UserIDEDT=" + UserIDEDT + 
                                        "&UserPasswordEDT=" + UserPasswordEDT + 
                                        "&LNameEDT=" + LNameEDT + 
                                        "&FNameEDT=" + FNameEDT +
                                        "&MNameEDT=" + MNameEDT +
                                        
                                        "&BranchEDT=" + BranchEDT +
                                        "&CategoryEDT=" + CategoryEDT +

                                        
                                        "&M10000EDT=" + aM10000EDT +
                                        "&M10100EDT=" + aM10100EDT +
                                        "&M10200EDT=" + aM10200EDT +
                                        "&M10300EDT=" + aM10300EDT +

                                        "&M10400EDT=" + aM10400EDT +
                                        "&M20000EDT=" + aM20000EDT +
                                        "&M20100EDT=" + aM20100EDT +
                                        "&M20200EDT=" + aM20200EDT +
                                        "&M20300EDT=" + aM20300EDT +

                                        "&M30000EDT=" + aM30000EDT +
                                        "&M30100EDT=" + aM30100EDT +
                                        "&M30200EDT=" + aM30200EDT +
                                        "&M30300EDT=" + aM30300EDT +
                                        "&M30400EDT=" + M30400EDT +

                                        "&M40000EDT=" + aM40000EDT +
                                        
                                        "&M40100EDT=" + aM40100EDT,
				
				success: function(response) {
     
					console.log(response);
  
                                        $('#UserAccessModal').modal('hide');
                                        $('#message').modal('toggle');
                                        $("#messagemodal").html(response);
				}
			});
            return false;
		});
</script>

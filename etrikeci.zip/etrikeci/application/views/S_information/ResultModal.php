<?php
if($result)
{
    foreach($result as $row)
    {


        $unitdata = $row->v_vunit;
        $batterydata = $row->v_vbattery;
        $driverdata = $row->v_vdriver;


        if(empty($unitdata))
        {
            ?>
                <div class="alert alert-danger" role="alert">
                        UNIT NOT AVAILABLE <?php echo $row->v_uEDateTime?>
                </div>
            <?php
        }
        elseif(empty($batterydata))
        {
            ?>
                <div class="alert alert-danger" role="alert">
                        BATTERY NOT AVAILABLE <?php echo $row->v_bEDateTime?>
                </div>
            <?php
        }
        elseif(empty($driverdata))
        {
            ?>
                <div class="alert alert-danger" role="alert">
                        DRIVER NOT AVAILABLE <?php echo $row->v_dEDateTime?>
                </div>
            <?php
        }
        elseif($unitdata & $batterydata & $driverdata)
        {
            ?>  




                        <div class="alert alert-success" role="alert">
                            <?php echo $row->p_branch?>
                        </div>
                        <div class="row">    
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                <label for="RDriverName">Driver's Name</label>
                                <input type="text" name="RDriverName" id="RDriverName" class="form-control input-sm"  placeholder="Driver's Name" value="<?php echo $row->p_ldriver.','.$row->p_fdriver.' '.$row->p_mdriver ?>" readonly >
                                </div>
                            </div>      
                        </div>  

                        <div class="row">    
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <div class="form-group">
                                <label for="RUnitCode">Unit Code</label>
                                <input type="text" name="RUnitCode" id="RUnitCode" class="form-control input-sm"  placeholder="Unit Code" value="<?php echo $row->p_unitid ?>" readonly >
                                </div>
                            </div>  
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <div class="form-group">
                                <label for="RBatteryCode">Battery Code</label>
                                <input type="text" name="RBatteryCode" id="RBatteryCode" class="form-control input-sm"  placeholder="Battery Code"  value="<?php echo $row->p_batteryid ?>" readonly >
                                </div>
                            </div>      
                        </div>  

                        <div class="row">    
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                <label for="RSwapType">Swap Type</label>
                                <input type="text" name="RSwapType" id="RSwapType" class="form-control input-sm"  placeholder="Unit Code" value="<?php echo $row->p_swaptype ?>" readonly >
                                </div>
                            </div>  
                
                        </div> 


                        <div class="row">    
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                <label for="RAttendant">Attendant</label>
                                <input type="text" name="RAttendant" id="RAttendant" class="form-control input-sm"  placeholder="Attendant" value="<?php echo $row->p_luser.','.$row->p_fuser.' '.$row->p_muser ?>" readonly >
                                </div>
                            </div>  
                        </div> 
                        <div class="row">    
                        <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <div id="RReferencecode"></div>
                                </div>
                            </div>  
                    
                        </div> 
                

                        <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                <button type="button" class="btn btn-primary form-control" data-dismiss="modal" onclick="newrecord()">New Scan</button>
                
                            
                            
                                </div>
                            </div>  










            <?php
        }
        ?>
           
          
            
<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("RReferencecode"), {
	text: "<?php echo $row->v_referencecode ; ?>",
	width: 128,
	height: 128,
	colorDark : "#009608",
	colorLight : "#ffffff",
	correctLevel : QRCode.CorrectLevel.H
});
</script>

        <?php
    }
}
?>


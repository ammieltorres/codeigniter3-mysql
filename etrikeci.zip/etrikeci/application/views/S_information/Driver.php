
<?php
    if($DriverIDres)
    {
        foreach($DriverIDres as $row)
        {
            // echo $row['LName'];
            // echo $row['FName'];
            // echo $row['MName'];
            ?>
                <div class="row">      
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                        <label for="p_driverid">Driver's ID</label>
                        <input type="text" name="p_driverid" id="p_driverid" class="form-control input-sm"  placeholder="Driver's ID" value="<?php echo $row['ID'] ?>" readonly >
                        </div>
                    </div>                                     
                    <div class="col-xs-4 col-sm-4 col-md-4">
                        <div class="form-group">
                        <label for="p_ldriver">Driver's Last Name</label>
                        <input type="text" name="p_ldriver" id="p_ldriver" class="form-control input-sm"  placeholder="Driver's Last Name" value="<?php echo $row['LName'] ?>" readonly >
                        </div>
                    </div>         
                    <div class="col-xs-4 col-sm-4 col-md-4">
                        <div class="form-group">
                        <label for="p_fdriver">Driver's First Name</label>
                        <input type="text" name="p_fdriver" id="p_fdriver" class="form-control input-sm"  placeholder="Driver's First Name" value="<?php echo $row['FName'] ?>" readonly >
                        </div>
                    </div>          
                    <div class="col-xs-4 col-sm-4 col-md-4">
                        <div class="form-group">
                        <label for="p_mdriver">Driver's Middle Name</label>
                        <input type="text" name="p_mdriver" id="p_mdriver" class="form-control input-sm"  placeholder="Driver's Middle Name" value="<?php echo $row['MName'] ?>" readonly >
                        </div>
                    </div>                
                </div>   


            <?php
        }
    }
?>
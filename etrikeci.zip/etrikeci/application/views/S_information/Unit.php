<?php
if($UnitIDres)
{
    foreach($UnitIDres as $row)
    {
        ?>
           <div class="row">  
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <label for="p_unitid">Unit Code</label>
                    <input type="text" name="p_unitid" id="p_unitid" class="form-control input-sm"  placeholder="Unit ID" value="<?php echo $row['ID'] ?>" readonly >
                    </div>
                </div>    
            </div>    
        <?php
    }
}
?>
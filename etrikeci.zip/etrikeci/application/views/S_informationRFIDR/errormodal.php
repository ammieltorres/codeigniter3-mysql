
<!-- Modal -->
<div class="modal fade " id="errormodal" tabindex="-1" role="dialog" aria-labelledby="EMODAL" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title alert alert-danger w-100" id="EMODAL">ERROR</h5>
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> -->
      </div>
      <div class="modal-body">
        <div class="alert alert-info"> 
        <?php if($Swapstatus === 'SWAP IN')
        {
            ?>
            <h3><b>THE METHOD IS SWAP IN</b></h3>
            <br>
            NOTE: <br> Must be Swap Out <br> Must be Repair Out / Empty <br>  Must be Charge Out / Empty <br >
            <?php
        }
        else
        {
            ?>
            <h3><b>THE METHOD IS SWAP OUT</b></h3>
            NOTE: <br> Must be Swap Out <br> Must be Repair Out / Empty<br>  Must be Charge Out / Empty <br>
            <?php
        } ?>        
    
    </div>

   
      <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="battery-status-group">
                        <label class="block text-sm text-gray-600 mb-1"><?php echo $label ?> <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $ID; ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
                    <div class="field-group" id="driver-name-group">
                        <label class="block text-sm text-gray-600 mb-1">Category <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $CategoryName; ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg text-green-600">
                    </div>
             
                <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="driver-name-group">
                        <label class="block text-sm text-gray-600 mb-1">SWAP Status <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $EStatus; ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg text-green-600">
                    </div>
                    <div class="field-group" id="driver-name-group">
                        <label class="block text-sm text-gray-600 mb-1">REPAIR Status <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $RStatus; ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg text-green-600">
                    </div>
                    <div class="field-group" id="driver-name-group">
                        <label class="block text-sm text-gray-600 mb-1">CHARGE Status <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $CStatus; ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg text-green-600">
                    </div>
                </div>
            </div>
        
            <button type="button" class="btn w-100 bg-red-500 float-right rounded-full" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script>
$(document).ready(function() {
    // Click the button to open the modal
    $('#errormodal').modal('toggle');
});
</script>
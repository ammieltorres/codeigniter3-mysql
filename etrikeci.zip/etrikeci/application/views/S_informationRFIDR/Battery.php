<?php
if($BatteryIDres)
{
    foreach($BatteryIDres as $row)
    {
        
         $newswapstatusB = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusB == "IN")
            {
                $newswapstatusdataB = 'OUT';
            }
            else
            {
                $newswapstatusdataB = 'IN';
            }
        ?>
            
            





        
    <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="battery-status-group">
                        <label class="block text-sm text-gray-600 mb-1">Battery Code <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $row['ID'] ?>" id ="p_batteryid" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
        

             
                    </div>
            </div>

        <?php
    }
}
else
{
    echo 'empty';
}
?>

<br>
<?php
if($chargerIDres)
{
    foreach($chargerIDres as $row)
    {
        
         $newswapstatusC = explode(" ",$row['CStatus'])[1];  
            if($newswapstatusC == "IN")
            {
                $newswapstatusdataC = 'OUT';
            }
            else
            {
                $newswapstatusdataC = 'IN';
            }
        ?>
     <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="battery-status-group">
                        <label class="block text-sm text-gray-600 mb-1">Charger Code <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="<?php echo $row['ID'] ?>" id ="p_chargerid" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
        

             
                    </div>
            </div>

        <?php
    }
}
else
{
    echo 'empty';
}
?>


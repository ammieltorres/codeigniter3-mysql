<hr>

<?php
if($UnitIDres)
{
    foreach($UnitIDres as $row)
    {
         $newswapstatusU = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusU == "IN")
            {
                $newswapstatusdataU = 'OUT';
            }
            else
            {
                $newswapstatusdataU = 'IN';
            }
         
        ?>
        
            
        <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="battery-status-group">
                        <label class="block text-sm text-gray-600 mb-1">Unit Code <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" id="p_unitid" name="p_unitid" value="<?php echo $row['ID'] ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
        
                    </div>
            </div>




        <?php
    }
}
?>

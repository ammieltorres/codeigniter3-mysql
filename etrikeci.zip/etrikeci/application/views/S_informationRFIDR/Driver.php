
<?php
    if($DriverIDres)
    {
        foreach($DriverIDres as $row)
        {
            
            $newswapstatusD = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusD == "IN")
            {
                $newswapstatusdataD = 'OUT';
            }
            else
            {
                $newswapstatusdataD= 'IN';
            }
            ?>



    <div class="grid grid-cols-1 gap-4" id="form-fields">
                    <div class="field-group" id="battery-status-group">
                        <label class="block text-sm text-gray-600 mb-1">Driver Code <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" value="AGUILA,RYAN" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
        
                    <div class="field-group" id="form-group">
                        <label class="block text-sm text-gray-600 mb-1">Last Name <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" name="p_ldriver" id="p_ldriver" value="<?php echo $row['LName'] ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
                    <div class="field-group" id="form-group">
                        <label class="block text-sm text-gray-600 mb-1">First Name <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" name="p_fdriver" id="p_fdriver" value="<?php echo $row['FName'] ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
                    <div class="field-group" id="form-group">
                        <label class="block text-sm text-gray-600 mb-1">Middle Name <span class="float-right text-gray-400 cursor-pointer close-btn">×</span></label>
                        <input type="text" name="p_mdriver" id="p_mdriver" value="<?php echo $row['MName'] ?>" readonly class="w-full p-2 border border-gray-300 rounded text-lg font-semibold">
                    </div>
             
                    </div>
            </div>



   


            <?php
        }
    }
?>







<style>

 i
 {
     /*font-size:40px;*/
     color:green;
 }


</style>


<script>function display_ct7() {
var x = new Date()
var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';
hours = x.getHours( ) % 12;
hours = hours ? hours : 12;
hours=hours.toString().length==1? 0+hours.toString() : hours;

var minutes=x.getMinutes().toString()
minutes=minutes.length==1 ? 0+minutes : minutes;

var seconds=x.getSeconds().toString()
seconds=seconds.length==1 ? 0+seconds : seconds;

var month=(x.getMonth() +1).toString();
month=month.length==1 ? 0+month : month;

var dt=x.getDate().toString();
dt=dt.length==1 ? 0+dt : dt;

var x1=month + "/" + dt + "/" + x.getFullYear(); 
x1 = x1 + " - " +  hours + ":" +  minutes + ":" +  seconds + " " + ampm;
document.getElementById('ct7').innerHTML = x1;
display_c7();
 }
 function display_c7(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct7()',refresh)
}
display_c7()
</script>

</head>

<body onload=display_ct7();>

<div class="">
    <div class="row">
        <div class="col-lg-4">
            <img style="width:300px;" src="<?php echo base_url('img/logonew.png') ?>">
        </div>
        <div class="col-lg-8">
            <h1 style="font-size:70px;"><span id='ct7' ></span></h1>
        </div>
    </div>

<hr>

	<div class="row">

<!-- --------------------- -->


    <div class="col-sm-12">
    	<div class="row">
 
    		
    		<div class="col-lg-6">
    		    <div class="alert alert-warning text-center" role="alert" style=" text-transform: uppercase;">
                    battery in use
                </div>
    			<div id="Batinuse"></div>
    		</div>
    		<div class="col-lg-6">
    		      <div class="alert alert-primary text-center" role="alert" style=" text-transform: uppercase;">
                    battery Available
                </div>
    			<div id="BatAvailable"></div>
    		</div>
    	</div>
    	<hr>
    	<div class="row">
    		<div class="col-lg-6">
    		      <div class="alert alert-danger text-center" role="alert" style=" text-transform: uppercase;">
                    battery to charge
                </div>
    			<div id="Battocharge"></div>
    		</div>
    		<div class="col-lg-6">
    		      <div class="alert alert-success text-center" role="alert" style=" text-transform: uppercase;">
                    battery charging
                </div>
    			<div id="Batcharging"></div>
    		</div>
    	</div>
    	</div>
    <div>





</div>
  </div>


<script>
 
$(document).ready(function() {
nextpages();

});



function nextpages()
{
    
        var numberpagesBattocharge = <?php echo $numberpagesBattocharge ?>;
        var numberpagesBattochargeV = <?php echo $numberpagesBattocharge ?>;
        
        var numberpagesBatcharging = <?php echo $numberpagesBatcharging ?>;
        var numberpagesBatchargingV = <?php echo $numberpagesBatcharging ?>;
        
        var numberpagesBatAvailable = <?php echo $numberpagesBatAvailable ?>;
        var numberpagesBatAvailableV = <?php echo $numberpagesBatAvailable ?>;
               
        var numberpagesBatinuse = <?php echo $numberpagesBatinuse ?>;
        var numberpagesBatinuseV = <?php echo $numberpagesBatinuse ?>;
        
        
        

        
        
        console.log(numberpagesBatinuse);
        setTimeout(excuteMethod, 15000);

        
        
        function excuteMethod() 
        {
            console.log(numberpagesBatinuse + ' call');
     	    
            
            
            numberpagesBattocharge--;
            numberpagesBatcharging--;
            numberpagesBatAvailable--;
            numberpagesBatinuse--;
            

            
                setTimeout(excuteMethod, 15000);
                // sitereport();
                
                
                // ==========================================================
                if (numberpagesBattocharge  >= 0) setTimeout(nextBattocharge(), 3000);
                if (numberpagesBatcharging  >= 0) setTimeout(nextBatcharging(), 3000);
                if (numberpagesBatAvailable  >= 0) setTimeout(nextBatAvailable(), 3000);
                if (numberpagesBatinuse  >= 0) setTimeout(nextBatinuse(), 3000);
                
                

                // ==========================================================
                if (numberpagesBattocharge  <= 0) setTimeout(Battocharge(page_url = false), 5000);
                if (numberpagesBatcharging  <= 0) setTimeout(Batcharging(page_url = false), 5000);
                if (numberpagesBatAvailable  <= 0) setTimeout(BatAvailable(page_url = false), 5000);
                if (numberpagesBatinuse  <= 0) setTimeout(Batinuse(page_url = false), 5000);
               

                // ==========================================================
                if (numberpagesBattocharge <= 0) { numberpagesBattocharge = numberpagesBattochargeV;  }
                if (numberpagesBatcharging <= 0) { numberpagesBatcharging = numberpagesBatchargingV;  }
                if (numberpagesBatAvailable <= 0) { numberpagesBatAvailable = numberpagesBatAvailableV;  }
                if (numberpagesBatinuse <= 0) { numberpagesBatinuse = numberpagesBatinuseV;  }

               
            }
            
            
            function nextBattocharge()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="Battocharge"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextBatcharging()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="Batcharging"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextBatAvailable()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="Battocharge"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextBatinuse()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="Batinuse"] a[rel="next"]')).forEach(button=>button.click());
            }
            
            

            

		};
		



// ======================== Battocharge ====================================
	/*--first time load--*/
		Battocharge(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.Battocharge li a", function(event) {
			var page_url = $(this).attr('href');
			Battocharge(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function Battocharge(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Dashboard/Battocharge/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#Battocharge").html(response);

					
				}
			});

		}
		
		
// ========================= Batcharging ===================================
	/*--first time load--*/
		Batcharging(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.Batcharging li a", function(event) {
			var page_url = $(this).attr('href');
			Batcharging(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function Batcharging(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Dashboard/Batcharging/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#Batcharging").html(response);

					
				}
			});

		}
		
		
	// ========================= BatAvailable ===================================
	/*--first time load--*/
		BatAvailable(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.BatAvailable li a", function(event) {
			var page_url = $(this).attr('href');
			Batcharging(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function BatAvailable(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Dashboard/BatAvailable/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#BatAvailable").html(response);

					
				}
			});

		}	
	// ======================== Batinuse ====================================
	/*--first time load--*/
		Batinuse(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.Batinuse li a", function(event) {
			var page_url = $(this).attr('href');
			Batinuse(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function Batinuse(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Dashboard/Batinuse/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#Batinuse").html(response);

					
				}
			});

		}
		
		
		
</script>









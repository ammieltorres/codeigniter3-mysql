
<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>   
                <th>GS_Battery_ID</th>
                <th>GS_Battery_Status</th>
                <th>GS_Battery_Driver_Charger</th>
                <th>GS_Name_Battery</th>
                <th>GS_CB_Name</th>
                <th>GS_TimeStamp</th>
                <th>GS_Duration</th>
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($Battery))
                {
                
                ?>

                    <?php foreach ($Battery as $row) 
                    {
                      ?>
                        <tr>
                            <td><?php echo $row->GS_BatteryID ?></td>
                            <td><?php echo $row->GS_Status ?></td>
                            <td><?php echo $row->GS_Battery_Driver_Charger ?></td>
         
                            <td><?php echo $row->GS_Name_Battery ?></td>
                            <td><?php echo $row->GS_CB_Name ?></td>
                            <td><?php echo $row->GS_TimeStamp ?></td>
                            <td><?php echo $row->GS_Duration ?></td>
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging" hidden>
    <ul class="pagination Batinuse">
    <li class="page-item "><?php echo $pagelinks ?></li>
	</ul>
</div>













<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>
    <th>Action</th>
                <th>ID</th>

                <th>Category</th>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>

           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($SwappingReports))
                {
                
                ?>

                    <?php foreach ($SwappingReports as $row) 
                    {
                      ?>
                        <tr>
                        <td><button href="#qrmodal" class="btn btn-primary" id="printQR"data-toggle="modal" data-target="#qrmodal"  value="<?php echo $row->ID?>">Print</button></td>
                            <td><?php echo $row->ID ?></td>
                            <td><?php echo $row->Category ?></td>
                            <td><?php echo $row->LName ?></td>
                            <td><?php echo $row->FName ?></td>
                            <td><?php echo $row->MName ?></td>
                            
           
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>










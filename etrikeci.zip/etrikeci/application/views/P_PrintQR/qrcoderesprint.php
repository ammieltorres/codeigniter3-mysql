

<link rel="stylesheet" href="<?php echo base_url('css/qrpintsize.css') ?>">



<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript"></script>
<div id="section-to-print">
<div id="qrres" style="margin-top:20px; margin-left:20px;"></div>
<center>
<?php echo $eqID ?>

</center>
</div>

<script>
var eqID = '<?php echo $eqID ?>';
  var qrcode = new QRCode(document.getElementById("qrres"), {
	text: eqID,
	width: 128,
	height: 128,
	colorDark : "#009608",
	colorLight : "#ffffff",
	correctLevel : QRCode.CorrectLevel.H
});


</script>




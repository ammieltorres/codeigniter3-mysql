


<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <th>Branch</th>

                <th>Attendant</th>
                <th>Driver</th>

                <th>Unit</th>
                <th>Type</th>
                <th>DateTime</th>
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($SwappingReports))
                {
                
                ?>

                    <?php foreach ($SwappingReports as $row) 
                    {
                      ?>
                        <tr>

                            <td><?php echo $row->Branch ?></td>
                            <td><?php echo $row->LUser.','.$row->FUser.' '.$row->MUser ?></td>
                            <td><?php echo $row->LDriver.','. $row->FDriver.' '.$row->MDriver ?></td>
                            <td><?php echo $row->UnitID ?></td>
                            <td><?php echo $row->SwapType ?></td>
                            <td><?php echo $row->DateTime ?></td>
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>







<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript"></script>
<div id="section-to-print">

<div class="row">

	<?php 
if($eqp)
{
	foreach($eqp as $row)
	{
		?> 	
				<div class="col-lg-3">
					<img style="margin:auto;" id="qr" name="qr" src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl=<?php echo $row['ID'];?>">
					<h6 for="qr" class="text-center"><?php echo $row['ID']; ?></h6>
				</div>
		<?php
	}
}

?>


	</div>








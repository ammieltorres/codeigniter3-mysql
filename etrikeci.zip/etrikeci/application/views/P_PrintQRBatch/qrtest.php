

<!-- <link rel="stylesheet" href="<?php echo base_url('css/qrpintsizebatch.css') ?>"> -->
<style>
	.label
	{
		margin-left:-115px;
	}
    .img
    {
          margin-top:;
    }
   .h6
    {
        margin-top:41px;
    }
    
    .row
    {
          display: grid;
  grid-template-columns: auto auto auto auto;
  grid-gap: 10px;

  padding: 10px;
    }
    .QR
    {
        margin-top:auto;
    }
    @page  
{ 
    size: auto;   /* auto is the initial value */ 

    /* this affects the margin in the printer settings */ 
    margin: 5mm 10mm 10mm 10mm;  
} 
body  
{ 
    /* this affects the margin on the content before sending to printer */ 
    margin: 0px;  
} 
</style>


<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript"></script>

<bod>
<div id="section-to-print">

<div class="row">
	<?php 
if($eqp)
{
    $i = 0;
	foreach($eqp as $row)
	{
        
        $dataid =  $row['ID'];
		?> 
         
                   <center>
                    <div class="QR">
                        <div style="" class="col-lg-3 "  id="qrres-<?php echo $i ?>"><br></b><h6 style="float:bottom;" for="qr" class=""></div>
                        
                         <div style="margin-top:5px;"> <?php echo  $row['ID']; ?> </div>
                          <?php echo $row['LName'].','.$row['FName']; ?>
                         
                   	</div>
			 </center>
	<script>
		var qrcode = new QRCode(document.getElementById("qrres-<?php echo $i ?>"), {
			text: "<?php echo $row['ID']; ?>",
			width: 158,
			height: 158,
			colorDark : "#000000",
			colorLight : "#ffffff",
			correctLevel : QRCode.CorrectLevel.H,
		});
	</script>

<?php
    $i++;
	}
}
?>
</div>


</body>



<?php 
    function phpReadFile($filename)
    {
        $myfile = fopen($filename,"r") or die("unable to open file");
        $filecontent = fread($myfile, filesize($filename));
        fclose($myfile);
        return $filecontent;
    }
//-----------------------------------------------------------------------



$files = directory_map('./weathercondition');  
foreach ($files as $file) 
{
    if (pathinfo($file, PATHINFO_EXTENSION) === 'txt')
    {
        //echo $file;
        $files1[] = $file;
    }
}

$latestfile = end($files1);
// echo $latestfile;
/*list all .txt file*/


    $data =  phpReadFile('weathercondition/'.''.$latestfile);
    $explode = (explode("...",$data));
    $dataend = end($explode);

    if($dataend > 9)
    {
        $dataendexplode = (explode(",",$dataend));
    }
    else
    {
        $data2l = prev($explode);
        $dataendexplode = (explode(",",$data2l));
    }
//====================================================================================

 





 ?>
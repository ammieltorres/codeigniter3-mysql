<!DOCTYPE html>
<html > 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GERWEISS</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('img/logo.png')?>">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css'); ?>" >
    <link rel="stylesheet"  href="<?php echo base_url('css/jquery.mCustomScrollbar.min.css'); ?>" >
    <link rel="stylesheet"  href="<?php echo base_url('css/bootstrap.css'); ?>" >
    <script src="<?php echo base_url('js/jquery.min.js'); ?>" ></script>
    <script rel="stylesheet" href="<?php echo base_url('js/bootstrap.js'); ?>" ></script>
    <script rel="stylesheet" href="<?php echo base_url('js/charts.js'); ?>" ></script>
    <!-- <script src="<?php echo base_url("js/cdn.tailwind.js"); ?>"></script> -->
    <link rel="stylesheet"  href="<?php echo base_url('css/tailwintstlye.css'); ?>" >
    
</head>


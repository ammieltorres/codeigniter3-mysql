











</div>
</div>



<script  src="<?php echo base_url('js/bootstrap.min.js'); ?>"></script>
<!-- <script>
    $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
        });
    });
</script> -->


<link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>




<script>
  document.addEventListener('DOMContentLoaded', (event) => {
    const dropdownToggles = document.querySelectorAll('[data-collapse-toggle]');
    
    dropdownToggles.forEach(toggle => {
      toggle.addEventListener('click', () => {
        const targetId = toggle.getAttribute('data-collapse-toggle');
        const target = document.getElementById(targetId);
        
        if (target.classList.contains('hidden')) {
          target.classList.remove('hidden');
          setTimeout(() => target.classList.add('show'), 10);
        } else {
          target.classList.remove('show');
          setTimeout(() => target.classList.add('hidden'), 300);
        }
      });
    });
  });
</script>


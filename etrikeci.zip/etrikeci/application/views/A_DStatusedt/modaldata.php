<?php

$data = trim($this->input->post('getrec'));

// print_r (explode("|",$data)[0]);
// print_r (explode("|",$data)[1]);
// print_r (explode("|",$data)[2]);
// print_r (explode("|",$data)[3]);
// print_r (explode("|",$data)[4]);


?>
<h6>CURRENT DATA</h6>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">
    
                        <div class="row">
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                    <label for="Branch">ID</label>
                                    <input type="text" class="form-control" name="currentdata" id="currentdata" value ="<?php print_r (explode("|",$data)[0]); ?>" onkeypress="return false;" readonly/>
                            </div>
                        
                
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                    <label for="Branch">Category</label>
                                    <input type="text" class="form-control" name="currentdata" id="currentdata" value ="<?php print_r (explode("|",$data)[1]); ?>" onkeypress="return false;" readonly/>
                            </div>
              
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label for="Branch">Swap Status</label>
                                    <input type="text" class="form-control" name="currentdata" id="currentdata" value ="<?php print_r (explode("|",$data)[2]); ?>" onkeypress="return false;" readonly/>
                            </div>
              
           
          
                        </div>
                    </div>
                </div>
            </div>
</div>

<hr>
<h5>EDIT VALUE</h5>
<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">
    
                        <div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">ID</label>
						        <input type="text" class="form-control" name="p_id" id="p_id" value ="<?php print_r (explode("|",$data)[0]); ?>" onkeypress="return false;" required/>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Category</label>
						        <input type="text" class="form-control" name="p_category" id="p_category" value ="<?php print_r (explode("|",$data)[1]); ?>"  onkeypress="return false;"  required/>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Status</label>
                                    <select  type="text" name="p_status" id="p_status" class="form-control input-sm" value="" required>                                       
                                        <option value="SWAP">SWAP</option>
                                    </select>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Value</label>
                                <select  type="text" name="p_value" id="p_value" class="form-control input-sm" value="" required>   
                                        <option value="SWAP">IN / OUT</option>                                          
                                        <option value="IN">IN</option>
                                        <option value="OUT">OUT</option>      
                                    </select>
                            </div>
                            <!-- <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">ID</label>
						        <input type="text" class="form-control" name="Branch" id="Branch" placeholder="Branch" />
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
</div>
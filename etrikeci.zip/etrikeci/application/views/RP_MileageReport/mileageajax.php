


<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <th>ID</th>
                <th>Category</th>
                <th>currentMileage</th>

           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($MileageReports))
                {
                
                ?>

                    <?php foreach ($MileageReports as $row) 
                    {
                      ?>
                        <tr>

                            <td><?php echo $row->ID ?></td>
                            <td><?php echo $row->Category ?></td>

                            <td><?php echo $row->currentmileage ?></td>
                           
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>



<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>   
                <th>IMEI</th>
                <th>StartTime</th>
                <th>EndTime</th>
                <th>AvgSpeed</th>
                <th>Distance (m)</th>
                <th>Distance (Km)</th>
                 <th>BatteryCode</th>
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($DeviceList))
                {
                
                ?>

                    <?php foreach ($DeviceList as $row) 
                    {
                      ?>
                        <tr>
                            <td><?php echo $row->IMEI ?></td>
                            <td><?php echo $row->StartTime ?></td>
                            <td><?php echo $row->EndTime ?></td>
                            <td><?php echo $row->AvgSpeed ?></td>
                            <td><?php echo $row->Distance ?></td>
                              <td><?php echo $row->Distance / 1000 ?></td>
                                 <td><?php echo $row->BatteryCode ?></td>
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


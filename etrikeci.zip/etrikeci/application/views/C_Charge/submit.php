<!-- <div class="row">                                        
    <div class="col-xs-12 col-sm-12 col-md-12">       
        <button  class="btn btn-success form-control" type="submit"  id ="subrec"name="submit">Submit</button>
    </div>
</div> -->



<div class="row">                                        
    <div class="col-xs-5 col-sm-5 col-md-5">       
        <button  class="btn btn-success form-control "  onclick="chargesub(event)" type="submit" value="CHARGE IN"  id ="subrec" name="submit">CHARGE IN</button>
      
    </div>
    <div class="col-xs-2 col-sm-2 col-md-2">       
      
      
    </div><br>
    <div class="col-xs-5 col-sm-5 col-md-5">              
      
    <button  class="btn btn-danger form-control"  onclick="chargesub(event)" type="submit" value="CHARGE OUT" id ="subrec "name="submit">CHARGE OUT</button>
    </div>
</div>

<div class="modal fade" id="Result" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Result</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ResData"></div>
      </div>
 
    </div>
  </div>
</div>


<script>
   function chargesub(event) {

  $('#submitrecord').unbind("submit");
    $("#submitrecord").submit(function(e) 
    {
          e.preventDefault();
            $('#subrec').attr('disabled','disabled');
            
            var p_chargetype        = (event.target.value);;
            var p_batteryid         = $("#p_batteryid").val();
            var p_chargerid         = $("#p_chargerid").val();
           
	        
            $.ajax({
				method: "POST",
				url: "<?php echo site_url('Charging/ChargingRecord/') ?>",
				data:  "p_chargetype=" + p_chargetype + "&p_batteryid=" + p_batteryid + 
                "&p_chargerid=" + p_chargerid,		
				
				success: function(response) {
				console.log(response);

                $('#Result').modal('toggle');
                $("#ResData").html(response);
                $("#p_chargetype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                // document.getElementById('p_swaptype').options[1].selected = 'selected';
                $('#Result').modal('toggle')
                // $('#Result').modal('toggle')
				}
			});
        
		});
  }
</script>


<script>
  $('#submitrecord').unbind("submit");
    $("#submitrecord").submit(function(e) 
    {
          e.preventDefault();
            $('#subrec').attr('disabled','disabled');
            

            var p_chargetype        = $("#p_chargetype").val();
            var p_batteryid         = $("#p_batteryid").val();
            var p_chargerid         = $("#p_chargerid").val();
    
           
			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Charging/ChargingRecord/') ?>",
				data:  "p_chargetype=" + p_chargetype + "&p_batteryid=" + p_batteryid + 
                "&p_chargerid=" + p_chargerid,		
				
				success: function(response) {
				console.log(response);

                $('#Result').modal('toggle');
                $("#ResData").html(response);
                $("#p_chargetype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                // document.getElementById('p_swaptype').options[1].selected = 'selected';
                $('#Result').modal('toggle')
                // $('#Result').modal('toggle')
				}
			});
        
		});
</script>

<script>
    $(document).ready(function(){
      video.srcObject.getTracks().forEach(track => {
          track.stop();
        });
        qrResult.hidden = false;
        canvasElement.hidden = true;
        btnScanQR.hidden = false;
    });
</script>           

<script>
    function openqrscan()
    {
        navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      btnScanQR.hidden = false;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
    }
</script>


<script>
       function newrecord()
    {

   
        $.ajax({
				method: "POST",
				url: "<?php echo site_url('Charging/removesession/') ?>",
        success: function(response) {
          location.reload()
        }
        });
        
    
        document.getElementById('p_swaptype').options[0].selected = 'selected';
    }
</script>
<?php
if($result)
{
    foreach($result as $row)
    {
        ?>
    


            <?php 
            // echo $row->p_chargetype;
            $VCBattery =  $row->v_vcbattery;
            $VRBattery = $row->v_vrbattery;
            $VSBattery = $row->v_vsbattery;

       
            $v_vrcharger = $row->v_vrcharger;
            $v_vccharger = $row->v_vccharger;


            if(empty($v_vrcharger))
            {
                ?>
                    <div class="alert alert-danger" role="alert">
                        ERROR: CHARGER IS IN REPAIR IN STATE <?php echo $row->v_vrchargerdatetimestamp?> (Repair)
                    </div>
                <?php
            }
            if(empty($v_vccharger))
            {
                ?>
                    <div class="alert alert-danger" role="alert">
                    ERROR: CHARGER IS IN CHARGE IN STATE <?php echo $row->v_vcchargerdatetimestamp?> (Charge)
                    </div>
                <?php
            }
            if(empty($VCBattery))
            {
                ?>
                    <div class="alert alert-danger" role="alert">
                        ERROR: BATTERY IS IN CHARGE IN <?php echo $row->v_vcbatterydatetimestamp?> (Charge)
                    </div>
                <?php
            }
            if(empty($VRBattery))
            {
                ?>
                <div class="alert alert-danger" role="alert">
                        ERROR: BATTERY IS IN REPAIR IN <?php echo $row->v_vrbatterydatetimestamp?> (Repair)
                </div>
            <?php
            }
            if(empty($VSBattery))
            {
                ?>
                <div class="alert alert-danger" role="alert">
                        ERROR: BATTERY IS IN SWAP OUT <?php echo $row->v_vsbatterydatetimestamp?> (Swap)
                </div>
            <?php
            }
            if($VCBattery & $VRBattery & $VSBattery & $v_vrcharger & $v_vccharger)
            {
                ?> 
                
                        <div class="alert alert-success" role="alert">
                <?php echo $row->p_branch?>
          
                 </div>
                            <div class="row">    
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <label for="RChargeType">Charge Type</label>
                    <input type="text" name="RChargeType" id="RChargeType" class="form-control input-sm"  placeholder="Unit Code" value="<?php echo $row->p_chargetype ?>" readonly >
                    </div>
                </div>  
       
            </div> 
            <div class="row">    
      
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                    <label for="RBatteryCode">Battery Code</label>
                    <input type="text" name="RBatteryCode" id="RBatteryCode" class="form-control input-sm"  placeholder="Battery Code"  value="<?php echo $row->p_batteryid ?>" readonly >
                    </div>
                </div>    
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <div class="form-group">
                    <label for="RChargerCode">Charger Code</label>
                    <input type="text" name="RChargerCode" id="RChargerCode" class="form-control input-sm"  placeholder="Unit Code" value="<?php echo $row->p_chargerid ?>" readonly >
                    </div>
                </div>    
            </div>  

        


            <div class="row">    
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <label for="RAttendant">Attendant</label>
                    <input type="text" name="RAttendant" id="RAttendant" class="form-control input-sm"  placeholder="Attendant" value="<?php echo $row->p_luser.','.$row->p_fuser.' '.$row->p_muser ?>" readonly >
                    </div>
                </div>  
            </div> 
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <div id="RReferencecode"></div>
                    </div>
                </div>  
           
            </div> 
       
                <?php
            }
                ?>  
            
         


            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
              
                         <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="newrecord()">Scan New</button>
                     
                   
                 
                    </div>
                </div>  
          
            
<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("RReferencecode"), {
	text: "<?php echo $row->v_referencecode ; ?>",
	width: 128,
	height: 128,
	colorDark : "#009608",
	colorLight : "#ffffff",
	correctLevel : QRCode.CorrectLevel.H
});
</script>

        <?php
    }
}
?>


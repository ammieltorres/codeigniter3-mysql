<?php
if($C_batteryIDres)
{
    foreach($C_batteryIDres as $row)
    {
        ?>
            <div class="row">    
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <label for="p_batteryid">Battery Code</label>
                    <input style="background-color:#e9ecef;" type="text" name="p_batteryid" id="p_batteryid" class="form-control input-sm"  placeholder="Please scan battery qr" onkeypress="return false;" value="<?php echo $row['ID'] ?>" required >
                    </div>
                </div>      
            </div>  
        <?php
    }
}
else
{
    echo 'empty';
}
?>



<?php 


$rec = explode("|", $data);



?>

<div class="row container-fluid">

<form Method="post" id="updateequipment">
<div class="form-group">
        <div class="row">
        <div class="col-md-4">
                <label for="ID_edt">Category Code</label>
                <input type="text" name="p_CategoryCode_edt" id="p_CategoryCode_edt"  value="<?php echo $rec[1]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="ID_edt">Category</label>
                <input type="text" name="p_Category_edt" id="p_Category_edt" value="<?php echo $rec[2]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="ID_edt">ID</label>
                <input type="text" name="p_ID_edt" id="p_ID_edt" value="<?php echo $rec[0]; ?>" class="form-control" readonly>
            </div>
        </div>
        <div class="row" <?php if($rec[1] != '0001') {?> hidden <?php } ?>>
            <div class="col-md-4">
                <label for="p_LName_edt">Last Name</label>
                <input type="text" name="p_LName_edt" id="p_LName_edt" value="<?php echo $rec[3]; ?>" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_FName_edt">First Name</label>
                <input type="text" name="p_FName_edt" id="p_FName_edt" value="<?php echo $rec[4]; ?>" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_MName_edt">Middle Name</label>
                <input type="text" name="p_MName_edt" id="p_MName_edt" value="<?php echo $rec[5]; ?>" class="form-control">
            </div>
        </div>
        <div class="row" >
            <div class="col-md-4">
                <label for="p_EStatus_edt">p_EStatus</label>
                <input type="text" name="p_EStatus_edt" id="p_EStatus_edt" value="<?php echo $rec[6]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="p_EDateTime_edt">p_EDateTime</label>
                <input type="text" name="p_EDateTime_edt" id="p_EDateTime_edt" value="<?php echo $rec[7]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="p_CStatus_edt">p_CStatus</label>
                <input type="text" name="p_CStatus_edt" id="p_CStatus_edt" value="<?php echo $rec[8]; ?>" class="form-control" readonly>
            </div>
        </div>

        <div class="row" >
            <div class="col-md-4">
                <label for="p_CDateTime_edt">p_CDateTime</label>
                <input type="text" name="p_CDateTime_edt" id="p_CDateTime_edt" value="<?php echo $rec[9]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="p_RStatus_edt">p_RStatus</label>
                <input type="text" name="p_RStatus_edt" id="p_RStatus_edt" value="<?php echo $rec[10]; ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="p_RDateTime_edt">p_RDateTime</label>
                <input type="text" name="p_RDateTime_edt" id="p_RDateTime_edt" value="<?php echo $rec[11]; ?>" class="form-control" readonly>
            </div>
        </div>
        <div class="row" >
            <div class="col-md-6">
                <label for="p_RFIDCode_edt">p_RFIDCode</label>
                <input type="text" name="p_RFIDCode_edt" id="p_RFIDCode_edt" value="<?php echo $rec[12]; ?>" class="form-control" >
            </div>
            <div class="col-md-6">
                <label for="p_SystemID_edt">p_SystemID</label>
                <input type="text" name="p_SystemID_edt" id="p_SystemID_edt" value="<?php echo $rec[13]; ?>" class="form-control" readonly>
            </div>
        </div>
                <div class="row" >
            <div class="col-md-12">
                <label for="p_LowVoltage">p_LowVoltage</label>
                <input type="text" name="p_LowVoltage" id="p_LowVoltage" value="<?php echo $rec[24]; ?>" class="form-control" readonly>
            </div>

        </div>
    </div>

    <button type="Submit" class="btn btn-primary form-control text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Save</button>
  
    </form>
</div>



<script>
    $('#updateequipment').unbind("submit");
    $("#updateequipment").submit(function(e) 
    {
      e.preventDefault();

      
        var p_ID                     = $("#p_ID_edt").val();
        var p_CategoryCode             = $("#p_CategoryCode_edt").val();
        var p_Category                 = $("#p_Category_edt").val();

        var p_LName                  = $("#p_LName_edt").val();
        var p_FName                  = $("#p_FName_edt").val();
        var p_MName                  = $("#p_MName_edt").val();

        var p_EStatus                = $("#p_EStatus_edt").val();
        var p_EDateTime              = $("#p_EDateTime_edt").val();
        var p_CStatus                = $("#p_CStatus").val();

        var p_CDateTime              = $("#p_CDateTime_edt").val();
        var p_RStatus                = $("#p_RStatus_edt").val();
        var p_RDateTime              = $("#p_RDateTime_edt").val();

        var p_RFIDCode               = $("#p_RFIDCode_edt").val();
        var p_SystemID               = $("#p_SystemID_edt").val();

        var p_UserID               = "<?php echo  $rec[15]; ?>";
        var p_ULName               = "<?php echo  $rec[16]; ?>";
        var p_UFName               = "<?php echo  $rec[17]; ?>";
        var p_UMName               = "<?php echo  $rec[18]; ?>";

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Equipments/updateequipment/') ?>",
				data:   "p_CategoryCode=" + p_CategoryCode +
                        "&p_Category=" + p_Category +
                        "&p_ID=" + p_ID +
                        "&p_LName=" + p_LName +
                        "&p_FName=" + p_FName +
                        "&p_MName=" + p_MName +
                        
                        "&p_EStatus=" + p_EStatus +
                        "&p_EDateTime=" + p_EDateTime +
                        "&p_CStatus=" + p_CStatus +
                        
                        "&p_CDateTime=" + p_CDateTime +
                        "&p_RStatus=" + p_RStatus +
                        "&p_RDateTime=" + p_RDateTime +
                        
                        "&p_RFIDCode=" + p_RFIDCode +
                        "&p_SystemID=" + p_SystemID +
                        
                        "&p_UserID=" + p_UserID +
                        "&p_ULName=" + p_ULName +
                        "&p_UFName=" + p_UFName +
                        "&p_UMName=" + p_UMName,
				
				success: function(response) {
     
					console.log(response);
                    $("#ajaxContentnew").html(response);
                    alert(response);
                                        // $('#ADDUserAccessModal').modal('hide');
                                        // $('#message').modal('toggle');
                                        // $("#messagemodal").html(response);
		
    
				}
			});
            return false;
		});
</script>

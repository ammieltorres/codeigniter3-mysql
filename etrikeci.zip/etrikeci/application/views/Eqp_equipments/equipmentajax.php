


<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <!-- <th>Branch</th> -->
                <th>Action</th>
                <th>Category</th>
                <th>ID</th>
                <th>LName</th>

                <th>FName</th>
                <th>MName</th>
                <th>LowVoltage</th>
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($Equipments))
                {
                
                ?>

                    <?php foreach ($Equipments as $row) 
                    {
                      ?>
                        <tr>
                          <td>
                            <button class="btn btn-primary"  data-toggle="modal" data-target="#editequipmentmodal" id="editequipment" value="<?php echo $row->ID .'|'. $row->CategoryCode .'|'. $row->Category .'|'. $row->LName .'|'. $row->FName .'|'.
                                                                                          $row->MName .'|'. $row->EStatus .'|'. $row->EDateTime .'|'. $row->CStatus .'|'. $row->CDateTime .'|'.
                                                                                          $row->RStatus .'|'. $row->RDateTime .'|'. $row->RFID .'|'. $row->SystemID .'|'. $row->UserID .'|'.
                                                                                          $row->ULName .'|'. $row->UFName .'|'. $row->UMName .'|'. $row->UpdatedByUserID .'|'. $row->UpdatedByULName .'|'.
                                                                                          $row->UpdatedByUFName .'|'. $row->UpdatedByUMName .'|'. $row->deleted .'|'. $row->DateStamp  .'|'. $row->LowVoltage ?>">
                                                                                          
                                                                                          EDIT
                            </button>
                          </td>

                            <td><?php echo $row->Category ?></td>
                            <td><?php echo $row->ID ?></td>
                            <td><?php echo $row->LName ?></td>
                            <td><?php echo $row->FName ?></td>
                            <td><?php echo $row->MName ?></td>
                            <td><?php echo $row->LowVoltage ?></td>
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>



<!-- Modal -->
<div class="modal fade" id="editequipmentmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Equipment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
   
            <div class="modal-body">
                <div class="col-md-12">
                    <div id="ajaxContentedit"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" data-dismiss="modal">Close</button>
           
            </div>
      
    </div>
  </div>
  </div>





<script>

$(document).on('click', "#editequipment", function(event) {
    
        var getrec = $(this).val();

    // alert(getrec);
  
  $.ajax({
    method: "POST",
    url: "<?php echo site_url('Equipments/editequipments/') ?>",
    data:  "getrec=" + getrec,

    success: function(response) {
      console.log(response);
      // alert(response)
      $("#ajaxContentedit").html(response);
      // $('#Driverstatusmodal').modal('toggle');

      
    }
  });

   
});

</script>














<div class="box">
	<div class="row">

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">
            
                        <div class="row">
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <label for="ID">ID</label>
						        <input type="text" class="form-control" name="IDsearch" id="IDsearch" placeholder="ID" />
                            </div>

                            
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <div class="form-group">
                                    <label for="CategoryCode">Category</label>
                                    <select  type="CategoryCode" name="CategoryCode" id="CategoryCode" class="form-control input-sm" value="" required>
                                                        <option value="">Category</option>                                                   
                                                        <option value="0001">Driver</option>
                                                        <option value="0002">Unit</option>      
                                                        <option value="0003">Battery</option>     
                                                        <option value="0004">Charger</option>     
                                    </select>
                                </div>
                            </div>
                        </div>
                     
                        <div class="row">
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="searchBtn" class="btn btn-info form-control text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Search</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="resetBtn" class="btn btn-warning form-control focus:outline-none text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:focus:ring-yellow-900">Clear Texbox</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="addequipment"  data-toggle="modal" data-target="#exampleModal" onclick="addmodalopen('0001','Driver')" class="btn  form-control focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">ADD Driver</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="addequipment"  data-toggle="modal" data-target="#exampleModal" onclick="addmodalopen('0002','Unit')" class="btn  form-control focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">ADD Unit</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="addequipment"  data-toggle="modal" data-target="#exampleModal" onclick="addmodalopen('0003','Battery')"class="btn  form-control focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">ADD Battery</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="addequipment"  data-toggle="modal" data-target="#exampleModal" onclick="addmodalopen('0004','Charger')" class="btn  form-control focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">ADD Charger</button>
                            </div>
                        </div>

					</div>
				</div>
				
			</div>
		</div>
	</div>
    <hr>


    <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Equipment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
   
            <div class="modal-body">
                <div class="col-md-12">
                    <div id="ajaxContentnew"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" data-dismiss="modal">Close</button>
           
            </div>
      
    </div>
  </div>
  </div>
<!-- --------------------- -->

	<div class="row">
		<div class="col-md-12">
			<div id="ajaxContent"></div>
		</div>
	</div>




<script>

    function addmodalopen(CategoryCode, Category) {
        
         

			var base_url = '<?php echo site_url('Equipments/addingequipments/') ?>';
            $.ajax({
				type: "POST",
				url: base_url,
				data:  "CategoryCode=" + CategoryCode + "&Category=" + Category,

				
				
				
				success: function(response) {
					console.log(response);
                    // ('#myModal').modal(toggle);
					$("#ajaxContentnew").html(response);
                    // alert(response);
					
				}
			});
    }
</script>




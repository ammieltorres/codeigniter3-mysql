<div class="row container-fluid">

<form Method="post" id="addnewequipment">
<div class="form-group">
        <div class="row">
        <div class="col-md-4">
                <label for="ID">Category Code</label>
                <input type="text" name="p_CategoryCode" id="p_CategoryCode"  value="<?php echo $CategoryCode ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="ID">Category</label>
                <input type="text" name="p_Category" id="p_Category" value="<?php echo $Category ?>" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                <label for="ID">ID</label>
                <input type="text" name="p_ID" id="p_ID" class="form-control" required>
            </div>
        </div>
        <div class="row" <?php if($CategoryCode != '0001') {?> hidden <?php } ?>>
            <div class="col-md-4">
                <label for="p_LName">Last Name</label>
                <input type="text" name="p_LName" id="p_LName" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_FName">First Name</label>
                <input type="text" name="p_FName" id="p_FName" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_MName">Middle Name</label>
                <input type="text" name="p_MName" id="p_MName" class="form-control">
            </div>
        </div>
        <div class="row" hidden>
            <div class="col-md-4">
                <label for="p_EStatus">p_EStatus</label>
                <input type="text" name="p_EStatus" id="p_EStatus" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_EDateTime">p_EDateTime</label>
                <input type="text" name="p_EDateTime" id="p_EDateTime" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_CStatus">p_CStatus</label>
                <input type="text" name="p_CStatus" id="p_CStatus" class="form-control">
            </div>
        </div>

        <div class="row" hidden>
            <div class="col-md-4">
                <label for="p_CDateTime">p_CDateTime</label>
                <input type="text" name="p_CDateTime" id="p_CDateTime" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_RStatus">p_RStatus</label>
                <input type="text" name="p_RStatus" id="p_RStatus" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="p_RDateTime">p_RDateTime</label>
                <input type="text" name="p_RDateTime" id="p_RDateTime" class="form-control">
            </div>
        </div>
        <div class="row" hidden>
            <div class="col-md-6">
                <label for="p_RFIDCode">p_RFIDCode</label>
                <input type="text" name="p_RFIDCode" id="p_RFIDCode" class="form-control">
            </div>
            <div class="col-md-6">
                <label for="p_SystemID">p_SystemID</label>
                <input type="text" name="p_SystemID" id="p_SystemID" class="form-control">
            </div>
        </div>
    </div>

    <button type="Submit" class="btn btn-primary form-control text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Save</button>
  
    </form>
</div>



<script>
    $('#addnewequipment').unbind("submit");
    $("#addnewequipment").submit(function(e) 
    {
      e.preventDefault();

      
        var p_ID                     = $("#p_ID").val();
        var p_CategoryCode             = $("#p_CategoryCode").val();
        var p_Category                 = $("#p_Category").val();

        var p_LName                  = $("#p_LName").val();
        var p_FName                  = $("#p_FName").val();
        var p_MName                  = $("#p_MName").val();

        var p_EStatus                = $("#p_EStatus").val();
        var p_EDateTime              = $("#p_EDateTime").val();
        var p_CStatus                = $("#p_CStatus").val();

        var p_CDateTime              = $("#p_CDateTime").val();
        var p_RStatus                = $("#p_RStatus").val();
        var p_RDateTime              = $("#p_RDateTime").val();

        var p_RFIDCode               = $("#p_RFIDCode").val();
        var p_SystemID               = $("#p_SystemID").val();


			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Equipments/addnewequipment/') ?>",
				data:   "p_CategoryCode=" + p_CategoryCode +
                        "&p_Category=" + p_Category +
                        "&p_ID=" + p_ID +
                        "&p_LName=" + p_LName +
                        "&p_FName=" + p_FName +
                        "&p_MName=" + p_MName +
                        
                        "&p_EStatus=" + p_EStatus +
                        "&p_EDateTime=" + p_EDateTime +
                        "&p_CStatus=" + p_CStatus +
                        
                        "&p_CDateTime=" + p_CDateTime +
                        "&p_RStatus=" + p_RStatus +
                        "&p_RDateTime=" + p_RDateTime +
                        
                        "&p_RFIDCode=" + p_RFIDCode +
                        "&p_SystemID=" + p_SystemID,
				
				success: function(response) {
     
					console.log(response);
                    $("#ajaxContentnew").html(response);
                                        // $('#ADDUserAccessModal').modal('hide');
                                        // $('#message').modal('toggle');
                                        // $("#messagemodal").html(response);
		
    
				}
			});
            return false;
		});
</script>

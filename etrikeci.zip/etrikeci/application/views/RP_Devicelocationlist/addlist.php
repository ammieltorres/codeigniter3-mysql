

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
		


<script>
	
	$(function() {
		
		/*--first time load--*/
		ajaxlist(page_url = false);
		
		/*-- Search keyword--*/
		$(document).on('click', "#searchBtn", function(event) {
			ajaxlist(page_url=false);
			event.preventDefault();
		});
		
		/*-- Reset Search--*/
		$(document).on('click', "#resetBtn", function(event) {
			$("#imei").val('');
            $("#deviceName").val('');
			
			ajaxlist(page_url=true);
			event.preventDefault();

			
		});
		
		/*-- Page click --*/
		$(document).on('click', ".pagination li a", function(event) {
			var page_url = $(this).attr('href');
			ajaxlist(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function ajaxlist(page_url = false)
		{
            // alert('123');
			var imei 	        = '';
            var deviceName 	        ='';

			
            var base_url = 'https://aenterprise.biz/etrike/TSCon/tscron';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "imei=" + imei + "&deviceName=" +  deviceName,

				
				
				
				success: function(response) {
					console.log(response);
					$("#ajaxContent").html(response);

					
				}
			});

		}
	});
	</script>
  </body>
</html>









<!-- https://bootstrapious.com/p/bootstrap-sidebar -->

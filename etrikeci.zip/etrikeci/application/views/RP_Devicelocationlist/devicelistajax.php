
<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>   
                <th>Device Name</th>
                <th>imei</th>
                <th>speed</th>
                <th>Power Value</th>
                <th>Timestamp</th>
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($DeviceList))
                {
                
                ?>

                    <?php foreach ($DeviceList as $row) 
                    {
                      ?>
                        <tr>
                            <td><?php echo $row->deviceName ?></td>
                            <td><?php echo $row->imei ?></td>
                            <td><?php echo $row->speed ?></td>
                            <td><?php echo $row->powerValue ?></td>
                            <td><?php echo $row->DateTimeStamp ?></td>
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


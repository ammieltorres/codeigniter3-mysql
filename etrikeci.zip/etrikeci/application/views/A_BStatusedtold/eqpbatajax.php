


<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <!-- <th>Branch</th> -->
                <th>Action</th>
                <th>Category</th>
                <th>ID</th>
                <th>Swap Status</th>

                <th>Repair Status</th>
                <th>Charge Status</th>
    
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($BatteryReports))
                {
                
                ?>

                    <?php foreach ($BatteryReports as $row) 
                    {
                      ?>
                        <tr>
                        <td><button class="btn btn-primary" id="getrec" value="<?php echo $row->ID .'|'. $row->Category .'|'. $row->EStatus .'|'. $row->RStatus .'|'. $row->CStatus?>">Edit Status</button></td>

                            <td><?php echo $row->Category ?></td>
                            <td><?php echo $row->ID ?></td>
                            <td><?php echo $row->EStatus ?></td>
                            <td><?php echo $row->RStatus ?></td>
                            <td><?php echo $row->CStatus ?></td>
                           
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>
<!-- Modal -->
<div class="modal fade" id="batterystatusmodal" tabindex="-1" role="dialog" aria-labelledby="batterystatusmodal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="batterystatusmodal">Edit Battery Status</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" id="updatebattery" Method="POST">
            <div class="modal-body">
                            <div id="ModalBatteryData"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="Submit" class="btn btn-primary">Save changes</button>
            </div>

      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="batterystatusmodalresultedt" tabindex="-1" role="dialog" aria-labelledby="batterystatusmodalresultedt" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="batterystatusmodalresultedt">Result</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

            <div class="modal-body">
                            <div id="ModalBatteryDataresulte"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="srch" data-dismiss="modal">Close</button>
               
            </div>

    </div>
  </div>
</div>


<script>
  $('#getrec').unbind("submit");
$(document).on('click', "#getrec", function(event) {
    
        var getrec = $(this).val();

    // alert(getrec);
  
  $.ajax({
    method: "POST",
    url: "<?php echo site_url('Adminc/BatteryModalStatusdata/') ?>",
    data:  "getrec=" + getrec,
    
    success: function(response) {
      console.log(response);
      // alert(RegIDQ)
      $("#ModalBatteryData").html(response);
      $('#batterystatusmodal').modal('toggle');

      
    }
  });

   
});

</script>



<script>
    $('#updatebattery').unbind("submit");
    $("#updatebattery").submit(function(e) 
    {
      e.preventDefault();
			var p_id              = $("#p_id").val();
      var p_category        = $("#p_category").val();
      var p_status          = $("#p_status").val();
      var p_value           = $("#p_value").val();
    

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Adminc/ModalStatusUpdate/') ?>",
				data:  "p_id=" + p_id + "&p_category=" + p_category + "&p_status=" + p_status + "&p_value=" + p_value,		
				
				success: function(response) {
     
					console.log(response);
  
          $('#batterystatusmodal').modal('hide');
          $('#batterystatusmodalresultedt').modal('toggle');
          $("#ModalBatteryDataresulte").html(response);
    
				}
			});
            return false;
		});
</script>

<?php
if($result)
{
    foreach($result as $row)
    {
        // echo $row->p_category;
        // if($row->p_category == "BATTERY")
        //     { echo "Battery";
        //     }   
        // elseif($row->p_category == "Charger")
        //     { echo "CHARGER";
        //     }   
        // elseif($row->p_category == "UNIT")
        //     { echo "UNIT";
        //     }
        // else
        //     {
        //         echo "none";
        //     }
            if(stripos($row->p_category,'BATTERY') !== FALSE)
            {
                 $VCBattery =  $row->v_vcbattery;
                 $VRBattery = $row->v_vrbattery;
                 $VSBattery = $row->v_vsbattery;
                if(empty($VCBattery))
                {
                    ?>
                        <div class="alert alert-danger" role="alert">
                            ERROR: BATTERY IS IN CHARGE IN STATE <?php echo $row->v_vcbatterydatetimestamp?> (Charge)
                        </div>
                    <?php
                }
                elseif(empty($VRBattery))
                {
                    ?>
                    <div class="alert alert-danger" role="alert">
                            ERROR: BATTERY IS IN REPAIR STATE<?php echo $row->v_vrbatterydatetimestamp?> (Repair)
                    </div>
                <?php
                }
                elseif(empty($VSBattery))
                {
                    ?>
                    <div class="alert alert-danger" role="alert">
                            ERROR: BATTERY IS IN SWAP OUT STATE <?php echo $row->v_vsbatterydatetimestamp?> (Swap)
                    </div>
                    
                <?php
                } 
                elseif($VCBattery & $VRBattery & $VRBattery)
                {
                    ?> 
                    
                            <div class="alert alert-success" role="alert">
                    <?php echo $row->p_branch?>
              
                     </div>
                                <div class="row">    
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                        <label for="RRepairType">Repair Type</label>
                        <input type="text" name="RRepairType" id="RRepairType" class="form-control input-sm"  placeholder="RRepairType" value="<?php echo $row->p_repairtype ?>" readonly >
                        </div>
                    </div>  
           
                </div> 
                <div class="row">    
          
                    <div class="col-xs-6 col-sm-6 col-md-6">
                        <div class="form-group">
                        <label for="RItem">Item</label>
                        <input type="text" name="RItem" id="RItem" class="form-control input-sm"  placeholder="RItem"   value="<?php echo $row->p_itemid ?>" readonly >
                        </div>
                    </div>    
                    <div class="col-xs-6 col-sm-6 col-md-6">
                        <div class="form-group">
                        <label for="RCategory">Category</label>
                        <input type="text" name="RCategory" id="RCategory" class="form-control input-sm"  placeholder="RCategory" value="<?php echo $row->p_category ?>" readonly >
                        </div>
                    </div>    
                </div>  
    
            
    
    
                <div class="row">    
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                        <label for="RAttendant">Attendant</label>
                        <input type="text" name="RAttendant" id="RAttendant" class="form-control input-sm"  placeholder="Attendant" value="<?php echo $row->p_luser.','.$row->p_fuser.' '.$row->p_muser ?>" readonly >
                        </div>
                    </div>  
                </div> 
                <div class="row">    
                <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <div id="RReferencecode"></div>
                        </div>
                    </div>  
               
                </div> 
                <?php
                }

            }
            elseif(stripos($row->p_category,'UNIT') !== FALSE) {
                 $VCUnit =  $row->v_vcunit;
                 $VRUnit = $row->v_vrunit;
                 $VSUnit = $row->v_vsunit;

                if(empty($VCUnit))
                {
                    ?>
                        <div class="alert alert-danger" role="alert">
                            ERROR: UNIT  <?php echo $row->p_chargetype ?> STATE <?php echo $row->v_vcunitdatetimestamp?> (Charge)
                        </div>
                    <?php
                }
                elseif(empty($VRUnit))
                {
                    ?>
                    <div class="alert alert-danger" role="alert">
                            ERROR: UNIT IS IN REPAIR STATE <?php echo $row->v_vrunitdatetimestamp?> (Repair)
                    </div>
                <?php
                }
                elseif(empty($VSUnit))
                {
                    ?>
                    <div class="alert alert-danger" role="alert">
                            ERROR: UNIT IS IN SWAP OUT STATE <?php echo $row->v_vsunitdatetimestamp?> (Swap)
                    </div>
                    
                <?php
                }
                 elseif($VCUnit & $VRUnit & $VSUnit)
                 {
                     ?> 
                     
                <div class="alert alert-success" role="alert">
                     <?php echo $row->p_branch?>
               
                      </div>
                                 <div class="row">    
                     <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                         <label for="RRepairType">Repair Type</label>
                         <input type="text" name="RRepairType" id="RRepairType" class="form-control input-sm"  placeholder="RRepairType" value="<?php echo $row->p_repairtype ?>" readonly >
                         </div>
                     </div>  
            
                 </div> 
                 <div class="row">    
           
                     <div class="col-xs-6 col-sm-6 col-md-6">
                         <div class="form-group">
                         <label for="RItem">Item</label>
                         <input type="text" name="RItem" id="RItem" class="form-control input-sm"  placeholder="RItem"   value="<?php echo $row->p_itemid ?>" readonly >
                         </div>
                     </div>    
                     <div class="col-xs-6 col-sm-6 col-md-6">
                         <div class="form-group">
                         <label for="RCategory">Category</label>
                         <input type="text" name="RCategory" id="RCategory" class="form-control input-sm"  placeholder="RCategory" value="<?php echo $row->p_category ?>" readonly >
                         </div>
                     </div>    
                 </div>  
     
             
     
     
                 <div class="row">    
                     <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                         <label for="RAttendant">Attendant</label>
                         <input type="text" name="RAttendant" id="RAttendant" class="form-control input-sm"  placeholder="Attendant" value="<?php echo $row->p_luser.','.$row->p_fuser.' '.$row->p_muser ?>" readonly >
                         </div>
                     </div>  
                 </div> 
                 <div class="row">    
                 <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                             <div id="RReferencecode"></div>
                         </div>
                     </div>  
                
                 </div> 
            
                     <?php
                 }
                }
            
        
    

                elseif(stripos($row->p_category,'CHARGER') !== FALSE) {
                 $v_vccharger =  $row->v_vccharger;
                 $v_vrcharger = $row->v_vrcharger;


                if(empty($v_vccharger))
                {
                    ?>
                        <div class="alert alert-danger" role="alert">
                            ERROR: CHARGER IS IN CHARGE STATE <?php echo $row->v_vcchargerdatetimestamp?> (Charge)
                        </div>
                    <?php
                }
                elseif(empty($v_vrcharger))
                {
                    ?>
                    <div class="alert alert-danger" role="alert">
                            ERROR: CHARGER REPAIR STATE <?php echo $row->v_vrchargerdatetimestamp?> (Repair)
                    </div>
                <?php
                }
              
                 elseif($v_vccharger & $v_vrcharger )
                 {
                     ?> 
                     
                <div class="alert alert-success" role="alert">
                     <?php echo $row->p_branch?>
               
                      </div>
                                 <div class="row">    
                     <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                         <label for="RRepairType">Repair Type</label>
                         <input type="text" name="RRepairType" id="RRepairType" class="form-control input-sm"  placeholder="RRepairType" value="<?php echo $row->p_repairtype ?>" readonly >
                         </div>
                     </div>  
            
                 </div> 
                 <div class="row">    
           
                     <div class="col-xs-6 col-sm-6 col-md-6">
                         <div class="form-group">
                         <label for="RItem">Item</label>
                         <input type="text" name="RItem" id="RItem" class="form-control input-sm"  placeholder="RItem"   value="<?php echo $row->p_itemid ?>" readonly >
                         </div>
                     </div>    
                     <div class="col-xs-6 col-sm-6 col-md-6">
                         <div class="form-group">
                         <label for="RCategory">Category</label>
                         <input type="text" name="RCategory" id="RCategory" class="form-control input-sm"  placeholder="RCategory" value="<?php echo $row->p_category ?>" readonly >
                         </div>
                     </div>    
                 </div>  
     
             
     
     
                 <div class="row">    
                     <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                         <label for="RAttendant">Attendant</label>
                         <input type="text" name="RAttendant" id="RAttendant" class="form-control input-sm"  placeholder="Attendant" value="<?php echo $row->p_luser.','.$row->p_fuser.' '.$row->p_muser ?>" readonly >
                         </div>
                     </div>  
                 </div> 
                 <div class="row">    
                 <div class="col-xs-12 col-sm-12 col-md-12">
                         <div class="form-group">
                             <div id="RReferencecode"></div>
                         </div>
                     </div>  
                
                 </div> 
            
                     <?php
                 }
                }
            
        
    

                     ?>  

            
            





        
          
            
           
            
         


            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
              
                         <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="newrecord()">Scan New</button>
                     
                   
                 
                    </div>
                </div>  
          
            
<script src="<?php echo  base_url('js/qrcdm.js') ?>"></script>
<script type="text/javascript">
var qrcode = new QRCode(document.getElementById("RReferencecode"), {
	text: "<?php echo $row->v_referencecode ; ?>",
	width: 128,
	height: 128,
	colorDark : "#009608",
	colorLight : "#ffffff",
	correctLevel : QRCode.CorrectLevel.H
});
</script>

        <?php
    }
}
?>


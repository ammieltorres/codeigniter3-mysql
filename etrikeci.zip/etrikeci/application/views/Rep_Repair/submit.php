





<?php
  if($result)
  {
    foreach($result as $row)
    {
      ?>




<div class="row">                                        
    <div class="col-xs-4 col-sm-4 col-md-4">       
        <div class="form-group">
            <label for="p_itemid">ID</label>
           <input style="background-color:#e9ecef;" type="text" name="p_itemid" id="p_itemid" class="form-control input-sm"  onkeypress="return false;" value="<?php echo $row['ID'] ?>" required >
        </div>
    </div>
    <div class="col-xs-4 col-sm-4 col-md-4">      
        <div class="form-group">
            <label for="p_category">category</label>
           <input style="background-color:#e9ecef;" type="text" name="p_category" id="p_category" class="form-control input-sm"   onkeypress="return false;" value="<?php echo $row['Category'] ?>" required >
        </div>
    </div>
    <!-- <div class="col-xs-4 col-sm-4 col-md-4">     
        <div class="form-group">
            <label for="p_batteryid">Repair Type</label>
            <select  type="text" name="p_repairtype" id="p_repairtype" class="form-control input-sm" value="" required>                                              
                                    <option value="REPAIR IN">REPAIR IN</option>
                                    <option value="REPAIR OUT">REPAIR OUT</option>      
              </select>
        </div>
    </div> -->
</div>











<div class="row">                                        
    <div class="col-xs-5 col-sm-5 col-md-5">       
        <button  class="btn btn-success form-control "  onclick="repairsub(event)" type="submit" value="REPAIR IN"  id ="subrec" name="submit">REPAIR IN</button>
      
    </div>
    <div class="col-xs-2 col-sm-2 col-md-2">       
      
      
    </div><br>
    <div class="col-xs-5 col-sm-5 col-md-5">              
      
    <button  class="btn btn-danger form-control"  onclick="repairsub(event)" type="submit" value="REPAIR OUT" id ="subrec "name="submit">REPAIR OUT</button>
    </div>
</div>




<!-- <div class="row">                                        
    <div class="col-xs-12 col-sm-12 col-md-12">       
        <button  class="btn btn-success form-control" type="submit"  id ="subrec"name="submit">Submit</button>
    </div>
</div> -->

<div class="modal fade" id="Result" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Result</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ResData"></div>
      </div>
 
    </div>
  </div>
</div>






<?php
    }
  }
?>
<script>
   function repairsub(event) {

  $('#submitrecord').unbind("submit");
    $("#submitrecord").submit(function(e) 
    {
          e.preventDefault();
            $('#subrec').attr('disabled','disabled');
            

            var p_itemid        = $("#p_itemid").val();
            var p_category         = $("#p_category").val();
            var p_repairtype         = (event.target.value);
    
           
			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Repair/RepairRecord/') ?>",
				data:  "p_itemid=" + p_itemid + "&p_category=" + p_category + 
                "&p_repairtype=" + p_repairtype,		
				
				success: function(response) {
				console.log(response);

                $('#Result').modal('toggle');
                $("#ResData").html(response);
                $("#p_chargetype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                // document.getElementById('p_swaptype').options[1].selected = 'selected';
                $('#Result').modal('toggle')
                // $('#Result').modal('toggle')
				}
			});
        
		});
  }
</script>

<script>
    $(document).ready(function(){
      video.srcObject.getTracks().forEach(track => {
          track.stop();
        });
        qrResult.hidden = false;
        canvasElement.hidden = true;
        btnScanQR.hidden = false;
    });
</script>           

<script>
    function openqrscan()
    {
        navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      btnScanQR.hidden = false;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
    }
</script>


<script>
       function newrecord()
    {

   
        $.ajax({
				method: "POST",
				url: "<?php echo site_url('Charging/removesession/') ?>",
        success: function(response) {
          location.reload()
        }
        });
        
    
        document.getElementById('p_swaptype').options[0].selected = 'selected';
    }
</script>
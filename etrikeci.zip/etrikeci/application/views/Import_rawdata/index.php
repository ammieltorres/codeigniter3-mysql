<form method="post" action="<?php echo base_url('ImportData/importreportrawdataprocess');?>" enctype="multipart/form-data" target="after" onsubmit="close()">

        <br><br>
<div class="box">
	<div class="row">

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">


             
             


                    <input type="file" name="upload_file" id="upload_file" required>
                  





					</div>
				</div>
				

				<div class="col-md-4">
					<div class="search-button">
					<br>
						<button type="submit" value = "SUBMIT" class="btn  form-control focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 ">IMPORT DATA</button>

					</div>
				</div>
			</div>
		</div>
	</div>

    </form>



<br>
<br>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <th>Branch</th>
                <th>Attendant</th>
                <th>Battery</th>
                <th>Time</th>
                <th>Type</th>
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($BatteryReports))
                {
                
                ?>

                    <?php foreach ($BatteryReports as $row) 
                    {
                      ?>
                        <tr>

                            <td><?php echo $row->Branch ?></td>
                            <td><?php echo $row->UserID ?></td>
                            <td><?php echo $row->BatteryID ?></td>
                            <td><?php echo $row->DateTimeStamp ?></td>
                            <td><?php echo $row->ChargeType ?></td>
                           
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


<!-- <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="p_swaptype">SWP TYPE</label>
              <select  type="text" name="p_swaptype" id="p_swaptype" class="form-control input-sm" value="" required>                                              
                                    <option value="SWAP IN">SWAP IN</option>
                                    <option value="SWAP OUT">SWAP OUT</option>      
              </select>
        </div>
    </div>       
</div>     -->



<div class="row">                                        
    <div class="col-xs-5 col-sm-5 col-md-5">       
        <button  class="btn btn-success form-control "  onclick="swapsub(event)" type="submit" value="SWAP IN"  id ="subrec" name="submit">SWAP IN</button>
      
    </div>
    <div class="col-xs-2 col-sm-2 col-md-2">       
      
      
    </div><br>
    <div class="col-xs-5 col-sm-5 col-md-5">              
      
        <button  class="btn btn-danger form-control"  onclick="swapsub(event)" type="submit" value="SWAP OUT" id ="subrec "name="submit">SWAP OUT</button>
    </div>
</div>



<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="Result" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Result</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ResData"></div>
      </div>
 
    </div>
  </div>
</div>


<script>
  function swapsub(event) {


  $('#submitrecord').unbind("submit");
    $("#submitrecord").submit(function(e) 
    {


          e.preventDefault();
            $('#subrec').attr('disabled','disabled');
            // console.log
			      var p_swaptype            = (event.target.value);
            var p_unitid              = $("#p_unitid").val();
            var p_batteryid           = $("#p_batteryid").val();
            var p_driverid            = $("#p_driverid").val();
            var p_ldriver             = $("#p_ldriver").val();
            var p_fdriver             = $("#p_fdriver").val();
            var p_mdriver             = $("#p_mdriver").val();
            // alert(p_swaptype);
           
			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/AddSwappingRecord/') ?>",
				data:  "p_swaptype=" + p_swaptype + "&p_unitid=" + p_unitid + 
                "&p_batteryid=" + p_batteryid + "&p_driverid=" + p_driverid + 
                "&p_ldriver=" + p_ldriver + "&p_fdriver=" + p_fdriver + "&p_mdriver=" + p_mdriver,		
				
				success: function(response) {
				console.log(response);

                $("#ResData").html(response);
                // $("#p_swaptype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                $('#Result').modal('toggle');
              

				}
			});
        
		});

  }
</script>

<script>
    $(document).ready(function(){
      video.srcObject.getTracks().forEach(track => {
          track.stop();
        });
        qrResult.hidden = false;
        canvasElement.hidden = true;
        btnScanQR.hidden = false;
    });
</script>           

<script>
    function openqrscan()
    {
        navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      btnScanQR.hidden = false;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
    }
</script>


<script>
       function newrecord()
    {

        $("#p_unitid").val('');
        $("#p_batteryid").val('');
        $("#p_driverid").val('');
        $("#p_ldriver").val('');
        $("#p_fdriver").val('');
        $("#p_mdriver").val('');
        $.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/removesession/') ?>",
        success: function(response) {
          location.reload()
        }
        });
        
    
        document.getElementById('p_swaptype').options[0].selected = 'selected';
    }
</script>
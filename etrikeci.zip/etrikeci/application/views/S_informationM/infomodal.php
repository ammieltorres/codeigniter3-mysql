

<div class="modal fade" id="batinfomodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Info</h5>

      </div>
      <div class="modal-body">
      <div class="row">    

      <?php
      if($record)
      {
        ?>
            <div class="alert alert-success" role="alert">
               <?php echo $Category ?> Scanned.
        </div>
        <?php
      }
      else
      {
        ?>
    <div class="alert alert-danger" role="alert">
               No Record Found.
        </div>
        <?php
      }
      ?>
  
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                    <label for="p_batteryid"> <?php echo $Category.'-'.$ID ?></label>
                    <input style="background-color:#e9ecef;" type="text" name="dataM" id="dataM" class="form-control input-sm"  onkeypress="return false;" value=" <?php echo $ID.' -'.$LName.','. $FName.' '.$MName ?>" >
                    </div>
                </div>      
            </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success form-control" onclick="opencamM()" data-dismiss="modal">ok</button>

      </div>
    </div>
  </div>
</div>


<script>
    $(document).ready(function(){
      video.srcObject.getTracks().forEach(track => {
          track.stop();
        });
        qrResult.hidden = false;
        canvasElement.hidden = true;
        btnScanQR.hidden = false;
        $('#batinfomodal').modal('toggle');
      
    });

    function opencamM()
    {
       
     $("#btn-scan-qr").trigger('click');
        // $('#batinfomodal').modal('destroy');
        // $("#batinfomodal").remove();
        
        
//         $(".modal").remove();
//         $('.modal-backdrop').remove();
// $('.modal').data('modal', null);

// $( '.modal' ).remove();
// $( '.modal-backdrop' ).remove();
// $( 'body' ).removeClass( "modal-open" );
    }
</script>      

<!-- <script src="<?php echo base_url("js/cdn.tailwind.js"); ?>"></script> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<?php
  if($rp_equipments_status)
  {

    foreach($rp_equipments_status as $row)
    {
      // Charger
        $TChargerIN         = $row->TChargerIN;
        $TChargerOUT        = $row->TChargerOUT;
        $TChargerTotal      = $TChargerIN + $TChargerOUT;

        $TChargerRepairIN   = $row->TChargerRepairIN;
        $TChargerRepairOUT  = $row->TChargerRepairOUT;
        $TChargerTotalR      = $TChargerRepairIN + $TChargerRepairOUT;


      // Battery
        $TBatteryRepairIN   = $row->TBatteryRepairIN;
        $TBatteryRepairOut  = $row->TBatteryRepairOut;
        $TBatteryRepairT      = $TBatteryRepairIN + $TBatteryRepairOut;
          
        $TBatteryChargeIN   = $row->TBatteryChargeIN;
        $TBatteryChargeOut  = $row->TBatteryChargeOut;
        $TBatteryChargeT    = $TBatteryChargeIN + $TBatteryChargeOut;
        
        $TBatterySWAPIN     = $row->TBatterySWAPIN;
        $TBatterySWAPOut    = $row->TBatterySWAPOut;
        $TBatterySWAPT      = $TBatterySWAPIN + $TBatterySWAPOut;

        //unit
        $TUnitRepairIN      = $row->TUnitRepairIN;
        $TUnitRepairOut     = $row->TUnitRepairOut;
        $TUnitRepairT      = $TUnitRepairIN + $TUnitRepairOut;
        
        $TUnitOUT           = $row->TUnitOUT;
        $TUnitIN            = $row->TUnitIN;
        $TUnitT      = $TUnitOUT + $TUnitIN;

     


    }
  }
    ?>
    


<!-- <h2 class="text-2xl font-bold mb-4">Equipment Available</h2> -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-3">
            <i class="fas fa-truck icon-pulse text-blue-500 mr-2"></i>
            UNIT Available
        </h3>
        <p class="text-3xl font-bold"><?php echo $TUnitIN .'/'. $TUnitT; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-3">
            <i class="fas fa-battery-full icon-pulse text-green-500 mr-2"></i>
            BATTERY Available
        </h3>
        <p class="text-3xl font-bold"><?php echo $TBatterySWAPIN .'/'. $TBatterySWAPT; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-3">
            <i class="fas fa-plug icon-pulse text-yellow-500 mr-2"></i>
            CHARGER Available
        </h3>
        <p class="text-3xl font-bold"><?php echo $TChargerOUT .'/'. $TChargerTotal; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-3">
            <i class="fas fa-bolt icon-pulse text-purple-500 mr-2"></i>
            BATTERY Charge
        </h3>
        <p class="text-3xl font-bold"><?php echo $TBatteryChargeIN .'/'. $TBatteryChargeT; ?></p>
    </div>
</div>


<br>
<h2 class="text-2xl font-bold mb-4">Equipment Repair</h2>
<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-2">
            <i class="fas fa-wrench icon-pulse text-red-500 mr-2"></i>
            UNIT Repair
        </h3>
        <p class="text-3xl font-bold"><?php echo $TUnitRepairIN .'/'. $TUnitRepairT; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-2">
            <i class="fas fa-tools icon-pulse text-orange-500 mr-2"></i>
            BATTERY Repair
        </h3>
        <p class="text-3xl font-bold"><?php echo $TBatteryRepairIN .'/'. $TBatteryRepairT; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-2">
            <i class="fas fa-cog icon-pulse text-indigo-500 mr-2"></i>
            CHARGER Repair
        </h3>
        <p class="text-3xl font-bold"><?php echo $TChargerRepairIN .'/'. $TChargerTotalR; ?></p>
    </div>

</div>
    


      
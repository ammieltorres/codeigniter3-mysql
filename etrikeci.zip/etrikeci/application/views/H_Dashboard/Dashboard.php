
<style>
    body {
   height: 100%;
  overflow-y: hidden; /* Hide vertical scrollbar */
  overflow-x: hidden; /* Hide horizontal scrollbar */
}

 i
 {
     font-size:70px;
     color:green;
 }


</style>


<script>function display_ct7() {
var x = new Date()
var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';
hours = x.getHours( ) % 12;
hours = hours ? hours : 12;
hours=hours.toString().length==1? 0+hours.toString() : hours;

var minutes=x.getMinutes().toString()
minutes=minutes.length==1 ? 0+minutes : minutes;

var seconds=x.getSeconds().toString()
seconds=seconds.length==1 ? 0+seconds : seconds;

var month=(x.getMonth() +1).toString();
month=month.length==1 ? 0+month : month;

var dt=x.getDate().toString();
dt=dt.length==1 ? 0+dt : dt;

var x1=month + "/" + dt + "/" + x.getFullYear(); 
x1 = x1 + " - " +  hours + ":" +  minutes + ":" +  seconds + " " + ampm;
document.getElementById('ct7').innerHTML = x1;
display_c7();
 }
 function display_c7(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct7()',refresh)
}
display_c7()
</script>

</head>

<body onload=display_ct();>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-4">
            <img style="width:300px;" src="<?php echo base_url('img/logonew.png') ?>">
        </div>
        <div class="col-lg-8">
            <h1 style="font-size:70px;"><span id='ct7' ></span></h1>
        </div>
    </div>



	<div class="row">
<hr>
<!-- --------------------- -->

<div class="col-sm-4">
    <div class="col-lg-12">
    	<div id="sitereportdata"></div>
    </div>
    <hr>
     <div class="col-lg-12">
         <label>Battery Track Solid API Insert (1 MIN) </label>
        <div id="BatRpt"> </div>
    </div>
      <div class="col-lg-12">
         <label>Mileage Track Solid API Insert (12 HRS)</label>
        <div id="MilRpt"> </div>
    </div>
    
</div>
    <div class="col-sm-8">
    	<div class="row">
    		<div class="col-lg-4">
    			<div id="Battery"></div>
    		</div>
    		<div class="col-lg-4">
    			<div id="L5KM"></div>
    		</div>
    		<div class="col-lg-4">
    			<div id="G5KM"></div>
    		</div>
    	</div>
    <div>





</div>
  </div>


<script>
 
$(document).ready(function() {
   sitereport()
nextpages();

});



function nextpages()
{
    
 
        var numberpagesbat = <?php echo $numberpagesbat ?>;
        var numberpagesbatV = <?php echo $numberpagesbat ?>;
        
        
        var numberpagesl5km = <?php echo $numberpagesl5km ?>;
        var numberpagesl5kmV = <?php echo $numberpagesl5km ?>;
        
        var numberpagesg5km = <?php echo $numberpagesg5km ?>;
        var numberpagesg5kmV = <?php echo $numberpagesg5km ?>;
        
        
        console.log(numberpagesbat);
        setTimeout(excuteMethod, 15000);
        setTimeout(getbatrec, 5000);
        setTimeout(tscronmilage, 8000);
        
        
        function excuteMethod() 
        {
            console.log(numberpagesbat + ' call');
     	    
            numberpagesbat--;
            numberpagesl5km--;
            numberpagesg5km--;
            
                setTimeout(excuteMethod, 15000);
                sitereport();
                
                if (numberpagesbat  >= 0) setTimeout(nextBattery(), 3000);
                if (numberpagesl5km >= 0) setTimeout(nextl5km(), 3000);
                if (numberpagesg5km >= 0) setTimeout(nextg5km(), 3000);
               
                if (numberpagesbat  <= 0) setTimeout(Battery(page_url = false), 5000);
                if (numberpagesl5km <= 0) setTimeout(L5KM(page_url = false), 5000);
                if (numberpagesg5km <= 0) setTimeout(G5KM(page_url = false), 5000);
                
              
                if (numberpagesbat <= 0) { numberpagesbat = numberpagesl5kmV;  }
                if (numberpagesl5km <= 0) { numberpagesl5km = numberpagesl5kmV;  }
                if (numberpagesg5km <= 0) { numberpagesg5km = numberpagesg5kmV;  }
               
            }
    
            function nextBattery()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="battery"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextl5km()
            {
                //  $("li[id='L5KM'] a[rel='next']").click();
                 
                 Array.from(document.querySelectorAll('li[id="L5KM"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextg5km()
            {
                //  $("li[id='G5KM'] a[rel='next']").click();
                 
                 Array.from(document.querySelectorAll('li[id="G5KM"] a[rel="next"]')).forEach(button=>button.click());
            }
		};
		
// 	================== Site Report =======================

    function sitereport()
    {
        
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/sitereport/') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#sitereportdata").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
// 	==================================== L5 KM ================================	
		/*--first time load--*/
		L5KM(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.l5km li a", function(event) {
			var page_urlL5KM = $(this).attr('href');
			L5KM(page_urlL5KM);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function L5KM(page_url = false)
		{
			var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/L5KM/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#L5KM").html(response);
					console.log(base_url);

					
				}
			});

		}
// 	==================================== G5 KM ================================	
		/*--first time load--*/
		G5KM(page_url = false);

		/*-- Page click --*/
		$(document).on('click', ".pagination.g5km li a", function(event) {
			var page_urlG5KM = $(this).attr('href');
			G5KM(page_urlG5KM);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function G5KM(page_url = false)
		{
			var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/G5KM/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#G5KM").html(response);
					console.log(base_url);

					
				}
			});

		}
	
	
	// 	================================ Battery ================================	
		/*--first time load--*/
		Battery(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.battery li a", function(event) {
			var page_url = $(this).attr('href');
			Battery(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function Battery(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Dashboard/GetLowVolBattery/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#Battery").html(response);

					
				}
			});

		}

</script>
<!-- ================ Track Solid Api Get ================-->



<script>
    
      function getbatrec()
    {
        setTimeout(getbatrec, 60000);
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('TSCon/tsgetdevice') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#BatRpt").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
    
</script>



<script>
    
      function tscronmilage()
    {
        setTimeout(getbatrec, 43200000);
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('TSCon/tscronmilage') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#MilRpt").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
    
</script>
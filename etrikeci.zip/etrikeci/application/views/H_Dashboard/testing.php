



<button class="btn btn-success" onclick="getbatrec()">get device</button>

<div id="BatRpt">
<script>
    
      function getbatrec()
    {
        
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('TSCon/tscronmilage') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#BatRpt").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
    
</script>
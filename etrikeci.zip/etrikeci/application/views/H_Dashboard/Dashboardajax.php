

<b><?php echo $result_count;?></b>
<br><br>

<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Battery</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Voltage</th>
            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php if(!empty($Battery)): ?>
            <?php foreach ($Battery as $row): ?>
                <tr>
                    <td class="px-4 py-2 whitespace-nowrap"><a class="btn btn-info" href='<?php echo base_url("TSCon/GPSDevice/$row->imei")  ?>' target="_blank">Locate</a></td>
                    <td class="px-4 py-2 whitespace-nowrap"><?php echo $row->deviceName ?></td>
                    <td class="px-4 py-2 whitespace-nowrap"><?php echo $row->powerValue ?></td>
                    <td class="px-4 py-2 whitespace-nowrap"><?php echo date('H:i', strtotime("$row->DateTimeStamp")); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" class="px-4 py-2">
                    <div class="alert alert-info">
                        No Record Found.
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>




  <div class="paging" hidden>
    <ul class="pagination battery">
    <li class="page-item "><?php echo $pagelinks ?></li>
	</ul>
</div>






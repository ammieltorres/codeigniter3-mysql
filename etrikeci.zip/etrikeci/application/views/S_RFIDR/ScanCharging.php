

     




<!-- <style>

.img
{
    width: 50px;
    height: 50px;
}


@import url('https://fonts.googleapis.com/css?family=Poppins:400,500,700');


.navbar.navbar-expand-md.navbar-light.navbar-default.bg-light.sticky-top{
  position: fixed;
  width: 100%;
  background-color: rgb(255, 255, 255);
  transition: .3s;
  }



.container-fluid .padding{
justify-content: center;
padding: 5rem 5rem 5rem 5rem ;
}



.navbar-default{
background-color: transparent;
opacity: 80%;
margin: 0;

}








.iconDetails {
margin-left:2%;
float:left; 
height:40px;
width:40px; 
} 

.container2 {
   width:100%;
   height:auto;
   padding:1%;
}




</style> -->







<body>





<center>


<div id="printableArea">





<div class="col-md-12 ">
  <div class="panel panel-default ">


    <div class="form-result">
 
      <div class="row justify-content-md-center">                                        
    <div class="col-xs-6 co lg-sm-6 col-md-6 ">       
    <canvas  hidden="" style=' width: 150%; 'id="qr-canvas"></canvas>
    </div>

      <div>
    <div>
  <div>
<div>



      
      </div>
                


      <div class="container mx-auto px-4 flex justify-center items-center">
      <div class="flex flex-col space-y-4 "> 
   
      <a href="<?php echo base_url('RFID/redirectchoice') ?>" class="rounded-full bg-green-500 text-white px-4 py-2">CLICK TO GO BACK TO CHOICES</a>
  </div>
</div>
<br>

<form id="search">
  <div class="form-group">
    <?php 
      if($SWAPTYPE === 'CHARGE IN')
      {
        ?>
  <div class="alert rounded-lg  bg-blue-700 text-white shadow-lg"><?php echo $SWAPTYPE; ?></div>
        <?php
      }
      else
      {
        ?>
  <div class="alert rounded-lg  bg-yellow-400 text-white shadow-lg"><?php echo $SWAPTYPE; ?></div>

<?php
      }
    ?>

  <br>


    <input type="text" class="rounded-lg border-green-800 focus:border-green-500 focus:ring-green-500"  name="ID" id="ID" autofocus></input>

  </div>



    <script src="<?php echo base_url('js/qr_packed.js') ?>"></script>

    <?php 
      if($SWAPTYPE === 'CHARGE IN')
      {
        ?>
 <h1 class="uppercase text-2xl font-bold text-blue-700 transition-all duration-300 animate-pulse uppercase">please tap the RFID</h1>
        <?php
      }
      else
      {
        ?>
 <h1 class="uppercase text-2xl font-bold text-yellow-400 transition-all duration-300 animate-pulse uppercase">please tap the RFID</h1>

<?php
      }
    ?>
       
  <!-- <a class="btn btn-info" id="btn-scan-qr">
       Scan     
  </a>
  <a class="btn btn-danger" id="btn-stopscan-qr">
       Scan stop
  </a> -->
  
  
  <button  class="btn btn-success" type="submit" id ="submit"name="submit" hidden>search</button>


</form>
<form id="submitrecord">
  
          <div id="result">

          </div>
          
</form>






</html>
</center>




<script>
  $('#search').unbind("submit");
    $("#search").submit(function(e) 
    {
      e.preventDefault();
			var ID            = $("#ID").val();
      var swapstatus = "<?php echo $SWAPTYPE ?>";
      // var status            = $("#status").val();

			$.ajax({
				method: "POST",
				url: "<?php echo site_url('RFID/queryRFIDRC/') ?>",
				data:  "ID=" + ID  + "&SWAPSTATUS=" + swapstatus,		
				
				success: function(response) {
					console.log(response);
                    $("#result").html(response);
                    $("#ID").val('');
                    var input = document.getElementById("ID").focus()
				}
			});
            return false;
		});
</script>
<script>
    $(".close-btn").click(function() {
    // $("#input-container").hide();
    const formFields = document.getElementById('form-fields');
        formFields.addEventListener('click', function(e) {
            if (e.target.classList.contains('close-btn')) {
                const fieldGroup = e.target.closest('.field-group');
                if (fieldGroup) {
                    fieldGroup.style.display = 'none';
                }
            }
         
        });
  });
    </script>
<div class="alert alert-info shadow-lg"> <h1 class="font-bold uppercase text-center">HELLO, <?php echo $this->session->userdata('LName') .', '.$this->session->userdata('FName'); ?></h1></div>

<div class="row">
  <div class="col-6 shadow-lg "><button onclick="redirect('swap_in')" value="SWAP IN" type="button" class="w-100 px-6 py-3.5 text-base font-medium text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">SWAPPING IN</button></div>
  <div class="col-6 shadow-lg"> <button onclick="redirect('charge_in')" value="CHARGE IN" type="button" class="w-100  px-6 py-3.5 text-base font-medium text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">CHARGER IN</button></div>
  <br><br><br>
  <div class="col-6 shadow-lg"><button onclick="redirect('swap_out')" value="SWAP OUT" type="button" class="w-100  px-6 py-3.5 text-base font-medium text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">SWAPPING OUT</button></div>
  <div class="col-6 shadow-lg"><button onclick="redirect('charge_out')" value="CHARGE OUT" type="button" class="w-100  px-6 py-3.5 text-base font-medium text-white bg-yellow-400 hover:bg-yellow-900 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">CHARGER OUT</button></div>
  <br><br><br>

  <div class="col-12 shadow-lg"><button value="" type="button" class="w-100  px-6 py-3.5 text-base font-medium text-dark  bg-blue-500 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">LOGOUT</button></div>
</div>

<script>
function redirect(action) {
  switch(action) {
    case 'swap_in':
      window.location.href = '<?php echo base_url("RFID/Swapping/SWAP_IN"); ?>';
      break;
    case 'charge_in':
      window.location.href = '<?php echo base_url("RFID/Charging/CHARGE_IN"); ?>';
      break;
    case 'swap_out':
      window.location.href = '<?php echo base_url("RFID/Swapping/SWAP_OUT"); ?>';
      break;
    case 'charge_out':
      window.location.href = '<?php echo base_url("RFID/Charging/CHARGE_OUT"); ?>';
      break;
  }
}
</script>
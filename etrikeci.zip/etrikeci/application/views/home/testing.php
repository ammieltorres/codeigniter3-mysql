<script>
    function doGet() {
  // Replace 'YOUR_SPREADSHEET_ID' with the ID of your Google Sheet
  var spreadsheetId = '1_Th0Bkoq8oM6Whe-SXzudRNfj35RsXgOoFuyOLkac88';
  
  // Replace 'YOUR_SHEET_NAME' with the name of the sheet you want to retrieve data from
  var sheetName = 'Sheet1';
  
  var sheet = SpreadsheetApp.openById(spreadsheetId).getSheetByName(sheetName);
  var data = sheet.getDataRange().getValues();
  
  // Get the header row
  var headers = data[0];
  
  // Create an array of objects, where each object represents a row of data
  var jsonData = [];
  for (var i = 1; i < data.length; i++) {
    var rowData = data[i];
    var rowObject = {};
    for (var j = 0; j < headers.length; j++) {
      rowObject[headers[j]] = rowData[j];
    }
    jsonData.push(rowObject);
  }
  
  // Return the data as JSON
  return ContentService.createTextOutput(JSON.stringify(jsonData))
      .setMimeType(ContentService.MimeType.JSON);
}
</script>

<b><?php echo $result_count;?></b>
<br><br>




<b><?php echo $result_count;?></b>
<br><br>

<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DeviceName</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Power Value</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Battery Power Val</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DateStamp</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php if(!empty($Battery)): ?>
            <?php foreach ($Battery as $row): ?>
                <tr>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->deviceName ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->powerValue ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->batteryPowerVal ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->DateTimeStamp ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3" class="px-3 py-2">
                    <div class="alert alert-info">
                        No Record Found.
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="paging" hidden>
    <ul class="pagination vol">
        <li class="page-item"><?php echo $pagelinks ?></li>
    </ul>
</div>


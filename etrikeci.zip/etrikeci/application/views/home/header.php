<link rel="stylesheet" type="text/css"  href="<?php echo base_url('css/dashboard.css'); ?>" >
<script src='<?php echo base_url('js/charts.js')?>'></script>
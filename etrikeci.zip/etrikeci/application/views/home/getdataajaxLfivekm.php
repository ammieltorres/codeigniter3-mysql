

<hr>

<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <th>imei</th>
                 <th>BatteryCode</th>
                <th>Distance(m)</th>
                    <th>Distance(km)</th>
                <th>StartTime</th>
                <th>EndTime</th>

           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($Equipments))
                {
                
                ?>

                    <?php foreach ($Equipments as $row) 
                    {
                      ?>
                        <tr>
                            <td><?php echo $row->IMEI; ?></td>
                             <td><?php echo $row->BatteryCode; ?></td>
                                   <td><?php echo round($row->Distance,2); ?></td>
                                 <td><?php echo round($row->Distance / 1000,2); ?></td>
                                  <td><?php echo $row->StartTime; ?></td>
                                     <td><?php echo $row->EndTime; ?></td>
   
                

                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination LF">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


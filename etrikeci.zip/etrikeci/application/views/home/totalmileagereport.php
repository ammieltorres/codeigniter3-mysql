
<br><br>

<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">imei</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MILEAGE</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CURRET</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MILEAGE</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">1 DAY AGO</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">2 DAYS AGO</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MILEAGE</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">3 DAYS AGO</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MILEAGE</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">4 DAYS AGO</th>

            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">MILEAGE</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">5 DAYS AGO</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php if(!empty($sp_rp_devicelocationlist_weekly_milage)): ?>
            <?php foreach ($sp_rp_devicelocationlist_weekly_milage as $row): ?>
                <tr>
                <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->imei ?></td>


                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_0, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_0 ?></td>

                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_1, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_1 ?></td>

                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_2, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_2 ?></td>

                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_3, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_3 ?></td>

                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_4, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_4 ?></td>

                    <td class="px-3 py-2 whitespace-nowrap"><?php echo round($row->mileage_5, 3) ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->date_5 ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3" class="px-3 py-2">
                    <div class="alert alert-info">
                        No Record Found.
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


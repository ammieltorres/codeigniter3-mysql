<div class="grid grid-cols-2 md:grid-cols-1 gap-4">
        

        <div class="grid grid-cols-1 md:grid-cols-1 gap-4">
            <div class="bg-white p-4 rounded-lg shadow">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                    <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RFID Code</th>
                                    <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time Stamp</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">

                            <?php if(!empty($result)): ?>
                                <?php foreach ($result as $row): ?>
                                    <tr>
                                        <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->id ?></td>
                                        <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->code ?></td>
                                        <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->timestamp ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="px-3 py-2">
                                        <div class="alert alert-info">
                                            No Record Found.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>

                                
                            </tbody>
                        </table>
                    </div>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-1 gap-4 h-20">
            <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Total RFID Read</h3>
                <p class="text-3xl font-bold"><?php echo $total ?> </p>
            </div>
        </div>
    </div>
</div>
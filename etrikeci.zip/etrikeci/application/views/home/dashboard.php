<?php
if($this->session->userdata('Category') === 'A')
{
?>
<br><br><br>
<div class="container">
<hr>
<canvas id="linechart" height="50px"></canvas>
<hr>
                                <!-- Chargers -->
    <div class="row">
        <div class="col-lg-3">
            <canvas id="C-charge" class="chartjs-render-monitor" ></canvas>
        </div>
        <div class="col-lg-3">
            <canvas id="R-charge" class="chartjs-render-monitor"></canvas>
        </div>
        <div class="col-lg-3">
              <canvas id="S-unit" class="chartjs-render-monitor"></canvas>
          </div>
          <div class="col-lg-3">
              <canvas id="R-unit"  class="chartjs-render-monitor" ></canvas>
          </div>
    </div>

<hr>
                                <!-- Battery -->
    <div class="row">
      <div class="col-lg-4">
      <canvas id="R-battery" class="chartjs-render-monitor"></canvas>
      </div>
      <div class="col-lg-4">
      <canvas id="C-battery" class="chartjs-render-monitor"></canvas>
      </div>
      <div class="col-lg-4">
      <canvas id="S-battery" class="chartjs-render-monitor"></canvas>
      </div>
    </div>

<hr>







<script>
const xValues = [1,2,3,4,5,6,7];
const UValues = [7,8,8,30,9,20,10];
const BValues = [6,1,8,2,5,8,51];
const CValues = [23,1,53,2,10,2,51];

new Chart("linechart", {
  type: "line",
  data: {
    labels: xValues,

    datasets: 
    [
      { 
        label: "Unit",
        data: UValues,
        borderColor: "red",
        backgroundColor: "red",
        fill: false,
      },
      { 
        label: "Battery",
        data: BValues,
        borderColor: "rgb(252, 186, 3)",
        backgroundColor: "rgb(252, 186, 3)",
        fill: false,
      },
      { 
        label: "Charger",
        data: CValues,
        borderColor: "#c0fac3",
        backgroundColor: "#c0fac3",
        fill: false,
      },
      
  ]
  },
  options: {
    legend: { 
        display: true,
       labels: {
           boxWidth: 40
       }},
    scales: {
      yAxes: [{ticks: {min: 0, max:60}}],
    }
  }
});
</script>

      </div>
</div>





    </div>

<?php
  if($rp_equipments_status)
  {

    foreach($rp_equipments_status as $row)
    {
      // Charger
        $TChargerOUT = $row->TChargerOUT;
        $TChargerIN = '2';

        $TChargerRepairOUT  = $row->TChargerRepairOUT;
        $TChargerRepairIN   = $row->TChargerRepairIN;

      // Battery
        $TBatteryRepairIN  = $row->TBatteryRepairIN;
        $TBatteryRepairOut   = $row->TBatteryRepairOut;
          
        $TBatteryChargeIN  = $row->TBatteryChargeIN;
        $TBatteryChargeOut   = $row->TBatteryChargeOut;
        
        $TBatterySWAPIN  = $row->TBatterySWAPIN;
        $TBatterySWAPOut   = $row->TBatterySWAPOut;

        //unit
        $TUnitRepairIN  = $row->TUnitRepairIN;
        $TUnitRepairOut   = $row->TUnitRepairOut;
        
        $TUnitOUT  = $row->TUnitOUT;
        $TUnitIN   = $row->TUnitIN;
    }

    ?>

    <!-- ===================== Charger ========================= -->
    <script>
        $(document).ready(function() {
            var ctx = $("#C-charge");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Charger Available - <?php echo $TChargerIN ?>", "Charger Unavailable - <?php echo $TChargerOUT; ?>"],
                    datasets: [{
                        data: [<?php echo $TChargerIN ?>, <?php echo $TChargerOUT; ?>],
                        backgroundColor: ["#89ecf5", "red"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Chargers'
                    }
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            var ctx = $("#R-charge");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Charger Available - <?php echo $TChargerRepairOUT ?>", "Charger In Repair - <?php echo $TChargerRepairIN; ?>"],
                    datasets: [{
                      data: [<?php echo $TChargerRepairOUT ?>, <?php echo $TChargerRepairIN; ?>],
                        backgroundColor: ["#89ecf5", "rgb(220, 20, 60)"]
                    }]
                    
                },
                options: {
                    title: {
                        display: true,
                        text: 'Charger Repairs'
                    }
                }
            });
        });
    </script>
<!-- ============================= Battery ==================================== -->

<script>
        $(document).ready(function() {
            var ctx = $("#R-battery");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Battery Available - <?php echo $TBatteryRepairIN ?>",  "Battery In Repair -  <?php echo $TBatteryRepairOut; ?>"],
                    datasets: [{
                      data: [<?php echo $TBatteryRepairIN ?>, <?php echo $TBatteryRepairOut; ?>],
                        backgroundColor: ["#87e69a", "rgb(220, 20, 60)"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Battery Repairs'
                    }
                }
            });
        });
    </script>


<script>
        $(document).ready(function() {
            var ctx = $("#C-battery");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Battery Available - <?php echo $TBatteryChargeOut ?>", "Battery In Charge - <?php echo $TBatteryChargeIN ?>"],
                    datasets: [{
                      data: [<?php echo $TBatteryChargeOut ?>, <?php echo $TBatteryChargeIN; ?>],
                        backgroundColor: ["#87e69a", "rgb(220, 20, 60)"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Battery Charge'
                    }
                }
            });
        });
    </script>


<script>
        $(document).ready(function() {
            var ctx = $("#S-battery");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Battery Swap In - <?php echo $TBatterySWAPIN ?>", "Battery Swap Out - <?php echo $TBatterySWAPOut ?>"],
                    datasets: [{
                      data: [<?php echo $TBatterySWAPIN ?>, <?php echo $TBatterySWAPOut; ?>],
                        backgroundColor: ["#87e69a", "rgb(220, 20, 60)"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Battery Swapping'
                    }
                }
            });
        });
    </script>
<!-- =============================== Unit ======================================== -->


<script>
        $(document).ready(function() {
            var ctx = $("#R-unit");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Unit Repair Out - <?php echo $TUnitRepairOut ?>","Unit Repair IN - <?php echo $TUnitRepairIN ?>"],
                    datasets: [{
                      data: [<?php echo $TUnitRepairOut; ?>,<?php echo $TUnitRepairIN ?>],
                        backgroundColor: ["#ed8aab", "rgb(220, 20, 60)"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Unit Repair'
                    }
                }
            });
        });
    </script>

<script>
        $(document).ready(function() {
            var ctx = $("#S-unit");
            var myLineChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Unit Swap IN  - <?php echo $TUnitIN ?>","Unit Swap OUT  - <?php echo $TUnitOUT ?>"],
                    datasets: [{
                      data: [<?php echo $TUnitIN; ?>,<?php echo $TUnitOUT ?>],
                        backgroundColor: ["#ed8aab", "rgb(220, 20, 60)"]
                    }]
                },
                options: {
                    title: {
                        display: true,
                        text: 'Unit Swapping'
                    }
                }
            });
        });
    </script>



<script>

</script>
    <?php
  }

?>


<?php
}
else
{


    
    ?>


<div class="" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Charge IN (By Users)</h5>

<hr>


    <table class="table table-striped table-light">
  <thead>
    <tr>
  
                <th>ID</th>

                <th>Status</th>

           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($sp_rp_equipments_find))
                {
                
                ?>

                    <?php foreach ($sp_rp_equipments_find as $row) 
                    {
                      ?>
                        <tr>
                             <td><?php echo $row->ID ?></td>
                            <td><?php echo $row->CStatus ?></td>
           
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-success">
                        NO BATTERY CURRENTLY CHARING.
                    </div>


                <?php
                    }
                ?>

  </tbody>
    </table>


  </div>
</div>


    <?php   
}
?>
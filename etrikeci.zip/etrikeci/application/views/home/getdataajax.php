

<div class="text-center"><b><?php echo $title; ?></b></div>
<hr>

<b><?php echo $result_count;?></b>
<br><br>

<!-- <?php echo $Status; ?> -->


<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>

                <th>ID</th>
                <th>Status</th>
                <th>DateTime</th>
           
           
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($Equipments))
                {
                
                ?>

                    <?php foreach ($Equipments as $row) 
                    {
                      ?>
                        <tr>
                            <td><?php echo $row->ID; ?></td>
                   
                            <td><?php
                                     if(stripos($Status,'SWAP IN') !== FALSE)
                                     {
                                        echo $row->EStatus;
                                     }
                                     elseif(stripos($Status,'SWAP OUT') !== FALSE)
                                     {
                                        echo $row->EStatus;
                                     }
                     
                     
                                     elseif(stripos($Status,'REPAIR IN') !== FALSE)
                                     {
                                        echo $row->RStatus;
                                     }
                                     elseif(stripos($Status,'REPAIR OUT') !== FALSE)
                                     {
                                        echo $row->RStatus;
                                     }
                     
                     
                                     elseif(stripos($Status,'CHARGE IN') !== FALSE)
                                     {
                                        echo $row->CStatus;
                                     }
                                     elseif(stripos($Status,'CHARGE OUT') !== FALSE)
                                     {
                                        echo $row->CStatus;
                                     
                                     }
                                    //  echo $Status;
                            ?></td>
                
                <td><?php
                                     if(stripos($Status,'SWAP IN') !== FALSE)
                                     {
                                        echo $row->EDateTime;
                                     }
                                     elseif(stripos($Status,'SWAP OUT') !== FALSE)
                                     {
                                        echo $row->EDateTime;
                                     }
                     
                     
                                     elseif(stripos($Status,'REPAIR IN') !== FALSE)
                                     {
                                        echo $row->RDateTime;
                                     }
                                     elseif(stripos($Status,'REPAIR OUT') !== FALSE)
                                     {
                                        echo $row->RDateTime;
                                     }
                     
                     
                                     elseif(stripos($Status,'CHARGE IN') !== FALSE)
                                     {
                                        echo $row->CDateTime;
                                     }
                                     elseif(stripos($Status,'CHARGE OUT') !== FALSE)
                                     {
                                        echo $row->CDateTime;
                                     
                                     }
                                    //  echo $Status;
                            ?></td>
                 
                            
                        

                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination dev">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


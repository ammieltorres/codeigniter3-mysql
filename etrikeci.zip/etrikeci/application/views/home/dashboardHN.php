
<script>function display_ct7() {
var x = new Date()
var ampm = x.getHours( ) >= 12 ? ' PM' : ' AM';
hours = x.getHours( ) % 12;
hours = hours ? hours : 12;
hours=hours.toString().length==1? 0+hours.toString() : hours;

var minutes=x.getMinutes().toString()
minutes=minutes.length==1 ? 0+minutes : minutes;

var seconds=x.getSeconds().toString()
seconds=seconds.length==1 ? 0+seconds : seconds;

var month=(x.getMonth() +1).toString();
month=month.length==1 ? 0+month : month;

var dt=x.getDate().toString();
dt=dt.length==1 ? 0+dt : dt;

var x1=month + "/" + dt + "/" + x.getFullYear(); 
x1 = x1 + " - " +  hours + ":" +  minutes + ":" +  seconds + " " + ampm;
document.getElementById('ct7').innerHTML = x1;
display_c7();
 }
 function display_c7(){
var refresh=1000; // Refresh rate in milli seconds
mytime=setTimeout('display_ct7()',refresh)
}
display_c7()
</script>

</head>

<body onload=display_ct7();>




	<!-- <div class="row"> -->

<!-- --------------------- -->










<div class="max-w-full mx-auto mt-8">
    <div class="mb-4 border-b border-gray-200 flex justify-between items-center">
        <h1 class="text-5xl"><span id='ct7'></span></h1>
        <ul class="flex flex-wrap -mb-px" id="myTab" role="tablist">
            <li class="mr-2" role="presentation">
                <button class="inline-block p-4 border-b-2 rounded-t-lg" id="tab1-tab" data-tabs-target="#tab1" type="button" role="tab" aria-controls="tab1" aria-selected="false">Equipments</button>
            </li>
            <li class="mr-2" role="presentation">
                <button class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300" id="tab2-tab" data-tabs-target="#tab2" type="button" role="tab" aria-controls="tab2" aria-selected="false">Track Solid</button>
            </li>

            <li class="mr-2" role="presentation">
                <button class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300" id="tab3-tab" data-tabs-target="#tab3" type="button" role="tab" aria-controls="tab3" aria-selected="false">RFID Report</button>
            </li>

            <li class="mr-2" role="presentation">
                <button class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300" id="tab4-tab" data-tabs-target="#tab4" type="button" role="tab" aria-controls="tab3" aria-selected="false">Sales Report</button>
            </li>


        </ul>
    </div>
    <div id="myTabContent" class="w-full ">
        <div class="hidden p-4 rounded-lg bg-gray-50" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">
        <h2 class="text-2xl font-bold mb-4 text-center alert alert-success shadow">GSHEET REPORT</h2>
        <div id="sitereportdata"></div>


      

          <br>
          
          <h2 class="text-2xl font-bold mb-4 text-center alert alert-success shadow">SITE REPORT</h2>
		  <div id="sitereportdataS" ></div><br>
          <div id="sp_rp_equipments_gtmileage"></div>
		  
		  

        </div>

        <div class="hidden p-4 rounded-lg bg-gray-50" id="tab2" role="tabpanel" aria-labelledby="tab2-tab">

    <h2 class="text-2xl font-bold mb-4 text-center alert alert-success shadow">Track Solid Reports</h2>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <!-- User Activity Report -->
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">User Activity Report</h3>
            <div class="overflow-x-auto">
               <div id="Battery"></div>
            </div>
        </div>

        <!-- Equipment Usage Report -->
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Equipment Usage Report</h3>
            <div class="overflow-x-auto">
				<div id="L5KM"></div>
            </div>
        </div>

        <!-- Maintenance Schedule Report -->
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Maintenance Schedule</h3>
            <div class="overflow-x-auto">
				<div id="G5KM"></div>
            </div>
        </div>
    </div>
    <br>
    <div class="grid grid-cols-1 lg:grid-cols-1 gap-4">
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Mileage Weekly Report</h3>
            <div class="overflow-x-auto">
               <div id="trachmileagetotalperweek"></div>
            </div>
        </div>
    </div>
</div>

</div>






<!-- RFID Report -->
<div class="hidden p-4 rounded-lg bg-gray-50" id="tab3" role="tabpanel" aria-labelledby="tab3-tab">

    <h2 class="text-2xl font-bold mb-4 text-center alert alert-success shadow">RFID REPORTS</h2>
    

    <div id="RFIDDATASCANED"></div>
 
           
    
</div>












        <!-- Sales Report -->
        <div class="hidden p-4 rounded-lg bg-gray-50" id="tab4" role="tabpanel" aria-labelledby="tab3-tab">
    <h2 class="text-2xl font-bold mb-4">Sales Report (SAMPLE ONLY)</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Total Sales</h3>
            <p class="text-3xl font-bold">$123,456</p>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-2">Units Sold</h3>
            <p class="text-3xl font-bold">1,234</p>
        </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow mb-6">
        <h3 class="text-lg font-semibold mb-2">Monthly Sales Trend</h3>
        <div class="h-64 bg-gray-200 rounded-lg flex items-center justify-center">
            <p class="text-gray-500">Sales chart placeholder</p>
        </div>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h3 class="text-lg font-semibold mb-2">Top Selling Products</h3>
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Units Sold</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Revenue</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">Product A</td>
                    <td class="px-6 py-4 whitespace-nowrap">500</td>
                    <td class="px-6 py-4 whitespace-nowrap">$50,000</td>
                </tr>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">Product B</td>
                    <td class="px-6 py-4 whitespace-nowrap">350</td>
                    <td class="px-6 py-4 whitespace-nowrap">$35,000</td>
                </tr>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">Product C</td>
                    <td class="px-6 py-4 whitespace-nowrap">200</td>
                    <td class="px-6 py-4 whitespace-nowrap">$20,000</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
    </div>
</div>

<script>
    // Tab functionality
    const tabButtons = document.querySelectorAll('[role="tab"]');
    const tabPanels = document.querySelectorAll('[role="tabpanel"]');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.getAttribute('data-tabs-target');
            const target = document.querySelector(targetId);

            tabPanels.forEach(panel => panel.classList.add('hidden'));
            tabButtons.forEach(btn => {
                btn.setAttribute('aria-selected', 'false');
                btn.classList.remove('bg-green-200', 'text-green-800');
                btn.classList.add('hover:text-green-600', 'hover:bg-green-100');
            });

            target.classList.remove('hidden');
            button.setAttribute('aria-selected', 'true');
            button.classList.remove('hover:text-green-600', 'hover:bg-green-100');
            button.classList.add('bg-green-200', 'text-green-800');
        });
    });

    // Set the first tab as active by default
    tabButtons[0].click();
</script>











</div>
  </div>


<script>
 
$(document).ready(function() {
   sitereport();
//    RFID();
   sitereportS();
nextpages();
trachmileagetotalperweek();

sp_rp_equipments_gtmileage();

});



function nextpages()
{
    
 
        var numberpagesbat = <?php echo $numberpagesbat ?>;
        var numberpagesbatV = <?php echo $numberpagesbat ?>;
        
        
        var numberpagesl5km = <?php echo $numberpagesl5km ?>;
        var numberpagesl5kmV = <?php echo $numberpagesl5km ?>;
        
        var numberpagesg5km = <?php echo $numberpagesg5km ?>;
        var numberpagesg5kmV = <?php echo $numberpagesg5km ?>;
        
        
        console.log(numberpagesbat);
        setTimeout(excuteMethod, 15000);

        
        
        function excuteMethod() 
        {
            console.log(numberpagesbat + ' call');
     	    
            numberpagesbat--;
            numberpagesl5km--;
            numberpagesg5km--;
            
                setTimeout(excuteMethod, 15000);
                sitereport();
                sitereportS();
                RFID();
                trachmileagetotalperweek();
                sp_rp_equipments_gtmileage();
                if (numberpagesbat  >= 0) setTimeout(nextBattery(), 3000);
                if (numberpagesl5km >= 0) setTimeout(nextl5km(), 3000);
                if (numberpagesg5km >= 0) setTimeout(nextg5km(), 3000);
               
                if (numberpagesbat  <= 0) setTimeout(Battery(page_url = false), 5000);
                if (numberpagesl5km <= 0) setTimeout(L5KM(page_url = false), 5000);
                if (numberpagesg5km <= 0) setTimeout(G5KM(page_url = false), 5000);
                
              
                if (numberpagesbat <= 0) { numberpagesbat = numberpagesl5kmV;  }
                if (numberpagesl5km <= 0) { numberpagesl5km = numberpagesl5kmV;  }
                if (numberpagesg5km <= 0) { numberpagesg5km = numberpagesg5kmV;  }
               
            }
    
            function nextBattery()
            {
                //  $("li[id='battery'] a[rel='next']").click();
              
                 Array.from(document.querySelectorAll('li[id="battery"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextl5km()
            {
                //  $("li[id='L5KM'] a[rel='next']").click();
                 
                 Array.from(document.querySelectorAll('li[id="L5KM"] a[rel="next"]')).forEach(button=>button.click());
            }
            function nextg5km()
            {
                //  $("li[id='G5KM'] a[rel='next']").click();
                 
                 Array.from(document.querySelectorAll('li[id="G5KM"] a[rel="next"]')).forEach(button=>button.click());
            }
		};
		
// 	================== Site Report =======================



function trachmileagetotalperweek()
    {
        
        

			var base_url = '<?php echo site_url('Dashboard/totalmileagereport/') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				
				
				
				success: function(response) {
					console.log(response);
					$("#trachmileagetotalperweek").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	

    function sitereport()
    {
        
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/Batteryreportgsheet/') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#sitereportdata").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
    
        function sitereportS()
    {
        
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/sitereport/') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#sitereportdataS").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	


    function sp_rp_equipments_gtmileage()
    {
        
        
        	var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Dashboard/sp_rp_equipments_gtmileage/') ?>';
			

			$.ajax({
				type: "POST",
				url: base_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#sp_rp_equipments_gtmileage").html(response);
				// 	console.log(base_url);
				// alert(response);

					
				}
			});
    }	
// 	==================================== L5 KM ================================	
		/*--first time load--*/
		L5KM(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.l5km li a", function(event) {
			var page_urlL5KM = $(this).attr('href');
			L5KM(page_urlL5KM);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function L5KM(page_url = false)
		{
			var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Home/L5KM/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#L5KM").html(response);
					console.log(base_url);

					
				}
			});

		}
// 	==================================== G5 KM ================================	
		/*--first time load--*/
		G5KM(page_url = false);

		/*-- Page click --*/
		$(document).on('click', ".pagination.g5km li a", function(event) {
			var page_urlG5KM = $(this).attr('href');
			G5KM(page_urlG5KM);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function G5KM(page_url = false)
		{
			var BatteryCode 	        = '';

			var base_url = '<?php echo site_url('Home/G5KM/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#G5KM").html(response);
					console.log(base_url);

					
				}
			});

		}
	
	
	// 	================================ Battery ================================	
		/*--first time load--*/
		Battery(page_url = false);
		
		/*-- Page click --*/
		$(document).on('click', ".pagination.battery li a", function(event) {
			var page_url = $(this).attr('href');
			Battery(page_url);
			event.preventDefault();
		});
		
		/*-- create function ajaxlist --*/
		function Battery(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Home/GetLowVolBattery/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#Battery").html(response);

					
				}
			});

		}










            // get rfid scanned



        		/*--first time load--*/
		RFID(page_url = false);
		
		
		/*-- create function ajaxlist --*/
		function RFID(page_url = false)
		{
			var BatteryCode 	        ='';
			
			var base_url = '<?php echo site_url('Home/GetRFID/') ?>';
			
			if(page_url == false) {
				var page_url = base_url;
			}
			
			$.ajax({
				type: "POST",
				url: page_url,
				data:  "BatteryCode=" + BatteryCode,

				
				
				
				success: function(response) {
					console.log(response);
					$("#RFIDDATASCANED").html(response);


					
				}
			});

		}

</script>

</script>







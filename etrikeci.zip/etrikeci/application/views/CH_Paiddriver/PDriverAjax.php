
<b><?php echo $result_count;?></b>
<br><br>




<div class="box">

<table class="table table-striped table-light">
  <thead>
    <tr>   
                <!--<th>Action</th>-->
                <th>USERID</th>
                <th>CHECKTIME</th>
                <th>CHECKTYPE</th>
                <th>VERIFYCODE</th>
                <th>SENSORID</th>
                <th>MEMOINFO</th>
                <th>sn</th>
                <th>UserExtFmt</th>
                <th>DateTimeStamp</th>
    </tr>
  </thead>
  <tbody>

  </tr>
                <?php if(!empty($PaidDrivers))
                {
                
                ?>

                    <?php foreach ($PaidDrivers as $row) 
                    {
                      ?>
                        <tr>
                            <!--<td><button class="btn btn-info">Details</button></td>-->
                            <td><?php echo $row->USERID ?></td>
                            <td><?php echo $row->CHECKTIME ?></td>
                            <td><?php echo $row->CHECKTYPE ?></td>
                            <td><?php echo $row->VERIFYCODE ?></td>
                            <td><?php echo $row->SENSORID ?></td>
                            <td><?php echo $row->MEMOINFO ?></td>
                            <td><?php echo $row->sn ?></td>
                            <td><?php echo $row->UserExtFmt ?></td>
                            <td><?php echo $row->DateTimeStamp ?></td>
                            
                 
                   
                        </tr>
                    <?php
                    }
                    ?>

        <?php   } 
                    else
                    {

        ?>
                    <div class="alert alert-info">
                        No Record Found.
                    </div>


                <?php
                    }
                ?>

  </tbody>

  
</table>

  <div class="paging">
    <ul class="pagination">
    <li class="page-item"><?php echo $pagelinks ?></li>
	</ul>
</div>


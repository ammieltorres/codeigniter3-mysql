
<?php
    if($DriverIDres)
    {
        foreach($DriverIDres as $row)
        {
            
            $newswapstatusD = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusD == "IN")
            {
                $newswapstatusdataD = 'OUT';
            }
            else
            {
                $newswapstatusdataD= 'IN';
            }
            ?>


     <table class="table">
          <thead>
            <tr></tr>
              <!--<th scope="col-2"><label for="p_unitid">Driver Code</label></th>-->
              <th scope="col-6">Name</th>

              <th scope="col-4">OLD Status</th>
              <th scope="col-3">NEW Status</th>
            </tr>
          </thead>
                   <th  ><input type="text" name="p_driverid" id="p_driverid" class="form-control input-sm"  placeholder="Driver ID" value="<?php echo $row['ID'] ?>" hidden ></th>
           
              <td  ><input type="text" name="p_ldriver" id="p_ldriver" class="form-control input-sm"  placeholder="Driver's First Name" value="<?php echo $row['LName'] ?>" hidden ></td>
              <td  ><input type="text" name="p_fdriver" id="p_fdriver" class="form-control input-sm"  placeholder="Driver's First Name" value="<?php echo $row['FName'] ?>" hidden ></td>
              <td  ><input type="text" name="p_mdriver" id="p_mdriver" class="form-control input-sm"  placeholder="Driver's Middle Name" value="<?php echo $row['MName'] ?>" hidden ></td>

          <tbody>
            <tr>
            <td  scope="col-sm-6"><input type="text" name="name" id="name" class="form-control input-sm"  placeholder="Driver's First Name" value="<?php echo $row['LName'].', '.$row['FName'] ?>" readonly ></td>
            <td  scope="col-sm-3"><input type="text" name="p_OldSwapStatus" id="p_OldSwapStatus" class="form-control input-sm"  placeholder="Driver's Middle Name" value="<?php echo $row['EStatus'] ?>" readonly ></td>
            <td  scope="col-sm-3"><input type="text" name="p_NewwapStatusD" id="p_NewwapStatusD" class="form-control input-sm"  placeholder="Driver's Middle Name" value="<?php echo 'SWAP '. $newswapstatusdataD ?>" readonly ></td>
              
              
              
     
            </tr>
             <tbody>
        </table>





            <?php
        }
    }
?>
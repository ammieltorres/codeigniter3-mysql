<!-- <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="p_swaptype">SWP TYPE</label>
              <select  type="text" name="p_swaptype" id="p_swaptype" class="form-control input-sm" value="" required>                                              
                                    <option value="SWAP IN">SWAP IN</option>
                                    <option value="SWAP OUT">SWAP OUT</option>      
              </select>
        </div>
    </div>       
</div>     -->






<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="Result" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Result</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ResData"></div>
      </div>
 
    </div>
  </div>
</div>

<div class="modal fade bd-example-modal-lg" id="errornodal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
            <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ERROR</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <h2>ALL VALUE MUST BE ALL SWAP IN / SWAP OUT.</h2>
                <div class="row">
                    <div class="col-sm-12">
                        <label>Driver Status</label>
                        <input class="form-control"  id="DS">
                    </div>
                    
                    <div class="col-sm-12">
                        <label>Battery Status</label>
                        <input class="form-control" id="BS">
                    </div>
                    
                    <div class="col-sm-12">
                        <label>Unit Status</label>
                        <input class="form-control"  id="US">
                    </div>
                </div>
                <hr>
                <div id="countdown"></div>
                    <div id="msg"><div>
                <form Method="POST" id="NewDataScanVerify" >
                    <div class="col-sm-12">
                        <label>to reset please scan user RFID</label>
                        <input class="form-control" id="rfiduser" autofocus >
                    </div>
                    <div class="col-sm-12" ><button type ="Submit" class="btn btn-danger form-control">Reset Data</button></div>
                </from>
            </div>
    </div>
  </div>
</div>




<div class="modal fade bd-example-modal-lg" id="errornodalresccan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
            <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ERROR</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <h2>INVALID USER.</h2>

                <hr>
                <div id="countdownresdata"></div>
                <form Method="POST" id="NewDataScanVerify" >
                  
                    <div class="col-sm-12">
                        <label>to reset please scan user RFID</label>
                        <input class="form-control" id="rfiduser" autofocus >
                    </div>
                    <div class="col-sm-12" ><button type ="Submit" class="btn btn-danger form-control">Reset Data</button></div>
                </from>
            </div>
    </div>
  </div>
</div>




<script>
  $('#NewDataScanVerify').unbind("submit");
    $("#NewDataScanVerify").submit(function(e) 
    {
      e.preventDefault();
			var rfiduser             = $("#rfiduser").val();
			var labelElement = document.getElementById("msg");
			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/VerifyUser/') ?>",
				data:  "rfiduser=" + rfiduser,		
				
				success: function(response) {
					console.log(response);
					if(response == true)
					{
					   // alert('reset');
					    window.location.replace("<?php echo base_url('Login/logoutrfid') ?>");
					}
					else
					{
					  labelElement.innerHTML ="<div class='alert alert-danger' role='alert'>INVALID USER</div>";
					  $('#errornodal').modal('hide');
					  $("#rfiduser").val(' ')
				// 	  $('#errornodalresccan').modal('toggle');
							setTimeout(function(){
                          $('#errornodal').modal('toggle');
                            }, 1000);
                            
    					setTimeout(function(){
                        $("#rfiduser").focus();
                            }, 2000);
                            
                            

                        let timeleft = 3;
                        let downloadTimer = setInterval(function(){
                          if(timeleft <= 0){
                            clearInterval(downloadTimer);
                             $('#errornodal').modal('hide');
                            // $('#errornodalresccan').modal('hide');
                            setTimeout(function(){
                                $("#ID").focus();
                            }, 1000);
                          } else {
                            document.getElementById("countdownresdata").innerHTML = timeleft + " seconds remaining before closing the error modal";
                          }
                          timeleft -= 1;
                        }, 1000);
            
            
            
            
					}
                    // $("#result").html(response);
                    // $("#ID").val('');
                    // var input = document.getElementById("ID").focus()
				}
			});
            return false;
		});
</script>



<script>


  
        
    
    
    
    

$(document).ready(function(){

    var p_NewSwapStatusU    =   $("#p_NewSwapStatusU").val();
    var p_NewwapStatusD     =   $("#p_NewwapStatusD").val();
    var p_NewSwapStatusB    =   $("#p_NewSwapStatusB").val();
     
    
    var p_unitid              = $("#p_unitid").val();
    var p_batteryid           = $("#p_batteryid").val();
    var p_driverid            = $("#p_driverid").val();
    var p_ldriver             = $("#p_ldriver").val();
    var p_fdriver             = $("#p_fdriver").val();
    var p_mdriver             = $("#p_mdriver").val();
    

    if (p_NewSwapStatusU === 'SWAP IN' && p_NewSwapStatusB === 'SWAP IN'  && p_NewwapStatusD === 'SWAP IN') 
        {
          
            var p_swaptype              = "SWAP IN";
            
               	$.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/AddSwappingRecord/') ?>",
				data:  "p_swaptype=" + p_swaptype + "&p_unitid=" + p_unitid + 
                "&p_batteryid=" + p_batteryid + "&p_driverid=" + p_driverid + 
                "&p_ldriver=" + p_ldriver + "&p_fdriver=" + p_fdriver + "&p_mdriver=" + p_mdriver,		
				
				success: function(response) {
				console.log(response);

                $("#ResData").html(response);
                // $("#p_swaptype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                $('#Result').modal('toggle');
                  redirecttorfidlogin();
            //     alert(p_batteryid);
            //   alert(p_unitid);

				}
			});
            
            
            
            
        }
    else if (p_NewSwapStatusU === 'SWAP OUT' && p_NewSwapStatusB === 'SWAP OUT'  && p_NewwapStatusD === 'SWAP OUT')
       {
          
             var p_swaptype              = "SWAP OUT";
           	$.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/AddSwappingRecord/') ?>",
				data:  "p_swaptype=" + p_swaptype + "&p_unitid=" + p_unitid + 
                "&p_batteryid=" + p_batteryid + "&p_driverid=" + p_driverid + 
                "&p_ldriver=" + p_ldriver + "&p_fdriver=" + p_fdriver + "&p_mdriver=" + p_mdriver,		
				
				success: function(response) {
				console.log(response);

                $("#ResData").html(response);
                //  alert('Swap out');
                // $("#p_swaptype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                $('#Result').modal('toggle');
                redirecttorfidlogin();
            //         alert(p_batteryid);
            //   alert(p_unitid);

				}
			});
           
           
           
           
           
           
           
       }
   else
       {
            $('#US').val(p_NewSwapStatusU);
            $('#DS').val(p_NewwapStatusD);
            $('#BS').val(p_NewSwapStatusB);
            
           $('#errornodal').modal('toggle');
           
           
           setTimeout(function(){
                    $("#rfiduser").focus();
                }, 1000);
                
                
                
            let timeleft = 3;
            let downloadTimer = setInterval(function(){
              if(timeleft <= 0){
                clearInterval(downloadTimer);
                $('#errornodal').modal('hide');
                setTimeout(function(){
                    $("#ID").focus();
                }, 1000);
              } else {
                document.getElementById("countdown").innerHTML = timeleft + " seconds remaining before closing the error modal";
              }
              timeleft -= 1;
            }, 1000);
            

  
          
       }
      
});

// window.location.replace("http://www.w3schools.com");


function redirecttorfidlogin()
{
     setTimeout(function(){
                window.location.replace("<?php echo base_url('Login/logoutrfid') ?>");
                }, 4000);
  
}
    

  function swapsub(event) {


  $('#submitrecord').unbind("submit");
    $("#submitrecord").submit(function(e) 
    {


          e.preventDefault();
            $('#subrec').attr('disabled','disabled');
            // console.log
			      var p_swaptype            = (event.target.value);
            var p_unitid              = $("#p_unitid").val();
            var p_batteryid           = $("#p_batteryid").val();
            var p_driverid            = $("#p_driverid").val();
            var p_ldriver             = $("#p_ldriver").val();
            var p_fdriver             = $("#p_fdriver").val();
            var p_mdriver             = $("#p_mdriver").val();
            // alert(p_swaptype);
           
			$.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/AddSwappingRecord/') ?>",
				data:  "p_swaptype=" + p_swaptype + "&p_unitid=" + p_unitid + 
                "&p_batteryid=" + p_batteryid + "&p_driverid=" + p_driverid + 
                "&p_ldriver=" + p_ldriver + "&p_fdriver=" + p_fdriver + "&p_mdriver=" + p_mdriver,		
				
				success: function(response) {
				console.log(response);

                $("#ResData").html(response);
                // $("#p_swaptype").val('');
                // $("#p_batteryid").val('');
                $('#subrec').attr("disabled", false);
                $('#Result').modal('toggle');
              

				}
			});
        
		});

  }
</script>

<script>
    $(document).ready(function(){
      video.srcObject.getTracks().forEach(track => {
          track.stop();
        });
        qrResult.hidden = false;
        canvasElement.hidden = true;
        btnScanQR.hidden = false;
    });
</script>           

<script>
    function openqrscan()
    {
        navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      btnScanQR.hidden = false;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
    }
</script>


<script>
       function newrecord()
    {

        $("#p_unitid").val('');
        $("#p_batteryid").val('');
        $("#p_driverid").val('');
        $("#p_ldriver").val('');
        $("#p_fdriver").val('');
        $("#p_mdriver").val('');
        $.ajax({
				method: "POST",
				url: "<?php echo site_url('Swapping/removesession/') ?>",
        success: function(response) {
          location.reload()
        }
        });
        
    
        document.getElementById('p_swaptype').options[0].selected = 'selected';
    }
</script>
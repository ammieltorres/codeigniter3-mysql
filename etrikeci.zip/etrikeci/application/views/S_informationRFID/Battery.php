<?php
if($BatteryIDres)
{
    foreach($BatteryIDres as $row)
    {
        
         $newswapstatusB = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusB == "IN")
            {
                $newswapstatusdataB = 'OUT';
            }
            else
            {
                $newswapstatusdataB = 'IN';
            }
        ?>
            
            
        <table class="table">
          <thead>
            <tr></tr>
              <th scope="col-6"><label for="p_unitid">Battery Code</label></th>

              <th scope="col-3">OLD Status</th>
              <th scope="col-3">NEW Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th  scope="col-sm-6"><input type="text" name="p_batteryid" id="p_batteryid" class="form-control input-sm"  placeholder="Unit ID" value="<?php echo $row['ID'] ?>" readonly ></th>
                <td  scope="col-sm-3"> <input type="text" name="p_OldSwapStatusB" id="p_OldSwapStatusB" class="form-control input-sm"  placeholder="Dp_OldSwapStatusB" value="<?php echo $row['EStatus'] ?>" readonly ></td>
                <td  scope="col-sm-3">  <input type="text" name="p_NewSwapStatusB" id="p_NewSwapStatusB" class="form-control input-sm"  placeholder="p_NewSwapStatusB" value="<?php echo 'SWAP '. $newswapstatusdataB ?>" readonly ></td>
              


            </tr>
             <tbody>
        </table>

        <?php
    }
}
else
{
    echo 'empty';
}
?>


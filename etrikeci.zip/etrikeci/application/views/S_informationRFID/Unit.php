<hr>

<?php
if($UnitIDres)
{
    foreach($UnitIDres as $row)
    {
         $newswapstatusU = explode(" ",$row['EStatus'])[1];  
            if($newswapstatusU == "IN")
            {
                $newswapstatusdataU = 'OUT';
            }
            else
            {
                $newswapstatusdataU = 'IN';
            }
         
        ?>
        
            
<table class="table">
  <thead>
    <tr></tr>
      <th scope="col-6"><label for="p_unitid">Unit Code</label></th>

      <th scope="col-3">OLD Status</th>
      <th scope="col-3">NEW Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th  scope="col-sm-2"><input type="text" name="p_unitid" id="p_unitid" class="form-control input-sm"  placeholder="Unit ID" value="<?php echo $row['ID'] ?>" readonly ></th>

      <td  scope="col-sm-2"> <input type="text" name="p_OldSwapStatusU" id="p_OldSwapStatusU" class="form-control input-sm"  placeholder="Dp_OldSwapStatusU" value="<?php echo $row['EStatus'] ?>" readonly ></td>
      <td  scope="col-sm-2">  <input type="text" name="p_NewSwapStatusU" id="p_NewSwapStatusU" class="form-control input-sm"  placeholder="p_NewSwapStatusU" value="<?php echo 'SWAP '. $newswapstatusdataU ?>" readonly ></td>
    </tr>
     <tbody>
</table>
        <?php
    }
}
?>

<?php

if($ResultModal)
{
    foreach($ResultModal as $row)
    {
    ?>
<div class="alert alert-success" role="alert">
<?php echo $row->p_itemcode; ?> Updated!
</div>

<br>
<div class="row">
                        <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">ID</label>
						        <input type="text" class="form-control" name="dataresultmodalbat" id="dataresultmodalbat" value ="<?php echo $row->p_itemcode; ?>" onkeypress="return false;" required/>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Category</label>
						        <input type="text" class="form-control" name="dataresultmodalbat" id="dataresultmodalbat" value ="<?php echo $row->p_category; ?>"  onkeypress="return false;"  required/>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Status</label>
						        <input type="text" class="form-control" name="dataresultmodalbat" id="dataresultmodalbat" value ="<?php echo $row->p_status; ?>"  onkeypress="return false;"  required/>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <label for="Branch">Value</label>
						        <input type="text" class="form-control" name="dataresultmodalbat" id="dataresultmodalbat" value ="<?php echo $row->p_value; ?>"  onkeypress="return false;"  required/>
                            </div>

</div>
    <?php
    }
}

?>


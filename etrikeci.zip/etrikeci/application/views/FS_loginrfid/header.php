<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>GERWEISS</title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('img/logo.png')?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="sha384-wESLQ85D6gbsF459vf1CiZ2+rr+CsxRY0RpiF1tLlQpDnAgg6rwdsUF1+Ics2bni" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css'); ?>" >
    <link rel="stylesheet"  href="<?php echo base_url('css/jquery.mCustomScrollbar.min.css'); ?>" >
    <link rel="stylesheet"  href="<?php echo base_url('css/bootstrap.css'); ?>" >
    <script src="<?php echo base_url('js/jquery.min.js'); ?>" ></script>
    <link rel="stylesheet" type="text/css"  href="<?php echo base_url('css/lstyle.css'); ?>" >
</head>
<body> 
    
<?php
    date_default_timezone_set('Asia/Manila');    
?>








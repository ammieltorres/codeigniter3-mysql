<div class="font-[sans-serif] h-screen flex items-center justify-center bg-gray-100">
  <div class="grid md:grid-cols-2 items-center gap-4 max-w-5xl w-full mx-auto p-4 bg-white shadow-[0_2px_10px_-3px_rgba(6,81,237,0.3)] rounded-md">
    <div class="w-full px-4 py-2">
    <form action="<?php echo base_url(); ?>Login/LoginValidationrfid" method="post" class="login100-form validate-form" >
        <div class="mb-6">
          <h3 class="text-gray-800 text-xl font-bold">RFID Login</h3>
          <div class="flex  md:hidden h-full bg-[#000842] rounded-xl p-4">
            <img src="<?php echo base_url('img/bg.png') ?>" class="w-full h-full object-contain" alt="login-image" />
          </div>
        </div>

        <?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
        <div class="alert alert-danger animated wow tada"  role="alert">
            <?php
             echo $this->session->flashdata('error');
 
            ?>
        </div>
        <?php
    }

    if(!empty($error_message))
    {
        ?>
        <div class="alert alert-danger" role="alert">
            <?php
            echo $error_message;
            ?>
        </div>
        <?php
    }
    ?>

        <!-- Email input -->
        <div class="mb-4">
          <label class="text-gray-800 text-xs block mb-1">RFID</label>
          <input name="RFID" type="text" required class="w-full text-gray-800 text-sm border-b border-gray-300 focus:border-blue-600 px-2 py-2 outline-none" placeholder="RFID" />
        </div>




        <div class="flex  space-x-4 mt-4">
          <a href="<?php echo base_url('Login/Userlogin') ?>" class="hover:text-green-600 transition-shadow duration-300 ease-in-out"><b>Proceed to username and password login</b></a>
        </div>

        <!-- Sign in button -->
        <button type="submit" class="w-full py-2 px-4 text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-900 focus:outline-none">
          Sign in
        </button>

        <!-- Social media buttons -->
        <div class="flex justify-center space-x-4 mt-4">
          <!-- ... (keep your existing social media button SVGs, but reduce their size) ... -->
        </div>
      </form>
    </div>

    <div class="hidden md:block h-full bg-[#000842] rounded-xl p-4">
      <img src="<?php echo base_url('img/bg.png') ?>" class="w-full h-full object-contain" alt="login-image" />
    </div>
  </div>
</div>
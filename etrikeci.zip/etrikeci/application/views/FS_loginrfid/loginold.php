

<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.19.1/css/mdb.min.css" rel="stylesheet">





<div class="container-fluid ps-md-0">
  <div class="row g-0">
  <?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
              <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
        <?php
    }
    else
    {
        ?>   
           <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image animated wow slideInDown"></div>
        <?php
    }

    ?>
 

    <div class="col-md-8 col-lg-6">
      <div class="login d-flex align-items-center py-5">
        <div class="container">
          <div class="row">
            <div class="col-md-9 col-lg-8 mx-auto">

            <?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
        <div class="alert alert-danger animated wow tada"  role="alert">
            <?php
             echo $this->session->flashdata('error');
 
            ?>
        </div>
        <?php
    }

    if(!empty($error_message))
    {
        ?>
        <div class="alert alert-danger" role="alert">
            <?php
            echo $error_message;
            ?>
        </div>
        <?php
    }
    ?>



<?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
            <h3 class="login-heading mb-4">GerWeiss</h3>
            <h3 class="login-heading mb-4">Record Keeping System</h3><br><br><br>
        <?php
    }
    else
    {
        ?>   
            <h3 class="login-heading mb-4 animated wow zoomIn" >GerWeiss</h3>
            <h3 class="login-heading mb-4 animated wow zoomIn" >Record Keeping System</h3><br><br><br>
              
       
        <?php
    }

    ?>
         


         <?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
           <div>
        <?php
    }
    else
    {
        ?>   
             <div class="animated wow slideInUp">
              
       
        <?php
    }

    ?>
          
       
            
              <!-- Sign In Form -->
              <form action="<?php echo base_url(); ?>Login/LoginValidationrfid" method="post" class="login100-form validate-form" >

              <?php 
    if(!empty($this->session->flashdata('error')))
    {
        ?>
            <div class="form-floating mb-3">
                  <input type="text" name="RFID"class="form-control" id="floatingInput" placeholder="UserID" autofocus required>
                  <label for="floatingInput">RFID</label>
                </div>

        <?php
    }
    else
    {
        ?>
        
           <div class="form-floating mb-3 animated wow zoomIn">
                  <input type="text" name="RFID"class="form-control" id="floatingInput" placeholder="RFID" autofocus required>
                  <label for="floatingInput">RFID</label>
                </div>
        
      
        <?php
    }

    ?>
             

                <div class="d-grid">
                  <button class="btn btn-lg btn-primary btn-login text-uppercase fw-bold mb-2" type="submit">login</button>
                
                </div>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
                            

</html>

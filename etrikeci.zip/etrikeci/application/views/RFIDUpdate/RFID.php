
<div class="box">
	<div class="row">

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="search-field">
            
                        <div class="row">
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <label for="ID">ID</label>
						        <input type="text" class="form-control" name="IDsearch" id="IDsearch" placeholder="ID" />
                            </div>

                            
                            <div class="col-xs-4 col-sm-4 col-md-4">
                                <div class="form-group">
                                    <label for="CategoryCode">Category</label>
                                    <select  type="CategoryCode" name="CategoryCode" id="CategoryCode" class="form-control input-sm" value="" required>
                                                        <option value="">Category</option>                                                   
                                                        <option value="0001">Driver</option>
                                                        <option value="0002">Unit</option>      
                                                        <option value="0003">Battery</option>     
                                                        <option value="0004">Charger</option>     
                                    </select>
                                </div>
                            </div>
                        </div>
                     
                        <div class="row">
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="searchBtn" class="btn btn-info form-control">Search</button>
                            </div>
                            <div class="col-xs-2 col-sm-2 col-md-2">
                                <button type="button" id="resetBtn" class="btn btn-warning form-control">Clear Texbox</button>
                            </div>
                           
                        </div>

					</div>
				</div>
				
			</div>
		</div>
	</div>
    <hr>


    <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Equipment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
   
            <div class="modal-body">
                <div class="col-md-12">
                    <div id="ajaxContentnew"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
           
            </div>
      
    </div>
  </div>
  </div>
<!-- --------------------- -->

	<div class="row">
		<div class="col-md-12">
			<div id="ajaxContent"></div>
		</div>
	</div>




<script>

//     function addmodalopen(CategoryCode, Category) {
        
         

// 			var base_url = '<?php echo site_url('Equipments/addingequipments/') ?>';
//             $.ajax({
// 				type: "POST",
// 				url: base_url,
// 				data:  "CategoryCode=" + CategoryCode + "&Category=" + Category,

				
				
				
// 				success: function(response) {
// 					console.log(response);
//                     // ('#myModal').modal(toggle);
// 					$("#ajaxContentnew").html(response);
//                     // alert(response);
					
// 				}
// 			});
//     }
// </script>





<style>

 i
 {
     /*font-size:40px;*/
     color:green;
 }


</style>

<style>
 i {
     color: green;
     animation: pulse 2s infinite;
 }

 @keyframes pulse {
     0% {
         transform: scale(1);
     }
     50% {
         transform: scale(1.1);
     }
     100% {
         transform: scale(1);
     }
 }
</style>
<style>
 i {
     color: green;
 }

 .fa-battery-empty {
     animation: blink-red 1s infinite;
 }

 .fa-battery-quarter {
     animation: charging 1.5s infinite;
 }

 .fa-battery-full {
     animation: pulse 2s infinite;
 }

 .fa-battery-three-quarters {
     animation: bounce 1.5s infinite;
 }

 @keyframes blink-red {
     0%, 100% { color: green; }
     50% { color: red; }
 }

 @keyframes charging {
     0%, 100% { 
         color: green;
         transform: scale(1);
     }
     50% { 
         color: #FFD700; /* Gold color for the lightning effect */
         transform: scale(1.2);
     }
 }

 @keyframes pulse {
     0% { transform: scale(1); }
     50% { transform: scale(1.1); }
     100% { transform: scale(1); }
 }

 @keyframes bounce {
     0%, 100% { transform: translateY(0); }
     50% { transform: translateY(-10px); }
 }
</style>


<!-- <script src="<?php echo base_url("js/cdn.tailwind.js"); ?>"></script> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


<!-- <h2 class="text-2xl font-bold mb-4">Battery</h2> -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">

<div class="grid grid-cols-1 md:grid-cols-1 gap-4">



<div class="bg-white p-4 rounded-lg shadow-lg ">
    <h3 class="text-lg font-semibold mb-1">
        <i class="fas fa-battery-half mr-2"></i>
        <i class="fas fa-list-ul mr-2"></i>
        Battery List
    </h3>



	<div class="overflow-x-auto">
	<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GS_DateTime</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GS_CB</th>
            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">GS_Unit_Battery</th>
        </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
        <?php if(!empty($result)): ?>
            <?php foreach ($result as $row): ?>
                <tr>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->GS_DateTime ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->GS_CB ?></td>
                    <td class="px-3 py-2 whitespace-nowrap"><?php echo $row->GS_Unit_Battery ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3" class="px-3 py-2">
                    <div class="alert alert-info">
                        No Record Found.
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

		</div>


















    </div>

	</div>


	<div class="grid grid-cols-1 md:grid-cols-2 gap-4">


    <div class="bg-white p-4 rounded-lg shadow">
        <h2 class="text-lg font-semibold mb-3"><i class="fas fa-battery-empty mr-2"></i>To Charge</h2>
        <p class="text-3xl font-bold"><?php echo $Battocharge; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h2 class="text-lg font-semibold mb-3"><i class="fas fa-battery-quarter mr-2"></i>Charging</h2>
        <p class="text-3xl font-bold"><?php echo $Batcharging; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h2 class="text-lg font-semibold mb-3"><i class="fas fa-battery-full mr-2"></i>Available</h2>
        <p class="text-3xl font-bold"><?php echo $BatAvailable; ?></p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <h2 class="text-lg font-semibold mb-3"><i class="fas fa-battery-three-quarters mr-2"></i>In Use</h2>
        <p class="text-3xl font-bold"><?php echo $Batinuse; ?></p>
    </div>
</div>

</div>   

                      












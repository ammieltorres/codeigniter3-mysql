/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./application/Views/**/*.php"],
  theme: {
    extend: {},
  },
  plugins: [],
}

